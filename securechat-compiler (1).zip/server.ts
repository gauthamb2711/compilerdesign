import express from "express";
import path from "path";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI } from "@google/genai";
import dotenv from "dotenv";

dotenv.config();

let aiClient: GoogleGenAI | null = null;

function getGeminiClient(): GoogleGenAI {
  if (!aiClient) {
    const apiKey = process.env.GEMINI_API_KEY;
    if (!apiKey) {
      console.warn("GEMINI_API_KEY environment variable is not set. Compiler AI will run in fallback mode.");
    }
    aiClient = new GoogleGenAI({
      apiKey: apiKey || "dummy-key",
      httpOptions: {
        headers: {
          "User-Agent": "aistudio-build",
        },
      },
    });
  }
  return aiClient;
}

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json({ limit: "5mb" }));

  // Health check API
  app.get("/api/health", (_req, res) => {
    res.json({ status: "ok", timestamp: new Date().toISOString() });
  });

  // Compiler AI Multi-Turn API Route (Fast Engine)
  app.post("/api/chatbot/chat", async (req, res) => {
    try {
      const {
        messages = [],
        systemInstruction = "You are Compiler AI, an intelligent, lightning-fast compiler engineering and language processing assistant. You specialize in compiler design, parsing, symbol tables, intermediate code (TAC), optimization passes, and target machine code generation. Always introduce and refer to yourself strictly as Compiler AI. Answer clearly, accurately, and directly.",
      } = req.body;

      if (!Array.isArray(messages) || messages.length === 0) {
        return res.status(400).json({ error: "Messages array cannot be empty." });
      }

      // Always use the fast model
      const model = "gemini-3.1-flash-lite";

      const apiKey = process.env.GEMINI_API_KEY;
      if (!apiKey) {
        // Fallback if API key is not configured yet
        const lastUserMessage = messages[messages.length - 1]?.text || "";
        return res.json({
          reply: `[Compiler AI Response]: I received your prompt: "${lastUserMessage}". In compiler architecture, this involves analyzing the source stream across the 6 core phases (Lexical Scanner → Recursive Descent Parser → Semantic Symbol Table Binding → Three-Address IR Generation → Multi-pass Optimization → Target Code Synthesis).`,
          role: "model",
        });
      }

      const ai = getGeminiClient();

      // Format messages into Gemini contents format
      const formattedContents = messages.map((m: { role: string; text: string }) => ({
        role: m.role === "assistant" || m.role === "model" ? "model" : "user",
        parts: [{ text: m.text }],
      }));

      const response = await ai.models.generateContent({
        model: model,
        contents: formattedContents,
        config: {
          systemInstruction: systemInstruction,
        },
      });

      const responseText = response.text || "I didn't receive a response from the compiler engine.";

      return res.json({
        reply: responseText,
        role: "model",
      });
    } catch (error: any) {
      console.error("Compiler AI API Error:", error);
      return res.status(500).json({
        error: error.message || "Failed to generate response from Compiler AI.",
      });
    }
  });

  // Vite middleware setup
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (_req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
