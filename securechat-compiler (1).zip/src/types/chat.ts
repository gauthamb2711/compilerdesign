import { CompilerResult, Classification, ThreatLevel } from '../compiler/types';

export type MessageStatus = 'SENDING' | 'SENT' | 'DELIVERED' | 'SEEN';

export interface ConversationParticipant {
  uid: string;
  fullName: string;
  email: string;
  phone?: string;
  avatarUrl?: string;
  online?: boolean;
}

export interface Message {
  id: string;
  conversationId: string;
  senderId: string;
  receiverId: string;
  originalText: string;
  processedText: string;
  classification: Classification;
  confidence?: number;
  riskScore: number;
  threatLevel: ThreatLevel;
  detectedUrls?: string[];
  removedUrls?: string[];
  hasUrl: boolean;
  compilerAnalysis: CompilerResult;
  status: MessageStatus;
  createdAt: any;
  deliveredAt?: string;
  seenAt?: string;
}

export interface Conversation {
  id: string;
  participantIds: string[];
  participants: Record<string, ConversationParticipant>;
  lastMessage: string;
  lastMessageType?: any;
  lastMessageAt: any;
  unreadCount?: Record<string, number>;
  createdAt: any;
  updatedAt?: any;
}

export interface TypingStatus {
  conversationId: string;
  userId: string;
  userName?: string;
  isTyping: boolean;
  updatedAt: string;
}
