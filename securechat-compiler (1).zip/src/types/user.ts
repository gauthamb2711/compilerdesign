export interface UserProfile {
  uid: string;
  fullName: string;
  email: string;
  emailNormalized: string;
  phone: string;
  phoneNormalized: string;
  avatarUrl?: string;
  online: boolean;
  lastSeen: string;
  createdAt: string;
}
