import React from 'react';
import { BrowserRouter, Link, Navigate, Route, Routes, useLocation } from 'react-router-dom';
import { Shield, MessageSquare, ShieldAlert, Cpu, User, LogOut, Bot } from 'lucide-react';
import { useAuth, AuthProvider } from './hooks/useAuth';
import { Landing } from './pages/Landing';
import { Login } from './pages/Login';
import { Register } from './pages/Register';
import { Chat } from './pages/Chat';
import { Security } from './pages/Security';
import { CompilerLab } from './pages/CompilerLab';
import { ChatbotPage } from './pages/ChatbotPage';
import { Profile } from './pages/Profile';
import { FloatingChatbot } from './components/chatbot/FloatingChatbot';
import { FirebaseMissingAlert } from './components/common/FirebaseMissingAlert';
import { isFirebaseConfigured } from './lib/firebase';
import { logoutUser } from './services/authService';

function NavigationHeader() {
  const { user, profile } = useAuth();
  const location = useLocation();

  if (['/login', '/register'].includes(location.pathname)) {
    return null;
  }

  const isActive = (path: string) => location.pathname === path;

  return (
    <header className="bg-white/90 backdrop-blur-md border-b border-slate-200/80 sticky top-0 z-40 shadow-sm">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
        <Link to="/" className="flex items-center gap-3 group">
          <div className="w-9 h-9 rounded-xl bg-indigo-600 flex items-center justify-center text-white shadow-md shadow-indigo-200 group-hover:scale-105 transition-transform">
            <Shield className="w-5 h-5" />
          </div>
          <span className="text-lg font-bold tracking-tight text-slate-800 group-hover:text-indigo-600 transition-colors">
            SecureChat <span className="text-indigo-600 font-mono text-xs border border-indigo-200 px-2 py-0.5 rounded-full bg-indigo-50 font-semibold">COMPILER</span>
          </span>
        </Link>

        <nav className="flex items-center gap-1 sm:gap-2">
          <Link
            to="/chat"
            className={`px-3.5 py-2 rounded-lg text-xs font-medium flex items-center gap-2 transition-colors ${
              isActive('/chat')
                ? 'bg-indigo-50 text-indigo-700 font-semibold'
                : 'text-slate-500 hover:text-slate-800 hover:bg-slate-50'
            }`}
          >
            <MessageSquare className="w-4 h-4" />
            <span className="hidden md:inline">Chat</span>
          </Link>

          <Link
            to="/chatbot"
            className={`px-3.5 py-2 rounded-lg text-xs font-medium flex items-center gap-2 transition-colors ${
              isActive('/chatbot')
                ? 'bg-indigo-50 text-indigo-700 font-semibold'
                : 'text-slate-500 hover:text-slate-800 hover:bg-slate-50'
            }`}
          >
            <Cpu className="w-4 h-4 text-indigo-600" />
            <span className="hidden md:inline font-mono">Compiler AI</span>
          </Link>

          <Link
            to="/security"
            className={`px-3.5 py-2 rounded-lg text-xs font-medium flex items-center gap-2 transition-colors ${
              isActive('/security')
                ? 'bg-indigo-50 text-indigo-700 font-semibold'
                : 'text-slate-500 hover:text-slate-800 hover:bg-slate-50'
            }`}
          >
            <ShieldAlert className="w-4 h-4" />
            <span className="hidden md:inline">Security</span>
          </Link>

          <Link
            to="/compiler"
            className={`px-3.5 py-2 rounded-lg text-xs font-medium flex items-center gap-2 transition-colors ${
              isActive('/compiler')
                ? 'bg-indigo-50 text-indigo-700 font-semibold'
                : 'text-slate-500 hover:text-slate-800 hover:bg-slate-50'
            }`}
          >
            <Cpu className="w-4 h-4" />
            <span className="hidden md:inline">Compiler Lab</span>
          </Link>

          <Link
            to="/profile"
            className={`px-3.5 py-2 rounded-lg text-xs font-medium flex items-center gap-2 transition-colors ${
              isActive('/profile')
                ? 'bg-indigo-50 text-indigo-700 font-semibold'
                : 'text-slate-500 hover:text-slate-800 hover:bg-slate-50'
            }`}
          >
            <User className="w-4 h-4" />
            <span className="hidden md:inline">{profile?.fullName.split(' ')[0] || 'Profile'}</span>
          </Link>

          {user ? (
            <button
              onClick={() => logoutUser()}
              className="p-2 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-lg transition-colors ml-1"
              title="Log Out"
            >
              <LogOut className="w-4 h-4" />
            </button>
          ) : (
            <div className="flex items-center gap-2 ml-2">
              <Link
                to="/login"
                className="px-3 py-1.5 bg-white hover:bg-slate-50 text-slate-700 border border-slate-200 rounded-lg text-xs font-semibold transition-colors shadow-sm"
              >
                Sign In
              </Link>
              <Link
                to="/register"
                className="px-3 py-1.5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-lg text-xs font-semibold transition-colors shadow-sm shadow-indigo-200"
              >
                Register
              </Link>
            </div>
          )}
        </nav>
      </div>
    </header>
  );
}

function ProtectedRoute({ children }: { children: React.ReactNode }) {
  return <>{children}</>;
}

function AppContent() {
  const { profile } = useAuth();

  return (
    <BrowserRouter>
      <div className="min-h-screen bg-slate-50 text-slate-800 font-sans selection:bg-indigo-500/20 selection:text-indigo-900">
        {!isFirebaseConfigured && <FirebaseMissingAlert />}

        <NavigationHeader />

        <Routes>
          <Route path="/" element={<Landing />} />
          <Route path="/login" element={<Login />} />
          <Route path="/register" element={<Register />} />
          <Route path="/compiler" element={<CompilerLab />} />
          <Route path="/chatbot" element={<ChatbotPage />} />

          <Route
            path="/chat"
            element={
              <ProtectedRoute>
                {profile ? (
                  <Chat currentProfile={profile} />
                ) : (
                  <div className="p-12 text-center text-xs text-slate-500 font-mono animate-pulse">
                    Loading profile details...
                  </div>
                )}
              </ProtectedRoute>
            }
          />

          <Route
            path="/security"
            element={
              <ProtectedRoute>
                {profile ? (
                  <Security currentProfile={profile} />
                ) : (
                  <div className="p-12 text-center text-xs text-slate-500 font-mono animate-pulse">
                    Loading profile details...
                  </div>
                )}
              </ProtectedRoute>
            }
          />

          <Route
            path="/profile"
            element={
              <ProtectedRoute>
                {profile ? (
                  <Profile profile={profile} />
                ) : (
                  <div className="p-12 text-center text-xs text-slate-500 font-mono animate-pulse">
                    Loading profile details...
                  </div>
                )}
              </ProtectedRoute>
            }
          />

          <Route path="*" element={<Navigate to="/" replace />} />
        </Routes>

        {/* Global Multi-Turn Gemini Chatbot */}
        <FloatingChatbot />
      </div>
    </BrowserRouter>
  );
}

export default function App() {
  return (
    <AuthProvider>
      <AppContent />
    </AuthProvider>
  );
}
