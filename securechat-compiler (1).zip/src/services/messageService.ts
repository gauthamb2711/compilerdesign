import { ref, push, set, onValue, update, get } from 'firebase/database';
import { compileMessage } from '../compiler/compiler';
import { rtdb } from '../lib/firebase';
import { ChatMessage } from '../types';

/**
 * Recursively removes all undefined fields from an object so Firebase RTDB set/update never fails.
 */
function sanitizeForFirebase<T>(data: T): T {
  if (data === undefined) {
    return null as unknown as T;
  }
  if (data === null || typeof data !== 'object') {
    return data;
  }
  if (Array.isArray(data)) {
    return data.map((item) => sanitizeForFirebase(item)) as unknown as T;
  }
  const cleaned: Record<string, any> = {};
  for (const [key, value] of Object.entries(data)) {
    if (value !== undefined) {
      cleaned[key] = sanitizeForFirebase(value);
    }
  }
  return cleaned as T;
}

export async function sendMessage(
  conversationId: string,
  senderId: string,
  receiverId: string,
  rawText: string
): Promise<ChatMessage> {
  const text = rawText.trim();
  if (!text) {
    throw new Error('Message text cannot be empty.');
  }

  const timestamp = Date.now();
  // Execute 6-Phase Compiler Pipeline!
  const compilerAnalysis = compileMessage(text);

  const messagesRef = ref(rtdb, `messages/${conversationId}`);
  const newMessageRef = push(messagesRef);
  const messageId = newMessageRef.key || 'msg_' + Math.random().toString(36).substring(2, 11);
  const createdAt = new Date(timestamp).toISOString();

  const rawMessageData = {
    id: messageId,
    conversationId,
    senderId,
    receiverId,
    text,
    originalText: text,
    processedText: compilerAnalysis.processedText,
    classification: compilerAnalysis.classification,
    riskScore: compilerAnalysis.riskScore,
    threatLevel: compilerAnalysis.threatLevel,
    hasUrl: compilerAnalysis.lexical.urls.length > 0,
    removedUrls: compilerAnalysis.optimization.removedUrls,
    compilerAnalysis,
    status: 'SENT',
    read: false,
    timestamp,
    createdAt
  };

  const messageData = sanitizeForFirebase(rawMessageData);

  try {
    // 1. Save Message to messages/{conversationId}/{messageId}
    await set(newMessageRef, messageData);

    // Also write to conversations/{conversationId}/messages/{messageId} for backwards compatibility
    await set(ref(rtdb, `conversations/${conversationId}/messages/${messageId}`), messageData);

    // 2. Update Conversation's lastMessage and updatedAt in conversations/{conversationId}
    const convRef = ref(rtdb, `conversations/${conversationId}`);
    const convSnap = await get(convRef);
    let currentUnread = 0;
    if (convSnap.exists()) {
      const data = convSnap.val();
      currentUnread = data.unreadCount?.[receiverId] || 0;
    }

    await update(convRef, {
      lastMessage: compilerAnalysis.processedText || text,
      updatedAt: timestamp,
      lastMessageAt: createdAt,
      [`unreadCount/${receiverId}`]: currentUnread + 1
    });

    return messageData as unknown as ChatMessage;
  } catch (err: any) {
    console.error('[Firebase Error] Error sending message:', err);
    throw err;
  }
}

export function subscribeToMessages(
  conversationId: string,
  callback: (messages: ChatMessage[]) => void
): () => void {
  const rootMessagesRef = ref(rtdb, `messages/${conversationId}`);

  const unsubscribe = onValue(
    rootMessagesRef,
    (snapshot) => {
      const listMap = new Map<string, ChatMessage>();

      if (snapshot.exists()) {
        const val = snapshot.val();
        Object.keys(val).forEach((key) => {
          const item = val[key];
          listMap.set(key, {
            id: item.id || key,
            conversationId: item.conversationId || conversationId,
            senderId: item.senderId,
            receiverId: item.receiverId,
            originalText: item.originalText || item.text || '',
            processedText: item.processedText || item.text || '',
            classification: item.classification || 'SAFE',
            riskScore: item.riskScore || 0,
            threatLevel: item.threatLevel || 'LOW',
            hasUrl: item.hasUrl || false,
            removedUrls: item.removedUrls || [],
            compilerAnalysis: item.compilerAnalysis || null,
            status: item.read ? 'SEEN' : item.status || 'SENT',
            createdAt:
              item.createdAt ||
              (item.timestamp ? new Date(item.timestamp).toISOString() : new Date().toISOString())
          } as ChatMessage);
        });
      }

      // Check fallback location conversations/{conversationId}/messages as well
      get(ref(rtdb, `conversations/${conversationId}/messages`)).then((convMsgsSnap) => {
        if (convMsgsSnap.exists()) {
          const cVal = convMsgsSnap.val();
          Object.keys(cVal).forEach((key) => {
            if (!listMap.has(key)) {
              const item = cVal[key];
              listMap.set(key, {
                id: item.id || key,
                conversationId: item.conversationId || conversationId,
                senderId: item.senderId,
                receiverId: item.receiverId,
                originalText: item.originalText || item.text || '',
                processedText: item.processedText || item.text || '',
                classification: item.classification || 'SAFE',
                riskScore: item.riskScore || 0,
                threatLevel: item.threatLevel || 'LOW',
                hasUrl: item.hasUrl || false,
                removedUrls: item.removedUrls || [],
                compilerAnalysis: item.compilerAnalysis || null,
                status: item.read ? 'SEEN' : item.status || 'SENT',
                createdAt:
                  item.createdAt ||
                  (item.timestamp ? new Date(item.timestamp).toISOString() : new Date().toISOString())
              } as ChatMessage);
            }
          });
        }

        const list = Array.from(listMap.values());
        list.sort((a, b) => {
          const tA = new Date(a.createdAt || 0).getTime();
          const tB = new Date(b.createdAt || 0).getTime();
          return tA - tB;
        });

        callback(list);
      });
    },
    (err) => {
      console.error('[Firebase Error] Error listening to messages:', err);
    }
  );

  return unsubscribe;
}

export async function markMessagesAsSeen(
  conversationId: string,
  currentUserId: string,
  messages: ChatMessage[]
): Promise<void> {
  const unseenMessages = messages.filter(
    (m) => m.receiverId === currentUserId && m.status !== 'SEEN'
  );

  if (unseenMessages.length === 0) return;

  const updates: Record<string, any> = {};
  unseenMessages.forEach((m) => {
    updates[`messages/${conversationId}/${m.id}/status`] = 'SEEN';
    updates[`messages/${conversationId}/${m.id}/read`] = true;
    updates[`conversations/${conversationId}/messages/${m.id}/status`] = 'SEEN';
    updates[`conversations/${conversationId}/messages/${m.id}/read`] = true;
  });

  try {
    await update(ref(rtdb), updates);
  } catch (err) {
    console.error('[Firebase Error] Error marking messages as seen:', err);
  }
}


