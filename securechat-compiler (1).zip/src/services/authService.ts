import {
  createUserWithEmailAndPassword,
  onAuthStateChanged,
  sendPasswordResetEmail,
  signInWithEmailAndPassword,
  signOut,
  User,
  Unsubscribe
} from 'firebase/auth';
import { ref, set, get, update } from 'firebase/database';
import { auth, rtdb } from '../lib/firebase';
import { UserProfile } from '../types';

export function subscribeToAuthChanges(callback: (user: User | null) => void): Unsubscribe {
  return onAuthStateChanged(auth, callback);
}

export async function registerUser(
  fullName: string,
  email: string,
  phone: string,
  password: string
): Promise<UserProfile> {
  const emailNorm = email.toLowerCase().trim();
  const phoneNorm = phone.replace(/\D/g, '');

  console.log('[Firebase Auth] Registering new user:', emailNorm);

  let userCredential;
  try {
    userCredential = await createUserWithEmailAndPassword(auth, emailNorm, password);
  } catch (err: any) {
    console.error('[Firebase Auth Error] Registration failed:', err);
    throw err;
  }

  const user = userCredential.user;
  const uid = user.uid;
  const createdAt = new Date().toISOString();
  const avatarUrl = `https://api.dicebear.com/7.x/avataaars/svg?seed=${encodeURIComponent(uid)}`;

  const profileData = {
    uid,
    fullName: fullName.trim(),
    email: emailNorm,
    phoneNumber: phone.trim(),
    phone: phone.trim(),
    emailNormalized: emailNorm,
    phoneNormalized: phoneNorm,
    avatarUrl,
    online: true,
    lastSeen: createdAt,
    createdAt
  };

  console.log(`[Firebase RTDB] Saving user profile to users/${uid}...`);
  try {
    await set(ref(rtdb, `users/${uid}`), profileData);
    console.log(`[Firebase RTDB] Successfully saved user profile to users/${uid}`);
  } catch (rtdbErr: any) {
    console.error('[Firebase RTDB Error] Failed to save user profile:', rtdbErr);
  }

  return profileData as UserProfile;
}

export async function loginUser(email: string, password: string): Promise<UserProfile> {
  const emailNorm = email.toLowerCase().trim();
  console.log('[Firebase Auth] Logging in user:', emailNorm);

  let credential;
  try {
    credential = await signInWithEmailAndPassword(auth, emailNorm, password);
  } catch (err: any) {
    console.error('[Firebase Auth Error] Login failed:', err);
    throw err;
  }

  const uid = credential.user.uid;
  const now = new Date().toISOString();

  try {
    await update(ref(rtdb, `users/${uid}`), {
      online: true,
      lastSeen: now
    });
  } catch (rtdbErr: any) {
    console.warn('[Firebase RTDB Warning] Could not update presence on login:', rtdbErr);
  }

  const profile = await getUserProfile(uid);
  if (!profile) {
    const fallbackProf: UserProfile = {
      uid,
      fullName: credential.user.displayName || emailNorm.split('@')[0] || 'User',
      email: emailNorm,
      phone: '',
      emailNormalized: emailNorm,
      phoneNormalized: '',
      avatarUrl: `https://api.dicebear.com/7.x/avataaars/svg?seed=${encodeURIComponent(uid)}`,
      online: true,
      lastSeen: now,
      createdAt: now
    };

    try {
      await set(ref(rtdb, `users/${uid}`), fallbackProf);
    } catch (e) {}

    return fallbackProf;
  }

  return profile;
}

export async function logoutUser(userId?: string): Promise<void> {
  const uid = userId || auth.currentUser?.uid;
  if (uid) {
    const now = new Date().toISOString();
    try {
      await update(ref(rtdb, `users/${uid}`), {
        online: false,
        lastSeen: now
      });
    } catch (e) {}
  }
  await signOut(auth);
}

export async function resetPassword(email: string): Promise<void> {
  try {
    await sendPasswordResetEmail(auth, email.toLowerCase().trim());
  } catch (err: any) {
    console.error('[Firebase Auth Error] Password reset failed:', err);
    throw err;
  }
}

export async function getUserProfile(uid: string): Promise<UserProfile | null> {
  try {
    const userRef = ref(rtdb, `users/${uid}`);
    const snapshot = await get(userRef);
    if (snapshot.exists()) {
      const data = snapshot.val();
      return {
        uid: data.uid || uid,
        fullName: data.fullName || '',
        email: data.email || '',
        phone: data.phoneNumber || data.phone || '',
        emailNormalized: data.emailNormalized || (data.email ? data.email.toLowerCase() : ''),
        phoneNormalized: data.phoneNormalized || (data.phoneNumber ? data.phoneNumber.replace(/\D/g, '') : ''),
        avatarUrl: data.avatarUrl || `https://api.dicebear.com/7.x/avataaars/svg?seed=${encodeURIComponent(uid)}`,
        online: data.online ?? true,
        lastSeen: data.lastSeen || new Date().toISOString(),
        createdAt: data.createdAt || new Date().toISOString()
      };
    }
  } catch (err: any) {
    console.error('[Firebase RTDB Error] Error reading user profile:', err);
  }

  return null;
}

