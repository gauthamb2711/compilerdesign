import { ref, get, set, onValue, update } from 'firebase/database';
import { rtdb } from '../lib/firebase';
import { Conversation, UserProfile, ConversationParticipant } from '../types';
import { getUserProfile } from './authService';

export function getDeterministicConversationId(uid1: string, uid2: string): string {
  return [uid1, uid2].sort().join('_');
}

export async function getOrCreateConversation(
  currentUserInput: UserProfile | string,
  partnerUserInput: UserProfile | string
): Promise<Conversation> {
  const currentUid = typeof currentUserInput === 'string' ? currentUserInput : currentUserInput?.uid;
  const partnerUid = typeof partnerUserInput === 'string' ? partnerUserInput : partnerUserInput?.uid;

  if (!currentUid || !partnerUid) {
    throw new Error('User ID is required to start a conversation.');
  }

  if (currentUid === partnerUid) {
    throw new Error('You cannot start a conversation with yourself.');
  }

  // Retrieve user profiles for metadata/UI rendering
  let currentUser: UserProfile | null = typeof currentUserInput === 'object' ? currentUserInput : null;
  if (!currentUser) {
    currentUser = await getUserProfile(currentUid);
  }

  let partnerUser: UserProfile | null = typeof partnerUserInput === 'object' ? partnerUserInput : null;
  if (!partnerUser) {
    partnerUser = await getUserProfile(partnerUid);
  }

  const convId = getDeterministicConversationId(currentUid, partnerUid);
  const convRef = ref(rtdb, `conversations/${convId}`);

  try {
    const snapshot = await get(convRef);

    const participantsMap: Record<string, ConversationParticipant> = {};
    if (currentUser) {
      participantsMap[currentUser.uid] = {
        uid: currentUser.uid,
        fullName: currentUser.fullName || 'User',
        email: currentUser.email || '',
        phone: currentUser.phone || '',
        avatarUrl: currentUser.avatarUrl || '',
        online: currentUser.online ?? true
      };
    }
    if (partnerUser) {
      participantsMap[partnerUser.uid] = {
        uid: partnerUser.uid,
        fullName: partnerUser.fullName || 'User',
        email: partnerUser.email || '',
        phone: partnerUser.phone || '',
        avatarUrl: partnerUser.avatarUrl || '',
        online: partnerUser.online ?? false
      };
    }

    if (snapshot.exists()) {
      const val = snapshot.val();
      const existingDetails = val.participantDetails || val.participants || {};
      const renderedParticipants =
        typeof existingDetails === 'object' &&
        !('true' in existingDetails) &&
        Object.values(existingDetails).some((p) => typeof p === 'object' && p !== null && 'fullName' in p)
          ? existingDetails
          : participantsMap;

      return {
        id: val.id || convId,
        participantIds: val.participantIds || [currentUid, partnerUid],
        participants: renderedParticipants,
        lastMessage: val.lastMessage || '',
        lastMessageType: val.lastMessageType || 'SAFE',
        lastMessageAt: val.lastMessageAt || new Date(val.updatedAt || Date.now()).toISOString(),
        unreadCount: val.unreadCount || { [currentUid]: 0, [partnerUid]: 0 },
        createdAt: val.createdAt || Date.now(),
        updatedAt: val.updatedAt || Date.now()
      } as Conversation;
    }

    // Create new conversation adhering strictly to the specified structure
    const now = Date.now();
    const newConversationData = {
      id: convId,
      participants: {
        [currentUid]: true,
        [partnerUid]: true
      },
      participantIds: [currentUid, partnerUid],
      participantDetails: participantsMap,
      createdAt: now,
      updatedAt: now,
      lastMessage: '',
      lastMessageAt: new Date(now).toISOString(),
      unreadCount: {
        [currentUid]: 0,
        [partnerUid]: 0
      }
    };

    await set(convRef, newConversationData);

    return {
      id: convId,
      participantIds: [currentUid, partnerUid],
      participants: participantsMap,
      lastMessage: '',
      lastMessageType: 'SAFE',
      lastMessageAt: new Date(now).toISOString(),
      unreadCount: { [currentUid]: 0, [partnerUid]: 0 },
      createdAt: now,
      updatedAt: now
    } as Conversation;
  } catch (err: any) {
    console.error('[Firebase Error] Failed to get or create conversation:', err);
    throw err;
  }
}

export function subscribeToUserConversations(
  userId: string,
  callback: (conversations: Conversation[]) => void
): () => void {
  const convsRef = ref(rtdb, 'conversations');

  const unsubscribe = onValue(
    convsRef,
    async (snapshot) => {
      if (!snapshot.exists()) {
        callback([]);
        return;
      }

      const val = snapshot.val();
      const listPromises = Object.keys(val).map(async (key) => {
        const conv = val[key];
        const isParticipant =
          (conv.participants && conv.participants[userId] !== undefined) ||
          (Array.isArray(conv.participantIds) && conv.participantIds.includes(userId)) ||
          key.split('_').includes(userId);

        if (!isParticipant) return null;

        const participantIds: string[] = conv.participantIds || key.split('_');
        const partnerId = participantIds.find((id) => id !== userId) || userId;

        let participantsMap: Record<string, ConversationParticipant> = conv.participantDetails || {};

        if (!participantsMap[partnerId] || !participantsMap[userId]) {
          const partnerProfile = await getUserProfile(partnerId);
          const userProfile = await getUserProfile(userId);

          participantsMap = {
            ...participantsMap,
            [userId]: {
              uid: userId,
              fullName: userProfile?.fullName || 'You',
              email: userProfile?.email || '',
              phone: userProfile?.phone || '',
              avatarUrl: userProfile?.avatarUrl || ''
            },
            [partnerId]: {
              uid: partnerId,
              fullName: partnerProfile?.fullName || 'User',
              email: partnerProfile?.email || '',
              phone: partnerProfile?.phone || '',
              avatarUrl: partnerProfile?.avatarUrl || ''
            }
          };
        }

        return {
          id: conv.id || key,
          participantIds,
          participants: participantsMap,
          lastMessage: conv.lastMessage || '',
          lastMessageType: conv.lastMessageType || 'SAFE',
          lastMessageAt:
            conv.lastMessageAt ||
            (conv.updatedAt ? new Date(conv.updatedAt).toISOString() : new Date().toISOString()),
          unreadCount: conv.unreadCount || {},
          createdAt: conv.createdAt || Date.now(),
          updatedAt: conv.updatedAt || Date.now()
        } as Conversation;
      });

      const resolved = (await Promise.all(listPromises)).filter((c): c is Conversation => c !== null);
      resolved.sort((a, b) => {
        const tA = typeof a.updatedAt === 'number' ? a.updatedAt : new Date(a.lastMessageAt || 0).getTime();
        const tB = typeof b.updatedAt === 'number' ? b.updatedAt : new Date(b.lastMessageAt || 0).getTime();
        return tB - tA;
      });

      callback(resolved);
    },
    (err) => {
      console.error('[Firebase Error] Listening to conversations failed:', err);
    }
  );

  return unsubscribe;
}

export const listenToUserConversations = subscribeToUserConversations;

export async function resetUnreadCount(conversationId: string, userId: string): Promise<void> {
  if (!conversationId || !userId) return;
  const convRef = ref(rtdb, `conversations/${conversationId}/unreadCount`);
  try {
    await update(convRef, {
      [userId]: 0
    });
  } catch (err) {
    console.error('[Firebase Error] Error resetting unread count:', err);
  }
}


