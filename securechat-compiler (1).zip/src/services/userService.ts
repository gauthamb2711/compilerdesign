import { ref, get } from 'firebase/database';
import { rtdb } from '../lib/firebase';
import { UserProfile } from '../types';

export async function searchUserByEmailOrPhone(
  searchQuery: string,
  currentUserId: string
): Promise<UserProfile | null> {
  if (!searchQuery || !searchQuery.trim()) return null;

  const rawQuery = searchQuery.trim();
  const normalizedEmail = rawQuery.toLowerCase();
  const normalizedPhone = rawQuery.replace(/\D/g, '');

  try {
    const usersRef = ref(rtdb, 'users');
    const snapshot = await get(usersRef);

    if (!snapshot.exists()) {
      return null;
    }

    const usersData = snapshot.val();
    let foundProfile: UserProfile | null = null;

    for (const uid of Object.keys(usersData)) {
      if (uid === currentUserId) continue;

      const user = usersData[uid];
      const userEmail = (user.email || '').toLowerCase();
      const userEmailNorm = (user.emailNormalized || userEmail).toLowerCase();
      const userPhone = user.phoneNumber || user.phone || '';
      const userPhoneNorm = user.phoneNormalized || userPhone.replace(/\D/g, '');

      if (
        userEmailNorm === normalizedEmail ||
        userEmail === normalizedEmail ||
        (normalizedPhone && userPhoneNorm === normalizedPhone) ||
        userPhone === rawQuery
      ) {
        foundProfile = {
          uid: user.uid || uid,
          fullName: user.fullName || '',
          email: user.email || '',
          phone: user.phoneNumber || user.phone || '',
          emailNormalized: userEmailNorm,
          phoneNormalized: userPhoneNorm,
          avatarUrl: user.avatarUrl || `https://api.dicebear.com/7.x/avataaars/svg?seed=${encodeURIComponent(uid)}`,
          online: user.online ?? false,
          lastSeen: user.lastSeen || new Date().toISOString(),
          createdAt: user.createdAt || new Date().toISOString()
        };
        break;
      }
    }

    return foundProfile;
  } catch (err) {
    console.error('Error searching user in Realtime Database:', err);
    return null;
  }
}

