import { ref, set, onValue, update } from 'firebase/database';
import { rtdb } from '../lib/firebase';

export async function setTypingStatus(
  conversationId: string,
  userId: string,
  isTyping: boolean
): Promise<void> {
  if (!conversationId || !userId) return;
  const typingRef = ref(rtdb, `typing/${conversationId}/${userId}`);

  try {
    await set(typingRef, {
      conversationId,
      userId,
      isTyping,
      updatedAt: new Date().toISOString()
    });
  } catch (err) {
    console.error('Error setting typing status:', err);
  }
}

export function subscribeToTypingStatus(
  conversationId: string,
  currentUserId: string,
  callback: (isTyping: boolean) => void
): () => void {
  const typingRef = ref(rtdb, `typing/${conversationId}`);

  const unsubscribe = onValue(typingRef, (snapshot) => {
    let someoneElseTyping = false;
    const now = Date.now();

    if (snapshot.exists()) {
      const val = snapshot.val();
      Object.keys(val).forEach((uid) => {
        if (uid !== currentUserId) {
          const data = val[uid];
          if (data && data.isTyping) {
            const updatedTime = new Date(data.updatedAt || 0).getTime();
            if (now - updatedTime < 5000) {
              someoneElseTyping = true;
            }
          }
        }
      });
    }

    callback(someoneElseTyping);
  });

  return unsubscribe;
}

export function initUserPresence(userId: string) {
  if (!userId) return () => {};

  const userRef = ref(rtdb, `users/${userId}`);

  update(userRef, {
    online: true,
    lastSeen: new Date().toISOString()
  }).catch(() => {});

  const handleUnload = () => {
    update(userRef, {
      online: false,
      lastSeen: new Date().toISOString()
    }).catch(() => {});
  };

  window.addEventListener('beforeunload', handleUnload);

  return () => {
    window.removeEventListener('beforeunload', handleUnload);
    update(userRef, {
      online: false,
      lastSeen: new Date().toISOString()
    }).catch(() => {});
  };
}

