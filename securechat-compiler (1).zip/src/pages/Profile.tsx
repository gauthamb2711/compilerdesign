import React from 'react';
import { Mail, Phone, Calendar, ShieldCheck, LogOut } from 'lucide-react';
import { useAuth } from '../hooks/useAuth';
import { Avatar } from '../components/common/Avatar';
import { useNavigate } from 'react-router-dom';

import { UserProfile } from '../types';

interface ProfileProps {
  profile?: UserProfile;
  onNavigate?: (route: string) => void;
}

export const ProfilePage: React.FC<ProfileProps> = ({ onNavigate }) => {
  const { profile, logout } = useAuth();
  const navigate = useNavigate();

  const handleLogout = async () => {
    await logout();
    if (onNavigate) {
      onNavigate('/');
    } else {
      navigate('/');
    }
  };

  return (
    <div className="min-h-screen bg-slate-50 text-slate-800 flex flex-col font-sans">
      <main className="flex-1 max-w-3xl w-full mx-auto p-4 lg:p-8 space-y-6">
        <div className="p-8 bg-white border border-slate-200/80 rounded-3xl shadow-sm relative overflow-hidden">
          <div className="flex flex-col sm:flex-row items-center gap-6">
            <Avatar
              name={profile?.fullName || 'User'}
              avatarUrl={profile?.avatarUrl}
              online={true}
              size="xl"
            />

            <div className="text-center sm:text-left space-y-1">
              <h2 className="text-2xl font-bold text-slate-900">{profile?.fullName}</h2>
              <p className="text-sm text-indigo-600 font-mono font-medium">{profile?.email}</p>
              <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-indigo-50 border border-indigo-200 text-indigo-700 text-xs font-semibold mt-2">
                <ShieldCheck className="w-3.5 h-3.5 text-indigo-600" /> Verified Secure Member
              </div>
            </div>
          </div>
        </div>

        <div className="p-6 bg-white border border-slate-200/80 rounded-3xl shadow-sm space-y-4">
          <h3 className="text-xs font-bold text-slate-400 uppercase tracking-wider">
            Account Identity & Search Settings
          </h3>

          <div className="space-y-3 text-xs">
            <div className="p-4 bg-slate-50 rounded-2xl border border-slate-200/60 flex items-center justify-between">
              <span className="text-slate-500 font-medium flex items-center gap-2">
                <Mail className="w-4 h-4 text-indigo-600" /> Primary Email
              </span>
              <span className="text-slate-800 font-semibold">{profile?.email}</span>
            </div>

            <div className="p-4 bg-slate-50 rounded-2xl border border-slate-200/60 flex items-center justify-between">
              <span className="text-slate-500 font-medium flex items-center gap-2">
                <Phone className="w-4 h-4 text-indigo-600" /> Registered Phone
              </span>
              <span className="text-slate-800 font-semibold">{profile?.phone || 'Not set'}</span>
            </div>

            <div className="p-4 bg-slate-50 rounded-2xl border border-slate-200/60 flex items-center justify-between">
              <span className="text-slate-500 font-medium flex items-center gap-2">
                <Calendar className="w-4 h-4 text-indigo-600" /> Account Created
              </span>
              <span className="text-slate-800 font-semibold">
                {profile?.createdAt ? new Date(profile.createdAt).toLocaleDateString() : 'N/A'}
              </span>
            </div>
          </div>
        </div>

        <div className="pt-2 flex justify-end">
          <button
            onClick={handleLogout}
            className="px-6 py-3 bg-rose-50 hover:bg-rose-100 text-rose-700 border border-rose-200 rounded-2xl text-xs font-bold flex items-center gap-2 transition-all shadow-sm"
          >
            <LogOut className="w-4 h-4" /> Sign Out
          </button>
        </div>
      </main>
    </div>
  );
};

export const Profile = ProfilePage;
