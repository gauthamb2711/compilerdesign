import React, { useEffect, useRef, useState } from 'react';
import {
  Check,
  CheckCheck,
  MessageSquare,
  Plus,
  Search,
  Send,
  Shield,
  ShieldAlert,
  Smile,
  Terminal
} from 'lucide-react';
import { SecurityBadge } from '../components/common/SecurityBadge';
import { CompilerAnalysisPanel } from '../components/chat/CompilerAnalysisPanel';
import { NewChatModal } from '../components/chat/NewChatModal';
import { useConversations } from '../hooks/useConversations';
import { useMessages } from '../hooks/useMessages';
import { getOrCreateConversation } from '../services/conversationService';
import { sendMessage } from '../services/messageService';
import { setTypingStatus } from '../services/presenceService';
import { ChatMessage, Conversation, UserProfile } from '../types';

interface ChatProps {
  currentProfile: UserProfile;
}

export const Chat: React.FC<ChatProps> = ({ currentProfile }) => {
  const [activeConv, setActiveConv] = useState<Conversation | null>(null);
  const [selectedMessage, setSelectedMessage] = useState<ChatMessage | null>(null);
  const [showRightPanel, setShowRightPanel] = useState<boolean>(true);
  const [isNewChatOpen, setIsNewChatOpen] = useState<boolean>(false);
  const [searchFilter, setSearchFilter] = useState<string>('');

  const [inputMessage, setInputMessage] = useState<string>('');
  const [isSending, setIsSending] = useState<boolean>(false);
  const [showEmojiPicker, setShowEmojiPicker] = useState<boolean>(false);

  const messagesEndRef = useRef<HTMLDivElement>(null);
  const typingTimeoutRef = useRef<NodeJS.Timeout | null>(null);

  const { conversations, loading: convsLoading } = useConversations(currentProfile.uid);

  const partnerId = activeConv?.participantIds.find((id) => id !== currentProfile.uid);
  const partnerParticipant = partnerId && activeConv?.participants ? activeConv.participants[partnerId] : null;

  const { messages, loading: msgsLoading, partnerIsTyping } = useMessages(
    activeConv?.id,
    currentProfile.uid,
    partnerId
  );

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, partnerIsTyping]);

  useEffect(() => {
    if (!activeConv && conversations.length > 0) {
      setActiveConv(conversations[0]);
    }
  }, [conversations, activeConv]);

  useEffect(() => {
    if (messages.length > 0 && !selectedMessage) {
      setSelectedMessage(messages[messages.length - 1]);
    }
  }, [messages, selectedMessage]);

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = e.target.value;
    setInputMessage(value);

    if (activeConv) {
      setTypingStatus(activeConv.id, currentProfile.uid, true);

      if (typingTimeoutRef.current) clearTimeout(typingTimeoutRef.current);

      typingTimeoutRef.current = setTimeout(() => {
        setTypingStatus(activeConv.id, currentProfile.uid, false);
      }, 2500);
    }
  };

  const handleSendMessage = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputMessage.trim() || !activeConv || !partnerId || isSending) return;

    const rawText = inputMessage.trim();
    setInputMessage('');
    setIsSending(true);

    if (typingTimeoutRef.current) clearTimeout(typingTimeoutRef.current);
    setTypingStatus(activeConv.id, currentProfile.uid, false);

    try {
      const sentMsg = await sendMessage(activeConv.id, currentProfile.uid, partnerId, rawText);
      setSelectedMessage(sentMsg);
    } catch (err) {
      console.error('Failed to send message:', err);
    } finally {
      setIsSending(false);
    }
  };

  const handleStartChatWithUser = async (partnerUser: UserProfile) => {
    try {
      const conv = await getOrCreateConversation(currentProfile, partnerUser);
      setActiveConv(conv);
    } catch (err) {
      console.error('[Firebase Error] Error starting conversation in Chat.tsx:', err);
      throw err;
    }
  };

  const filteredConversations = conversations.filter((conv) => {
    if (!searchFilter.trim()) return true;
    const pId = conv.participantIds.find((id) => id !== currentProfile.uid);
    const p = pId ? conv.participants[pId] : null;
    if (!p) return false;
    const term = searchFilter.toLowerCase();
    return (
      p.fullName.toLowerCase().includes(term) ||
      p.email.toLowerCase().includes(term) ||
      p.phone?.toLowerCase().includes(term)
    );
  });

  const emojis = ['👍', '❤️', '⚠️', '🚨', '✅', '🔥', '🛡️', '😊', '🔒', '💻'];

  return (
    <div className="h-[calc(100vh-4rem)] bg-slate-950 flex flex-col md:flex-row text-slate-100 font-sans overflow-hidden">
      {/* LEFT SIDEBAR */}
      <div className="w-full md:w-80 lg:w-96 bg-slate-900/90 border-r border-slate-800/80 flex flex-col shrink-0">
        <div className="p-3.5 bg-slate-950 border-b border-slate-800/80 flex items-center justify-between">
          <div className="flex items-center gap-2.5 min-w-0">
            <div className="relative shrink-0">
              <img
                src={currentProfile.avatarUrl}
                alt={currentProfile.fullName}
                className="w-9 h-9 rounded-full bg-slate-800 border border-slate-700"
              />
              <span className="w-2.5 h-2.5 bg-emerald-500 rounded-full border-2 border-slate-950 absolute bottom-0 right-0" />
            </div>
            <div className="min-w-0">
              <h3 className="text-xs font-semibold text-slate-100 truncate">
                {currentProfile.fullName}
              </h3>
              <p className="text-[10px] text-slate-400 font-mono truncate">
                {currentProfile.email}
              </p>
            </div>
          </div>

          <button
            onClick={() => setIsNewChatOpen(true)}
            className="p-2 bg-cyan-600 hover:bg-cyan-500 text-white rounded-xl flex items-center gap-1 text-xs font-medium transition-colors shadow-md shadow-cyan-950/40"
            title="Start New Chat"
          >
            <Plus className="w-4 h-4" />
            <span className="hidden sm:inline">New Chat</span>
          </button>
        </div>

        <div className="p-3 border-b border-slate-800/80">
          <div className="relative">
            <input
              type="text"
              placeholder="Search chats by name/email/phone..."
              value={searchFilter}
              onChange={(e) => setSearchFilter(e.target.value)}
              className="w-full pl-9 pr-3 py-2 bg-slate-950 border border-slate-800 rounded-xl text-xs text-slate-200 placeholder-slate-500 focus:outline-none focus:border-cyan-500"
            />
            <Search className="w-4 h-4 text-slate-500 absolute left-2.5 top-2.5" />
          </div>
        </div>

        <div className="flex-1 overflow-y-auto divide-y divide-slate-800/40">
          {convsLoading ? (
            <div className="p-6 text-center text-xs text-slate-500 animate-pulse">
              Loading conversations...
            </div>
          ) : filteredConversations.length === 0 ? (
            <div className="p-8 text-center text-slate-500 text-xs space-y-2">
              <MessageSquare className="w-8 h-8 text-slate-700 mx-auto" />
              <p>No active conversations found.</p>
              <button
                onClick={() => setIsNewChatOpen(true)}
                className="text-cyan-400 font-medium hover:underline text-xs"
              >
                + Find a user to chat
              </button>
            </div>
          ) : (
            filteredConversations.map((conv) => {
              const pId = conv.participantIds.find((id) => id !== currentProfile.uid);
              const partner = pId ? conv.participants[pId] : null;
              const isSelected = activeConv?.id === conv.id;
              const unread = conv.unreadCount?.[currentProfile.uid] || 0;

              return (
                <button
                  key={conv.id}
                  onClick={() => {
                    setActiveConv(conv);
                    setSelectedMessage(null);
                  }}
                  className={`w-full p-3.5 flex items-center gap-3 text-left transition-colors ${
                    isSelected ? 'bg-slate-800/80 border-l-4 border-cyan-500' : 'hover:bg-slate-800/40'
                  }`}
                >
                  <div className="relative shrink-0">
                    <img
                      src={partner?.avatarUrl || 'https://api.dicebear.com/7.x/bottts/svg?seed=user'}
                      alt={partner?.fullName || 'User'}
                      className="w-10 h-10 rounded-full bg-slate-800 border border-slate-700"
                    />
                    {partner?.online && (
                      <span className="w-3 h-3 bg-emerald-500 border-2 border-slate-900 rounded-full absolute bottom-0 right-0" />
                    )}
                  </div>

                  <div className="flex-1 min-w-0">
                    <div className="flex items-center justify-between mb-1">
                      <span className="text-xs font-semibold text-slate-200 truncate">
                        {partner?.fullName || 'Unknown User'}
                      </span>
                      {conv.lastMessageAt && (
                        <span className="text-[10px] text-slate-500 font-mono">
                          {new Date(
                            conv.lastMessageAt.toMillis ? conv.lastMessageAt.toMillis() : Date.now()
                          ).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                        </span>
                      )}
                    </div>

                    <div className="flex items-center justify-between">
                      <p className="text-xs text-slate-400 truncate max-w-[180px]">
                        {conv.lastMessage || 'No messages yet'}
                      </p>
                      {unread > 0 && (
                        <span className="w-5 h-5 rounded-full bg-cyan-500 text-slate-950 font-bold font-mono text-[10px] flex items-center justify-center shrink-0">
                          {unread}
                        </span>
                      )}
                    </div>
                  </div>
                </button>
              );
            })
          )}
        </div>
      </div>

      {/* CENTER CHAT PANEL */}
      <div className="flex-1 flex flex-col bg-slate-950 min-w-0">
        {activeConv && partnerParticipant ? (
          <>
            <div className="px-4 py-3 bg-slate-900/90 border-b border-slate-800/80 flex items-center justify-between shrink-0">
              <div className="flex items-center gap-3 min-w-0">
                <div className="relative shrink-0">
                  <img
                    src={partnerParticipant.avatarUrl}
                    alt={partnerParticipant.fullName}
                    className="w-10 h-10 rounded-full bg-slate-800 border border-slate-700"
                  />
                  {partnerParticipant.online && (
                    <span className="w-3 h-3 bg-emerald-500 border-2 border-slate-950 rounded-full absolute bottom-0 right-0" />
                  )}
                </div>
                <div className="min-w-0">
                  <h3 className="text-sm font-semibold text-slate-100 truncate">
                    {partnerParticipant.fullName}
                  </h3>
                  <p className="text-[11px] text-slate-400 font-mono truncate">
                    {partnerParticipant.email} • {partnerParticipant.online ? 'Online' : 'Offline'}
                  </p>
                </div>
              </div>

              <button
                onClick={() => setShowRightPanel(!showRightPanel)}
                className={`p-2 rounded-xl border transition-colors flex items-center gap-1.5 text-xs font-mono ${
                  showRightPanel
                    ? 'bg-cyan-500/10 text-cyan-400 border-cyan-500/30'
                    : 'bg-slate-900 text-slate-400 border-slate-800 hover:text-slate-200'
                }`}
                title="Toggle Compiler Inspector"
              >
                <Terminal className="w-4 h-4" />
                <span className="hidden sm:inline">Compiler Analysis</span>
              </button>
            </div>

            <div className="flex-1 overflow-y-auto p-4 space-y-4">
              {msgsLoading ? (
                <div className="text-center py-12 text-xs text-slate-500 animate-pulse">
                  Listening to real-time messages...
                </div>
              ) : messages.length === 0 ? (
                <div className="text-center py-16 text-slate-500 text-xs space-y-2">
                  <Shield className="w-10 h-10 text-cyan-500/30 mx-auto" />
                  <p className="font-semibold text-slate-300">Secure Channel Established</p>
                  <p className="text-slate-500 max-w-sm mx-auto">
                    Messages sent in this chat will pass through all 6 Compiler Design phases (Lexical, Syntax, Semantic, IR, Optimization, CodeGen).
                  </p>
                </div>
              ) : (
                messages.map((msg) => {
                  const isMe = msg.senderId === currentProfile.uid;
                  const isSelected = selectedMessage?.id === msg.id;

                  return (
                    <div
                      key={msg.id}
                      onClick={() => setSelectedMessage(msg)}
                      className={`flex flex-col cursor-pointer group ${
                        isMe ? 'items-end' : 'items-start'
                      }`}
                    >
                      <div
                        className={`max-w-xl rounded-2xl p-4 space-y-2 transition-all ${
                          isMe
                            ? 'bg-slate-900 border border-slate-800 text-slate-100 rounded-br-none'
                            : 'bg-slate-900/90 border border-slate-800 text-slate-100 rounded-bl-none'
                        } ${isSelected ? 'ring-2 ring-cyan-500/50 shadow-lg' : 'hover:border-slate-700'}`}
                      >
                        {msg.classification !== 'SAFE' && (
                          <div className="p-3 bg-rose-950/40 border border-rose-500/40 rounded-xl space-y-1.5">
                            <div className="flex items-center justify-between gap-2">
                              <span className="text-xs font-bold text-rose-300 font-mono flex items-center gap-1.5">
                                <ShieldAlert className="w-4 h-4 text-rose-400" />
                                {msg.classification} THREAT DETECTED
                              </span>
                              <SecurityBadge
                                classification={msg.classification}
                                riskScore={msg.riskScore}
                                threatLevel={msg.threatLevel}
                                size="sm"
                              />
                            </div>

                            {msg.removedUrls && msg.removedUrls.length > 0 && (
                              <p className="text-[11px] text-rose-200/90 font-mono">
                                ⚠ {msg.removedUrls.length} dangerous link(s) neutralized and replaced with [LINK REMOVED].
                              </p>
                            )}

                            <button
                              onClick={(e) => {
                                e.stopPropagation();
                                setSelectedMessage(msg);
                                setShowRightPanel(true);
                              }}
                              className="text-[11px] text-cyan-400 font-mono hover:underline block pt-1"
                            >
                              [View Compiler Analysis]
                            </button>
                          </div>
                        )}

                        <p className="text-sm leading-relaxed break-words font-sans">
                          {isMe ? msg.originalText : msg.processedText}
                        </p>

                        <div className="flex items-center justify-between text-[10px] text-slate-500 font-mono pt-1 border-t border-slate-800/40">
                          <button
                            onClick={(e) => {
                              e.stopPropagation();
                              setSelectedMessage(msg);
                              setShowRightPanel(true);
                            }}
                            className="hover:text-cyan-400 transition-colors flex items-center gap-1"
                          >
                            <Terminal className="w-3 h-3 text-cyan-500" />
                            <span>View Analysis</span>
                          </button>

                          <div className="flex items-center gap-1.5">
                            <span>
                              {msg.createdAt?.toMillis
                                ? new Date(msg.createdAt.toMillis()).toLocaleTimeString([], {
                                    hour: '2-digit',
                                    minute: '2-digit'
                                  })
                                : 'Just now'}
                            </span>

                            {isMe && (
                              <span className="text-slate-400">
                                {msg.status === 'SEEN' ? (
                                  <span className="text-cyan-400 flex items-center gap-0.5" title="Seen">
                                    <CheckCheck className="w-3.5 h-3.5" /> Seen
                                  </span>
                                ) : msg.status === 'DELIVERED' ? (
                                  <span className="text-slate-400 flex items-center gap-0.5" title="Delivered">
                                    <CheckCheck className="w-3.5 h-3.5" /> Delivered
                                  </span>
                                ) : (
                                  <span className="text-slate-500 flex items-center gap-0.5" title="Sent">
                                    <Check className="w-3.5 h-3.5" /> Sent
                                  </span>
                                )}
                              </span>
                            )}
                          </div>
                        </div>
                      </div>
                    </div>
                  );
                })
              )}

              {partnerIsTyping && (
                <div className="flex items-center gap-2 text-xs text-cyan-400 font-mono italic animate-pulse py-2">
                  <span className="w-2 h-2 rounded-full bg-cyan-400" />
                  <span>{partnerParticipant.fullName} is typing...</span>
                </div>
              )}

              <div ref={messagesEndRef} />
            </div>

            <div className="p-3 bg-slate-900/90 border-t border-slate-800/80 relative">
              {showEmojiPicker && (
                <div className="absolute bottom-full mb-2 left-4 p-2 bg-slate-900 border border-slate-800 rounded-xl shadow-xl flex gap-1 z-20">
                  {emojis.map((emoji) => (
                    <button
                      key={emoji}
                      onClick={() => {
                        setInputMessage((prev) => prev + emoji);
                        setShowEmojiPicker(false);
                      }}
                      className="p-1.5 hover:bg-slate-800 rounded text-base"
                    >
                      {emoji}
                    </button>
                  ))}
                </div>
              )}

              <form onSubmit={handleSendMessage} className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => setShowEmojiPicker(!showEmojiPicker)}
                  className="p-2.5 text-slate-400 hover:text-slate-200 hover:bg-slate-800 rounded-xl transition-colors"
                >
                  <Smile className="w-5 h-5" />
                </button>

                <input
                  type="text"
                  placeholder="Type a message to compile and send..."
                  value={inputMessage}
                  onChange={handleInputChange}
                  className="flex-1 px-4 py-2.5 bg-slate-950 border border-slate-800 rounded-xl text-sm text-slate-100 placeholder-slate-500 focus:outline-none focus:border-cyan-500"
                />

                <button
                  type="submit"
                  disabled={!inputMessage.trim() || isSending}
                  className="p-2.5 bg-cyan-600 hover:bg-cyan-500 disabled:bg-slate-800 text-white rounded-xl transition-colors shadow-md shadow-cyan-950/40"
                >
                  <Send className="w-5 h-5" />
                </button>
              </form>
            </div>
          </>
        ) : (
          <div className="flex-1 flex flex-col items-center justify-center p-8 text-center text-slate-500 space-y-3">
            <MessageSquare className="w-12 h-12 text-slate-700" />
            <h3 className="text-base font-semibold text-slate-300">Select or Start a Chat</h3>
            <p className="text-xs text-slate-500 max-w-xs">
              Choose a conversation from the left sidebar or search for another user by email or phone.
            </p>
            <button
              onClick={() => setIsNewChatOpen(true)}
              className="px-4 py-2 bg-cyan-600 hover:bg-cyan-500 text-white font-medium text-xs rounded-xl transition-colors"
            >
              + Find User to Chat
            </button>
          </div>
        )}
      </div>

      {showRightPanel && (
        <div className="w-full md:w-80 lg:w-96 shrink-0 h-full border-t md:border-t-0 md:border-l border-slate-800">
          <CompilerAnalysisPanel
            analysis={selectedMessage?.compilerAnalysis || null}
            onClose={() => setShowRightPanel(false)}
          />
        </div>
      )}

      <NewChatModal
        currentUserId={currentProfile.uid}
        isOpen={isNewChatOpen}
        onClose={() => setIsNewChatOpen(false)}
        onStartChat={handleStartChatWithUser}
      />
    </div>
  );
};
