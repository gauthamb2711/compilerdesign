import React from 'react';
import { ChatbotView } from '../components/chatbot/ChatbotView';
import { Cpu, Zap } from 'lucide-react';

export const ChatbotPage: React.FC = () => {
  return (
    <div className="min-h-screen bg-slate-50 text-slate-800 flex flex-col font-sans">
      <main className="flex-1 max-w-6xl w-full mx-auto p-4 sm:p-6 lg:p-8 space-y-6">
        {/* Page Header */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-white border border-slate-200 rounded-2xl p-5 shadow-2xs">
          <div className="flex items-center gap-3.5">
            <div className="w-12 h-12 rounded-2xl bg-indigo-600 text-white flex items-center justify-center shadow-sm">
              <Cpu className="w-6 h-6" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h1 className="text-xl font-bold tracking-tight text-slate-900 font-mono">
                  Compiler AI
                </h1>
                <span className="px-2 py-0.5 rounded-full bg-emerald-50 border border-emerald-200 text-emerald-700 text-xs font-mono font-medium flex items-center gap-1">
                  <Zap className="w-3 h-3 fill-current" /> Fast Engine
                </span>
              </div>
              <p className="text-xs text-slate-500 mt-0.5 font-sans">
                Interactive compiler engineering and language processing assistant for 6-phase pipeline exploration, TAC analysis, and code optimizations.
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2 text-xs font-mono text-slate-500">
            <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-100 border border-slate-200">
              <Cpu className="w-3.5 h-3.5 text-indigo-600" />
              <span>Full Pipeline Intelligence</span>
            </div>
          </div>
        </div>

        {/* Master Compiler AI Interface */}
        <ChatbotView isCompact={false} />
      </main>

      <footer className="mt-auto py-6 border-t border-slate-200 bg-white text-center text-xs text-slate-500 font-mono">
        Compiler AI • SecureChat Compiler System • Real-Time Language Processing
      </footer>
    </div>
  );
};
