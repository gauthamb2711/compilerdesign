import React, { useEffect, useState } from 'react';
import { compileMessage } from '../compiler/compiler';
import { CompilerResult } from '../compiler/types';
import { CompilationHistoryModal, HistoryItem } from '../components/compiler/CompilationHistoryModal';
import { CompilerConsole } from '../components/compiler/CompilerConsole';
import { CompilerHeader, WorkbenchView } from '../components/compiler/CompilerHeader';
import { CompilerPipelineHero } from '../components/compiler/CompilerPipelineHero';
import { CompilerStatisticsBar } from '../components/compiler/CompilerStatisticsBar';
import { GrammarExplorer } from '../components/compiler/GrammarExplorer';
import { IntermediateWorkspace } from '../components/compiler/IntermediateWorkspace';
import { LexicalWorkspace } from '../components/compiler/LexicalWorkspace';
import { OptimizationWorkspace } from '../components/compiler/OptimizationWorkspace';
import { SourceCodeEditor } from '../components/compiler/SourceCodeEditor';
import { SyntaxWorkspace } from '../components/compiler/SyntaxWorkspace';
import { TargetCodeWorkspace } from '../components/compiler/TargetCodeWorkspace';
import { SemanticWorkspace } from '../components/compiler/SemanticWorkspace';

const DEFAULT_CODE = `// SecureChat Compiler DSL Program
message("Hello team, please review the project submission.");
url = "https://example-university.edu/portal";
send(message, url);`;

export const CompilerLab: React.FC = () => {
  const [currentView, setCurrentView] = useState<WorkbenchView>('workbench');
  const [sourceCode, setSourceCode] = useState<string>(DEFAULT_CODE);
  const [activePhase, setActivePhase] = useState<number>(1);
  const [isCompiling, setIsCompiling] = useState<boolean>(false);
  const [compilerResult, setCompilerResult] = useState<CompilerResult | null>(() =>
    compileMessage(DEFAULT_CODE)
  );
  const [history, setHistory] = useState<HistoryItem[]>(() => {
    const initial = compileMessage(DEFAULT_CODE);
    return [
      {
        id: 'run-init',
        timestamp: new Date().toLocaleTimeString(),
        sourceCode: DEFAULT_CODE,
        result: initial
      }
    ];
  });

  const handleRunCompile = () => {
    if (!sourceCode.trim()) return;

    setIsCompiling(true);
    let step = 1;

    // Fast animated step-through for realistic compiler pipeline execution
    const interval = setInterval(() => {
      if (step <= 6) {
        setActivePhase(step);
        step++;
      } else {
        clearInterval(interval);
        const result = compileMessage(sourceCode);
        setCompilerResult(result);
        setIsCompiling(false);

        // Record in history
        const newHistoryItem: HistoryItem = {
          id: `run-${Date.now()}`,
          timestamp: new Date().toLocaleTimeString(),
          sourceCode,
          result
        };
        setHistory((prev) => [newHistoryItem, ...prev.slice(0, 19)]);
      }
    }, 80);
  };

  const handleSelectPhase = (phaseNum: number) => {
    setActivePhase(phaseNum);
    // If not in workbench, switch to specific view for that phase
    if (currentView !== 'workbench') {
      const viewMap: Record<number, WorkbenchView> = {
        1: 'tokens',
        2: 'parsetree',
        3: 'symbols',
        4: 'ir',
        5: 'optimization',
        6: 'targetcode'
      };
      setCurrentView(viewMap[phaseNum] || 'workbench');
    }
  };

  const handleLoadHistory = (item: HistoryItem) => {
    setSourceCode(item.sourceCode);
    setCompilerResult(item.result);
    setCurrentView('workbench');
  };

  const handleClearHistory = () => {
    setHistory([]);
  };

  // Keyboard shortcut: F5 or Ctrl+Enter to compile
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'F5' || (e.ctrlKey && e.key === 'Enter')) {
        e.preventDefault();
        handleRunCompile();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [sourceCode]);

  return (
    <div className="min-h-screen bg-slate-50 text-slate-800 flex flex-col font-sans selection:bg-indigo-500/20 selection:text-indigo-900">
      {/* Workbench Top Navigation Bar */}
      <CompilerHeader
        currentView={currentView}
        onSelectView={setCurrentView}
        isCompiling={isCompiling}
        onRunCompile={handleRunCompile}
        historyCount={history.length}
      />

      {/* Main Studio Workspace Container */}
      <main className="flex-1 max-w-7xl w-full mx-auto p-4 sm:p-6 lg:p-8 space-y-6">
        {/* Render View Based on Navigation */}
        {currentView === 'workbench' && (
          <div className="space-y-6">
            {/* 1. Source Input Code Editor */}
            <SourceCodeEditor
              sourceCode={sourceCode}
              onChangeSourceCode={setSourceCode}
              onRunCompile={handleRunCompile}
              isCompiling={isCompiling}
              activePhase={activePhase}
            />

            {/* 2. 6-Phase Pipeline Hero Section */}
            <CompilerPipelineHero
              compilerResult={compilerResult}
              activePhase={activePhase}
              onSelectPhase={handleSelectPhase}
              isCompiling={isCompiling}
            />

            {/* 3. Dynamic Active Phase Deep Workspace */}
            {compilerResult && (
              <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-2xs space-y-4">
                <div className="flex items-center justify-between border-b border-slate-100 pb-3">
                  <h3 className="text-xs font-mono font-bold uppercase tracking-wider text-slate-800">
                    PHASE 0{activePhase} WORKSPACE INSPECTOR
                  </h3>
                  <span className="text-[11px] font-mono text-slate-500">
                    Live Data Structures Generated from Compiler AST
                  </span>
                </div>

                {activePhase === 1 && <LexicalWorkspace lexical={compilerResult.lexical} />}
                {activePhase === 2 && <SyntaxWorkspace syntax={compilerResult.syntax} />}
                {activePhase === 3 && <SemanticWorkspace semantic={compilerResult.semantic} />}
                {activePhase === 4 && (
                  <IntermediateWorkspace ir={compilerResult.intermediateCode} />
                )}
                {activePhase === 5 && (
                  <OptimizationWorkspace
                    optimization={compilerResult.optimization}
                    originalText={compilerResult.originalText}
                  />
                )}
                {activePhase === 6 && <TargetCodeWorkspace codeGen={compilerResult.codeGen} />}
              </div>
            )}

            {/* 4. Compiler Statistics Section */}
            {compilerResult && (
              <CompilerStatisticsBar stats={compilerResult.statistics} />
            )}

            {/* 5. Bottom Compiler Console Logs Tray */}
            {compilerResult && (
              <CompilerConsole
                logs={compilerResult.logs}
                processedText={compilerResult.processedText}
              />
            )}
          </div>
        )}

        {/* Dedicated Pipeline Flow View */}
        {currentView === 'pipeline' && compilerResult && (
          <div className="space-y-6">
            <CompilerPipelineHero
              compilerResult={compilerResult}
              activePhase={activePhase}
              onSelectPhase={handleSelectPhase}
              isCompiling={isCompiling}
            />
            <CompilerStatisticsBar stats={compilerResult.statistics} />
            <CompilerConsole
              logs={compilerResult.logs}
              processedText={compilerResult.processedText}
            />
          </div>
        )}

        {/* Dedicated Tokens View */}
        {currentView === 'tokens' && compilerResult && (
          <div className="space-y-4">
            <h2 className="text-sm font-mono font-bold uppercase tracking-wider text-slate-800">
              Phase 1: Lexical Analysis — Token & Lexeme Table
            </h2>
            <LexicalWorkspace lexical={compilerResult.lexical} />
          </div>
        )}

        {/* Dedicated Parse Tree View */}
        {currentView === 'parsetree' && compilerResult && (
          <div className="space-y-4">
            <h2 className="text-sm font-mono font-bold uppercase tracking-wider text-slate-800">
              Phase 2: Syntax Analysis — Concrete & Abstract Syntax Tree (AST)
            </h2>
            <SyntaxWorkspace syntax={compilerResult.syntax} />
          </div>
        )}

        {/* Dedicated Symbol Table View */}
        {currentView === 'symbols' && compilerResult && (
          <div className="space-y-4">
            <h2 className="text-sm font-mono font-bold uppercase tracking-wider text-slate-800">
              Phase 3: Semantic Analysis — Symbol Table & Type Checking
            </h2>
            <SemanticWorkspace semantic={compilerResult.semantic} />
          </div>
        )}

        {/* Dedicated Intermediate Code View */}
        {currentView === 'ir' && compilerResult && (
          <div className="space-y-4">
            <h2 className="text-sm font-mono font-bold uppercase tracking-wider text-slate-800">
              Phase 4: Intermediate Code Generation — Three-Address Code & Quadruples
            </h2>
            <IntermediateWorkspace ir={compilerResult.intermediateCode} />
          </div>
        )}

        {/* Dedicated Optimization View */}
        {currentView === 'optimization' && compilerResult && (
          <div className="space-y-4">
            <h2 className="text-sm font-mono font-bold uppercase tracking-wider text-slate-800">
              Phase 5: Code Optimization — Constant Folding & Sanitization Passes
            </h2>
            <OptimizationWorkspace
              optimization={compilerResult.optimization}
              originalText={compilerResult.originalText}
            />
          </div>
        )}

        {/* Dedicated Target Code View */}
        {currentView === 'targetcode' && compilerResult && (
          <div className="space-y-4">
            <h2 className="text-sm font-mono font-bold uppercase tracking-wider text-slate-800">
              Phase 6: Target Code Generation — Multi-Architecture Assembly & Registers
            </h2>
            <TargetCodeWorkspace codeGen={compilerResult.codeGen} />
          </div>
        )}

        {/* Dedicated Grammar Explorer View */}
        {currentView === 'grammar' && <GrammarExplorer />}

        {/* Dedicated Compilation History View */}
        {currentView === 'history' && (
          <CompilationHistoryModal
            history={history}
            onSelectRun={handleLoadHistory}
            onClearHistory={handleClearHistory}
          />
        )}
      </main>

      {/* Clean Academic Footer */}
      <footer className="mt-auto py-6 border-t border-slate-200 bg-white text-center text-xs text-slate-500 font-mono">
        SecureChat Compiler Workbench • 6-Phase Language Processing System • Built for Academic Compiler Design
      </footer>
    </div>
  );
};
