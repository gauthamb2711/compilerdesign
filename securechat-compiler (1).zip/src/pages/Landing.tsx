import React from 'react';
import { useNavigate } from 'react-router-dom';
import {
  ShieldCheck,
  Zap,
  Terminal,
  Lock,
  MessageSquare,
  ArrowRight,
  Code2,
  Cpu,
  Layers,
  Sparkles,
  Link2,
  CheckCircle2,
  Activity
} from 'lucide-react';

interface LandingProps {
  onNavigate?: (route: string) => void;
}

export const Landing: React.FC<LandingProps> = ({ onNavigate }) => {
  const navigate = useNavigate();

  const handleNavigate = (route: string) => {
    if (onNavigate) {
      onNavigate(route);
    } else {
      navigate(route);
    }
  };

  return (
    <div className="min-h-screen bg-slate-50 text-slate-800 flex flex-col font-sans selection:bg-indigo-500/20">
      {/* Hero Section */}
      <section className="relative overflow-hidden py-16 lg:py-24 px-4 lg:px-8 max-w-7xl mx-auto text-center flex flex-col items-center">
        {/* Subtle Ambient Glow */}
        <div className="absolute top-1/4 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[500px] h-[250px] bg-indigo-500/5 rounded-full blur-[100px] pointer-events-none" />

        {/* Pill Tag */}
        <div className="inline-flex items-center gap-2.5 px-4 py-2 rounded-full bg-white border border-slate-200 text-slate-600 text-xs font-medium mb-8 shadow-sm">
          <Terminal className="w-3.5 h-3.5 text-indigo-600" />
          <span>Compiler Design Academic Project</span>
          <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
        </div>

        {/* Title */}
        <h1 className="text-4xl sm:text-6xl lg:text-7xl font-extrabold tracking-tight text-slate-900 max-w-4xl leading-[1.1] mb-6">
          SecureChat <span className="text-indigo-600">Compiler</span>
        </h1>

        {/* Subtitle */}
        <p className="text-lg sm:text-xl text-slate-500 max-w-2xl font-sans mb-10 leading-relaxed">
          Real-Time Message Security & Threat Neutralization Built on 6-Phase Compiler Architecture
        </p>

        {/* Call to Action Buttons */}
        <div className="flex flex-col sm:flex-row items-center gap-4 mb-16">
          <button
            onClick={() => handleNavigate('/register')}
            className="w-full sm:w-auto px-8 py-4 bg-indigo-600 hover:bg-indigo-700 text-white font-bold rounded-2xl shadow-lg shadow-indigo-200 transition-all flex items-center justify-center gap-2.5 text-sm font-sans tracking-wide"
          >
            Get Started
            <ArrowRight className="w-4 h-4" />
          </button>

          <button
            onClick={() => handleNavigate('/login')}
            className="w-full sm:w-auto px-8 py-4 bg-white hover:bg-slate-50 text-slate-700 font-bold rounded-2xl border border-slate-200 shadow-sm transition-all flex items-center justify-center gap-2 text-sm font-sans"
          >
            Login to Account
          </button>
        </div>

        {/* Executive Overview Hero Card */}
        <div className="w-full max-w-5xl bg-white border border-slate-200/80 rounded-3xl p-8 shadow-sm flex flex-col md:flex-row justify-between relative overflow-hidden gap-8 text-left">
          <div className="relative z-10 flex-1">
            <div>
              <p className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-2">
                SECURITY COMPILER STATUS
              </p>
              <h2 className="text-3xl sm:text-4xl font-bold text-slate-800">
                100% Threat Neutralization Rate
              </h2>
            </div>
            <div className="mt-8 flex flex-wrap gap-8">
              <div className="flex flex-col">
                <span className="text-xs font-bold text-slate-400 mb-1 uppercase tracking-wider">LATENCY</span>
                <span className="text-xl font-bold text-emerald-600 font-mono">&lt; 12ms / Message</span>
              </div>
              <div className="flex flex-col">
                <span className="text-xs font-bold text-slate-400 mb-1 uppercase tracking-wider">COMPILER PHASES</span>
                <span className="text-xl font-bold text-slate-800">6 Real-Time Stages</span>
              </div>
              <div className="flex flex-col">
                <span className="text-xs font-bold text-slate-400 mb-1 uppercase tracking-wider">ACCURACY</span>
                <span className="text-xl font-bold text-indigo-600">99.8% Precision</span>
              </div>
            </div>
          </div>

          <div className="w-full md:w-72 bg-indigo-600 rounded-2xl p-6 text-white shadow-lg shadow-indigo-100 flex flex-col justify-between gap-4">
            <div>
              <p className="text-indigo-200 text-xs uppercase font-bold tracking-wider mb-1">Active Pipeline</p>
              <h3 className="text-2xl font-bold">Lexical & AST Engine</h3>
            </div>
            <div className="space-y-2">
              <div className="flex items-center justify-between text-xs font-semibold">
                <span>Threat Scrubbing</span>
                <span>Active</span>
              </div>
              <div className="h-2 bg-indigo-400/30 rounded-full overflow-hidden">
                <div className="w-[92%] h-full bg-white rounded-full"></div>
              </div>
            </div>
            <p className="text-xs text-indigo-100">
              Compiler Phase: <span className="font-bold">Target Sanitized Code</span>
            </p>
          </div>
        </div>
      </section>

      {/* Real-Time Pipeline Architecture */}
      <section className="py-12 px-4 lg:px-8 max-w-7xl mx-auto w-full">
        <div className="bg-slate-900 rounded-3xl p-8 text-white shadow-md">
          <div className="flex items-center justify-between mb-8">
            <h3 className="text-xs font-mono text-indigo-400 font-bold uppercase tracking-widest flex items-center gap-2">
              <Terminal className="w-4 h-4" /> Real-Time Pipeline Architecture
            </h3>
            <span className="text-xs text-slate-400 font-mono hidden sm:inline">AST & IR Code Engine</span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-4 gap-4 items-center">
            <div className="p-4 bg-slate-800/80 border border-slate-700/60 rounded-2xl">
              <span className="text-[10px] font-mono text-slate-400 block mb-1">STEP 01</span>
              <span className="text-sm font-bold text-slate-100">Raw Input Stream</span>
            </div>

            <div className="p-4 bg-indigo-900/60 border border-indigo-700/80 rounded-2xl text-indigo-200">
              <span className="text-[10px] font-mono text-indigo-300 block mb-1">CORE COMPILER</span>
              <span className="text-sm font-bold">6-Phase Parsing</span>
            </div>

            <div className="p-4 bg-slate-800/80 border border-slate-700/60 rounded-2xl">
              <span className="text-[10px] font-mono text-slate-400 block mb-1">STEP 03</span>
              <span className="text-sm font-bold text-slate-100">Risk Assessment</span>
            </div>

            <div className="p-4 bg-emerald-950/80 border border-emerald-800/80 rounded-2xl text-emerald-300">
              <span className="text-[10px] font-mono text-emerald-400 block mb-1">DELIVERY</span>
              <span className="text-sm font-bold">Sanitized Target</span>
            </div>
          </div>
        </div>
      </section>

      {/* Feature Grid */}
      <section className="py-16 px-4 lg:px-8 max-w-7xl mx-auto w-full">
        <div className="text-center max-w-2xl mx-auto mb-16">
          <h2 className="text-2xl sm:text-3xl font-bold text-slate-800 tracking-tight mb-3">
            Intelligent Compiler Security Features
          </h2>
          <p className="text-sm text-slate-500">
            Powered by Firebase Auth, Cloud Firestore real-time listeners, and an inline 6-phase compiler pipeline.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {[
            {
              title: 'Real-Time Messaging',
              desc: 'Instant delivery across separate browser sessions using Firestore onSnapshot listeners with real-time status indicators.',
              icon: Zap,
              badgeBg: 'bg-indigo-50 text-indigo-600'
            },
            {
              title: 'Fraud Detection',
              desc: 'Identifies banking fraud, impersonation, OTP solicitation, and credential theft with context-aware semantic rules.',
              icon: ShieldCheck,
              badgeBg: 'bg-rose-50 text-rose-600'
            },
            {
              title: 'Spam Detection',
              desc: 'Normalizes excessive capitalization, exclamation spam, and aggressive promotional advertising patterns.',
              icon: Activity,
              badgeBg: 'bg-amber-50 text-amber-600'
            },
            {
              title: 'Phishing Detection',
              desc: 'Detects malicious login links, fake banking portals, and high-pressure urgency threats.',
              icon: Lock,
              badgeBg: 'bg-rose-50 text-rose-600'
            },
            {
              title: 'URL Sanitization',
              desc: 'Neutralizes and removes dangerous links before delivery, replacing them with safe [LINK REMOVED] badges.',
              icon: Link2,
              badgeBg: 'bg-indigo-50 text-indigo-600'
            },
            {
              title: 'Six Compiler Phases',
              desc: 'Executes Lexical Analysis, Syntax Analysis, Semantic Analysis, IR Generation, Optimization, and Target Generation.',
              icon: Cpu,
              badgeBg: 'bg-purple-50 text-purple-600'
            }
          ].map((feat) => {
            const Icon = feat.icon;
            return (
              <div
                key={feat.title}
                className="p-6 bg-white border border-slate-200/80 hover:border-indigo-200 rounded-3xl transition-all shadow-sm flex flex-col justify-between"
              >
                <div>
                  <div className={`p-3 rounded-2xl inline-block mb-4 ${feat.badgeBg}`}>
                    <Icon className="w-6 h-6" />
                  </div>
                  <h3 className="text-base font-bold text-slate-800 mb-2">{feat.title}</h3>
                  <p className="text-xs text-slate-500 leading-relaxed">{feat.desc}</p>
                </div>
              </div>
            );
          })}
        </div>
      </section>

      {/* Footer */}
      <footer className="mt-auto py-8 border-t border-slate-200 text-center text-xs text-slate-500 font-mono">
        SecureChat Compiler © 2026 — Real-Time Compiler Design Message Security System
      </footer>
    </div>
  );
};
