import React, { useEffect, useState } from 'react';
import { ref, get } from 'firebase/database';
import {
  Shield,
  ShieldAlert,
  Zap
} from 'lucide-react';
import { rtdb } from '../lib/firebase';
import { ChatMessage, UserProfile } from '../types';
import { SecurityBadge } from '../components/common/SecurityBadge';
import { CompilerAnalysisPanel } from '../components/chat/CompilerAnalysisPanel';

interface SecurityProps {
  currentProfile: UserProfile;
}

export const Security: React.FC<SecurityProps> = ({ currentProfile }) => {
  const [userMessages, setUserMessages] = useState<ChatMessage[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [inspectMessage, setInspectMessage] = useState<ChatMessage | null>(null);

  useEffect(() => {
    async function fetchUserSecurityStats() {
      setLoading(true);
      try {
        const convsRef = ref(rtdb, 'conversations');
        const snapshot = await get(convsRef);

        const msgsList: ChatMessage[] = [];
        if (snapshot.exists()) {
          const convsData = snapshot.val();
          Object.keys(convsData).forEach((convId) => {
            const conv = convsData[convId];
            if (conv.messages) {
              Object.keys(conv.messages).forEach((msgId) => {
                const msg = conv.messages[msgId] as ChatMessage;
                if (msg.senderId === currentProfile.uid || msg.receiverId === currentProfile.uid) {
                  msgsList.push(msg);
                }
              });
            }
          });
        }

        msgsList.sort((a, b) => {
          const tA = new Date(a.createdAt || 0).getTime();
          const tB = new Date(b.createdAt || 0).getTime();
          return tB - tA;
        });

        setUserMessages(msgsList);
      } catch (err) {
        console.error('Error fetching security messages:', err);
      } finally {
        setLoading(false);
      }
    }

    fetchUserSecurityStats();
  }, [currentProfile.uid]);


  const total = userMessages.length;
  const safeCount = userMessages.filter((m) => m.classification === 'SAFE').length;
  const spamCount = userMessages.filter((m) => m.classification === 'SPAM').length;
  const suspiciousCount = userMessages.filter((m) => m.classification === 'SUSPICIOUS').length;
  const misleadingCount = userMessages.filter((m) => m.classification === 'MISLEADING').length;
  const fraudCount = userMessages.filter((m) => m.classification === 'FRAUD').length;
  const phishingCount = userMessages.filter((m) => m.classification === 'PHISHING').length;

  const totalUrlsRemoved = userMessages.reduce((acc, m) => acc + (m.removedUrls?.length || 0), 0);

  const safePercent = total > 0 ? Math.round((safeCount / total) * 100) : 100;
  const spamPercent = total > 0 ? Math.round((spamCount / total) * 100) : 0;
  const suspiciousPercent = total > 0 ? Math.round((suspiciousCount / total) * 100) : 0;
  const misleadingPercent = total > 0 ? Math.round((misleadingCount / total) * 100) : 0;
  const fraudPercent = total > 0 ? Math.round((fraudCount / total) * 100) : 0;
  const phishingPercent = total > 0 ? Math.round((phishingCount / total) * 100) : 0;

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 font-sans p-4 sm:p-6 lg:p-8 max-w-7xl mx-auto space-y-8">
      {/* Header */}
      <div className="space-y-2 border-b border-slate-800 pb-6">
        <div className="flex items-center gap-2">
          <Shield className="w-7 h-7 text-cyan-400" />
          <h1 className="text-2xl sm:text-3xl font-extrabold tracking-tight">
            Security & Threat Analytics Dashboard
          </h1>
        </div>
        <p className="text-xs sm:text-sm text-slate-400">
          Real-time compiler threat metrics and fraud detection summary across all messaging channels.
        </p>
      </div>

      {/* Metric Cards Grid */}
      <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-8 gap-3">
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-3.5 space-y-1">
          <span className="text-[10px] font-mono text-slate-400 uppercase">Total Messages</span>
          <div className="text-xl font-bold text-slate-100 font-mono">{total}</div>
        </div>

        <div className="bg-slate-900 border border-emerald-500/30 rounded-xl p-3.5 space-y-1">
          <span className="text-[10px] font-mono text-emerald-400 uppercase">Safe</span>
          <div className="text-xl font-bold text-emerald-400 font-mono">{safeCount}</div>
        </div>

        <div className="bg-slate-900 border border-amber-500/30 rounded-xl p-3.5 space-y-1">
          <span className="text-[10px] font-mono text-amber-400 uppercase">Spam</span>
          <div className="text-xl font-bold text-amber-400 font-mono">{spamCount}</div>
        </div>

        <div className="bg-slate-900 border border-orange-500/30 rounded-xl p-3.5 space-y-1">
          <span className="text-[10px] font-mono text-orange-400 uppercase">Suspicious</span>
          <div className="text-xl font-bold text-orange-400 font-mono">{suspiciousCount}</div>
        </div>

        <div className="bg-slate-900 border border-yellow-500/30 rounded-xl p-3.5 space-y-1">
          <span className="text-[10px] font-mono text-yellow-300 uppercase">Misleading</span>
          <div className="text-xl font-bold text-yellow-300 font-mono">{misleadingCount}</div>
        </div>

        <div className="bg-slate-900 border border-rose-500/30 rounded-xl p-3.5 space-y-1">
          <span className="text-[10px] font-mono text-rose-400 uppercase">Fraud</span>
          <div className="text-xl font-bold text-rose-400 font-mono">{fraudCount}</div>
        </div>

        <div className="bg-slate-900 border border-red-500/50 rounded-xl p-3.5 space-y-1">
          <span className="text-[10px] font-mono text-red-400 uppercase">Phishing</span>
          <div className="text-xl font-bold text-red-400 font-mono">{phishingCount}</div>
        </div>

        <div className="bg-slate-900 border border-cyan-500/30 rounded-xl p-3.5 space-y-1">
          <span className="text-[10px] font-mono text-cyan-400 uppercase">URLs Removed</span>
          <div className="text-xl font-bold text-cyan-400 font-mono">{totalUrlsRemoved}</div>
        </div>
      </div>

      {/* Threat Distribution Chart */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 space-y-4">
        <h3 className="text-sm font-semibold text-slate-200 flex items-center gap-2">
          <Zap className="w-4 h-4 text-cyan-400" /> Threat Distribution Breakdown
        </h3>

        <div className="h-4 w-full bg-slate-950 rounded-full overflow-hidden flex border border-slate-800">
          <div style={{ width: `${safePercent}%` }} className="bg-emerald-500 transition-all" title={`Safe: ${safePercent}%`} />
          <div style={{ width: `${spamPercent}%` }} className="bg-amber-500 transition-all" title={`Spam: ${spamPercent}%`} />
          <div style={{ width: `${suspiciousPercent}%` }} className="bg-orange-500 transition-all" title={`Suspicious: ${suspiciousPercent}%`} />
          <div style={{ width: `${misleadingPercent}%` }} className="bg-yellow-400 transition-all" title={`Misleading: ${misleadingPercent}%`} />
          <div style={{ width: `${fraudPercent}%` }} className="bg-rose-500 transition-all" title={`Fraud: ${fraudPercent}%`} />
          <div style={{ width: `${phishingPercent}%` }} className="bg-red-600 transition-all" title={`Phishing: ${phishingPercent}%`} />
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-6 gap-2 text-xs font-mono pt-2">
          <div className="flex items-center gap-2">
            <span className="w-3 h-3 rounded-full bg-emerald-500" />
            <span className="text-slate-400">Safe ({safePercent}%)</span>
          </div>
          <div className="flex items-center gap-2">
            <span className="w-3 h-3 rounded-full bg-amber-500" />
            <span className="text-slate-400">Spam ({spamPercent}%)</span>
          </div>
          <div className="flex items-center gap-2">
            <span className="w-3 h-3 rounded-full bg-orange-500" />
            <span className="text-slate-400">Suspicious ({suspiciousPercent}%)</span>
          </div>
          <div className="flex items-center gap-2">
            <span className="w-3 h-3 rounded-full bg-yellow-400" />
            <span className="text-slate-400">Misleading ({misleadingPercent}%)</span>
          </div>
          <div className="flex items-center gap-2">
            <span className="w-3 h-3 rounded-full bg-rose-500" />
            <span className="text-slate-400">Fraud ({fraudPercent}%)</span>
          </div>
          <div className="flex items-center gap-2">
            <span className="w-3 h-3 rounded-full bg-red-600" />
            <span className="text-slate-400">Phishing ({phishingPercent}%)</span>
          </div>
        </div>
      </div>

      {/* Recent Security Detections Table */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl overflow-hidden space-y-4 p-6">
        <h3 className="text-sm font-semibold text-slate-200 flex items-center gap-2">
          <ShieldAlert className="w-4 h-4 text-cyan-400" /> Message Security Detections Log
        </h3>

        {loading ? (
          <div className="p-8 text-center text-xs text-slate-500 animate-pulse">
            Querying security records...
          </div>
        ) : userMessages.length === 0 ? (
          <div className="p-8 text-center text-xs text-slate-500">
            No messages logged yet. Send or receive messages in chat to view live threat telemetry.
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs font-sans">
              <thead className="bg-slate-950 text-slate-400 font-mono uppercase text-[10px] border-b border-slate-800">
                <tr>
                  <th className="py-3 px-4">Time</th>
                  <th className="py-3 px-4">Message Excerpt</th>
                  <th className="py-3 px-4">Classification</th>
                  <th className="py-3 px-4">Risk Score</th>
                  <th className="py-3 px-4">Threat Level</th>
                  <th className="py-3 px-4">URL Status</th>
                  <th className="py-3 px-4 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60">
                {userMessages.map((msg) => (
                  <tr key={msg.id} className="hover:bg-slate-800/40 transition-colors">
                    <td className="py-3 px-4 font-mono text-slate-400 whitespace-nowrap">
                      {msg.createdAt
                        ? new Date(msg.createdAt).toLocaleTimeString([], {
                            hour: '2-digit',
                            minute: '2-digit'
                          })
                        : 'Just now'}
                    </td>

                    <td className="py-3 px-4 text-slate-200 max-w-xs truncate">
                      {msg.processedText}
                    </td>

                    <td className="py-3 px-4">
                      <SecurityBadge
                        classification={msg.classification}
                        riskScore={msg.riskScore}
                        threatLevel={msg.threatLevel}
                        size="sm"
                      />
                    </td>

                    <td className="py-3 px-4 font-mono font-bold text-slate-200">
                      {msg.riskScore}/100
                    </td>

                    <td className="py-3 px-4 font-mono">
                      <span
                        className={`text-[10px] font-bold ${
                          msg.threatLevel === 'CRITICAL'
                            ? 'text-red-400'
                            : msg.threatLevel === 'HIGH'
                            ? 'text-rose-400'
                            : msg.threatLevel === 'MEDIUM'
                            ? 'text-amber-400'
                            : 'text-emerald-400'
                        }`}
                      >
                        {msg.threatLevel}
                      </span>
                    </td>

                    <td className="py-3 px-4 font-mono text-[11px]">
                      {msg.removedUrls && msg.removedUrls.length > 0 ? (
                        <span className="text-rose-400 font-semibold">
                          {msg.removedUrls.length} Neutralized
                        </span>
                      ) : msg.hasUrl ? (
                        <span className="text-amber-400">1 Link Verified</span>
                      ) : (
                        <span className="text-slate-500">No Links</span>
                      )}
                    </td>

                    <td className="py-3 px-4 text-right">
                      <button
                        onClick={() => setInspectMessage(msg)}
                        className="px-2.5 py-1 bg-slate-800 hover:bg-slate-700 text-cyan-400 rounded-lg font-mono text-[10px] transition-colors"
                      >
                        Inspect
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {inspectMessage && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm">
          <div className="w-full max-w-2xl h-[80vh] bg-slate-950 border border-slate-800 rounded-2xl overflow-hidden shadow-2xl">
            <CompilerAnalysisPanel
              analysis={inspectMessage.compilerAnalysis || null}
              onClose={() => setInspectMessage(null)}
            />
          </div>
        </div>
      )}
    </div>
  );
};
