import { Classification, CompilerResult, ThreatLevel } from './compiler/types';

export interface UserProfile {
  uid: string;
  fullName: string;
  email: string;
  phone: string;
  emailNormalized: string;
  phoneNormalized: string;
  avatarUrl?: string;
  online: boolean;
  lastSeen: any;
  createdAt: any;
}

export interface ConversationParticipant {
  uid: string;
  fullName: string;
  email: string;
  phone?: string;
  avatarUrl?: string;
  online?: boolean;
}

export interface Conversation {
  id: string;
  participantIds: string[];
  participants: Record<string, ConversationParticipant>;
  lastMessage: string;
  lastMessageType?: any;
  lastMessageAt: any;
  unreadCount?: Record<string, number>;
  createdAt: any;
  updatedAt?: any;
}

export type MessageStatus = 'SENT' | 'DELIVERED' | 'SEEN';

export interface ChatMessage {
  id: string;
  conversationId: string;
  senderId: string;
  receiverId: string;
  originalText: string;
  processedText: string;
  status: MessageStatus;
  
  // Security Analysis Fields from Compiler Engine
  classification: Classification;
  riskScore: number;
  threatLevel: ThreatLevel;
  hasUrl: boolean;
  removedUrls?: string[];
  compilerAnalysis: CompilerResult;
  
  createdAt: any;
}

export * from './compiler/types';
