import React from 'react';
import { ClassificationCategory, ThreatLevel } from '../../compiler/types';

interface SecurityBadgeProps {
  classification: ClassificationCategory;
  riskScore?: number;
  threatLevel?: ThreatLevel;
  size?: 'sm' | 'md' | 'lg';
}

export const SecurityBadge: React.FC<SecurityBadgeProps> = ({
  classification,
  riskScore,
  threatLevel,
  size = 'md'
}) => {
  const getBadgeStyle = () => {
    switch (classification) {
      case 'SAFE':
        return 'bg-emerald-500/10 text-emerald-400 border-emerald-500/30';
      case 'SPAM':
        return 'bg-amber-500/10 text-amber-400 border-amber-500/30';
      case 'SUSPICIOUS':
        return 'bg-orange-500/10 text-orange-400 border-orange-500/30';
      case 'MISLEADING':
        return 'bg-yellow-500/10 text-yellow-300 border-yellow-500/30';
      case 'FRAUD':
        return 'bg-rose-500/15 text-rose-400 border-rose-500/40';
      case 'PHISHING':
        return 'bg-red-600/20 text-red-400 border-red-500/50 shadow-red-900/20 shadow-sm';
      default:
        return 'bg-slate-500/10 text-slate-400 border-slate-500/30';
    }
  };

  const paddingClass = size === 'sm' ? 'px-2 py-0.5 text-xs' : size === 'lg' ? 'px-3 py-1.5 text-sm font-semibold' : 'px-2.5 py-1 text-xs font-medium';

  return (
    <span
      className={`inline-flex items-center gap-1.5 border rounded-full font-mono uppercase tracking-wider ${getBadgeStyle()} ${paddingClass}`}
    >
      <span className={`w-1.5 h-1.5 rounded-full ${classification === 'SAFE' ? 'bg-emerald-400 animate-pulse' : classification === 'PHISHING' ? 'bg-red-400 animate-ping' : 'bg-current'}`} />
      {classification}
      {riskScore !== undefined && (
        <span className="opacity-75 text-[10px]">({riskScore}/100)</span>
      )}
    </span>
  );
};
