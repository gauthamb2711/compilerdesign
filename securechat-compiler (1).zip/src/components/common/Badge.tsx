import React from 'react';
import { ClassificationCategory, ThreatLevel } from '../../compiler/types';

interface ClassificationBadgeProps {
  type: ClassificationCategory;
  size?: 'sm' | 'md' | 'lg';
}

export const ClassificationBadge: React.FC<ClassificationBadgeProps> = ({
  type,
  size = 'md'
}) => {
  const styles: Record<ClassificationCategory, { bg: string; text: string; label: string }> = {
    SAFE: {
      bg: 'bg-emerald-950 border-emerald-800',
      text: 'text-emerald-400',
      label: 'SAFE'
    },
    SPAM: {
      bg: 'bg-amber-950 border-amber-800',
      text: 'text-amber-400',
      label: 'SPAM'
    },
    SUSPICIOUS: {
      bg: 'bg-orange-950 border-orange-800',
      text: 'text-orange-400',
      label: 'SUSPICIOUS'
    },
    MISLEADING: {
      bg: 'bg-purple-950 border-purple-800',
      text: 'text-purple-400',
      label: 'MISLEADING'
    },
    FRAUD: {
      bg: 'bg-rose-950 border-rose-800',
      text: 'text-rose-400',
      label: 'FRAUD'
    },
    PHISHING: {
      bg: 'bg-red-950 border-red-800',
      text: 'text-red-400 animate-pulse',
      label: 'PHISHING'
    }
  };

  const style = styles[type] || styles.SAFE;
  const sizeClasses = {
    sm: 'px-1.5 py-0.5 text-[10px]',
    md: 'px-2.5 py-1 text-xs',
    lg: 'px-3 py-1.5 text-xs font-bold'
  }[size];

  return (
    <span
      className={`inline-flex items-center font-mono font-bold rounded border ${style.bg} ${style.text} ${sizeClasses}`}
    >
      {style.label}
    </span>
  );
};

interface ThreatBadgeProps {
  level: ThreatLevel;
}

export const ThreatBadge: React.FC<ThreatBadgeProps> = ({ level }) => {
  const styles: Record<ThreatLevel, { bg: string; text: string }> = {
    LOW: { bg: 'bg-emerald-950 border-emerald-800', text: 'text-emerald-400' },
    MEDIUM: { bg: 'bg-amber-950 border-amber-800', text: 'text-amber-400' },
    HIGH: { bg: 'bg-rose-950 border-rose-800', text: 'text-rose-400' },
    CRITICAL: { bg: 'bg-red-950 border-red-800', text: 'text-red-400 animate-pulse' }
  };

  const style = styles[level] || styles.LOW;

  return (
    <span
      className={`inline-flex items-center px-2 py-0.5 font-mono text-[10px] font-bold rounded border ${style.bg} ${style.text}`}
    >
      THREAT: {level}
    </span>
  );
};
