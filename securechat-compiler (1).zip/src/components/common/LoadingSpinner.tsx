import React from 'react';

export const LoadingSpinner: React.FC<{ size?: 'sm' | 'md' | 'lg'; text?: string }> = ({
  size = 'md',
  text
}) => {
  const sizes = {
    sm: 'w-4 h-4 border-2',
    md: 'w-8 h-8 border-3',
    lg: 'w-12 h-12 border-4'
  };

  return (
    <div className="flex flex-col items-center justify-center p-4 gap-3 text-slate-400">
      <div
        className={`${sizes[size]} border-cyan-500/30 border-t-cyan-400 rounded-full animate-spin`}
      />
      {text && <p className="text-xs font-mono text-cyan-400/80 animate-pulse">{text}</p>}
    </div>
  );
};
