import React from 'react';
import { AlertCircle, Terminal, Shield } from 'lucide-react';

export const FirebaseMissingAlert: React.FC = () => {
  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex items-center justify-center p-4 font-sans">
      <div className="max-w-md w-full bg-slate-900 border border-slate-800 rounded-2xl p-6 space-y-4 text-center shadow-2xl">
        <div className="w-12 h-12 bg-amber-500/10 border border-amber-500/30 text-amber-400 rounded-2xl flex items-center justify-center mx-auto">
          <AlertCircle className="w-6 h-6" />
        </div>

        <h2 className="text-lg font-bold text-slate-100">
          Firebase Backend Configuration Required
        </h2>

        <p className="text-xs text-slate-400 leading-relaxed">
          SecureChat Compiler requires a real Firebase project for authentication and Firestore real-time messaging.
        </p>

        <div className="bg-slate-950 p-3 rounded-xl border border-slate-800 text-left font-mono text-xs text-slate-300 space-y-1">
          <div className="text-cyan-400 font-semibold mb-1">.env.example Configuration:</div>
          <div>VITE_FIREBASE_API_KEY=...</div>
          <div>VITE_FIREBASE_PROJECT_ID=...</div>
          <div>VITE_FIREBASE_AUTH_DOMAIN=...</div>
        </div>

        <p className="text-[11px] text-slate-500">
          Please check your environment variables or <code className="text-cyan-400">firebase-applet-config.json</code> file.
        </p>
      </div>
    </div>
  );
};
