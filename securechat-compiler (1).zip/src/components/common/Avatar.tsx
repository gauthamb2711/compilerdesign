import React from 'react';

interface AvatarProps {
  name: string;
  avatarUrl?: string;
  online?: boolean;
  size?: 'sm' | 'md' | 'lg' | 'xl';
  className?: string;
}

export const Avatar: React.FC<AvatarProps> = ({
  name,
  avatarUrl,
  online,
  size = 'md',
  className = ''
}) => {
  const dimensions = {
    sm: 'w-8 h-8 text-xs',
    md: 'w-10 h-10 text-sm',
    lg: 'w-12 h-12 text-base',
    xl: 'w-16 h-16 text-lg'
  };

  const statusDot = {
    sm: 'w-2.5 h-2.5 right-0 bottom-0',
    md: 'w-3 h-3 right-0 bottom-0',
    lg: 'w-3.5 h-3.5 right-0.5 bottom-0.5',
    xl: 'w-4 h-4 right-1 bottom-1'
  };

  const getInitials = (str: string) => {
    if (!str) return '?';
    const parts = str.trim().split(' ');
    if (parts.length >= 2) return `${parts[0][0]}${parts[1][0]}`.toUpperCase();
    return str.slice(0, 2).toUpperCase();
  };

  return (
    <div className={`relative inline-block flex-shrink-0 ${className}`}>
      {avatarUrl ? (
        <img
          src={avatarUrl}
          alt={name}
          className={`${dimensions[size]} rounded-full object-cover border border-slate-700 bg-slate-900`}
        />
      ) : (
        <div
          className={`${dimensions[size]} rounded-full bg-gradient-to-br from-cyan-600 to-blue-800 text-white font-semibold flex items-center justify-center border border-cyan-500/30 shadow-inner`}
        >
          {getInitials(name)}
        </div>
      )}

      {online !== undefined && (
        <span
          className={`absolute rounded-full border-2 border-slate-950 ${statusDot[size]} ${
            online ? 'bg-emerald-500 shadow-[0_0_8px_#10b981]' : 'bg-slate-500'
          }`}
          title={online ? 'Online' : 'Offline'}
        />
      )}
    </div>
  );
};
