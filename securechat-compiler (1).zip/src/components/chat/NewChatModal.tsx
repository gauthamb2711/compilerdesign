import React, { useState } from 'react';
import { X, Search, UserPlus, AlertCircle, MessageSquare } from 'lucide-react';
import { useAuth } from '../../hooks/useAuth';
import { searchUserByEmailOrPhone } from '../../services/userService';
import { getOrCreateConversation } from '../../services/conversationService';
import { UserProfile } from '../../types';
import { Avatar } from '../common/Avatar';

interface NewChatModalProps {
  currentUserId?: string;
  isOpen: boolean;
  onClose: () => void;
  onSelectConversation?: (conversationId: string) => void;
  onStartChat?: (partnerUser: UserProfile) => void;
}

export const NewChatModal: React.FC<NewChatModalProps> = ({
  currentUserId,
  isOpen,
  onClose,
  onSelectConversation,
  onStartChat
}) => {
  const { user, profile } = useAuth();
  const [searchTerm, setSearchTerm] = useState('');
  const [searching, setSearching] = useState(false);
  const [foundUser, setFoundUser] = useState<UserProfile | null>(null);
  const [hasSearched, setHasSearched] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [startingChat, setStartingChat] = useState(false);

  if (!isOpen) return null;

  const activeUserId = currentUserId || user?.uid || profile?.uid;

  const handleSearch = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!searchTerm.trim() || !activeUserId) return;

    setSearching(true);
    setError(null);
    setFoundUser(null);
    setHasSearched(false);

    try {
      const targetUser = await searchUserByEmailOrPhone(searchTerm, activeUserId);
      setFoundUser(targetUser);
      setHasSearched(true);
    } catch (err: any) {
      console.error('[Firebase Search Error]:', err);
      setError(err.message || 'Error searching user.');
    } finally {
      setSearching(false);
    }
  };

  const handleStartChat = async () => {
    if (!foundUser || !activeUserId) {
      setError('User credentials missing. Please try signing in again.');
      return;
    }

    if (activeUserId === foundUser.uid) {
      setError('You cannot start a conversation with yourself.');
      return;
    }

    setStartingChat(true);
    setError(null);

    try {
      console.log(`[RTDB] Initiating conversation between ${activeUserId} and ${foundUser.uid}...`);
      if (onStartChat) {
        await onStartChat(foundUser);
      } else {
        const currentUserProfile: UserProfile = profile || {
          uid: activeUserId,
          fullName: user?.displayName || 'User',
          email: user?.email || '',
          phone: '',
          emailNormalized: (user?.email || '').toLowerCase(),
          phoneNormalized: '',
          online: true,
          lastSeen: new Date().toISOString(),
          createdAt: new Date().toISOString()
        };
        const conv = await getOrCreateConversation(currentUserProfile, foundUser);
        if (onSelectConversation) {
          onSelectConversation(conv.id);
        }
      }
      onClose();
    } catch (err: any) {
      console.error('[Firebase RTDB Error] Failed to start conversation:', err);
      setError(err?.message || 'Could not initiate conversation.');
    } finally {
      setStartingChat(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md animate-fadeIn">
      <div className="w-full max-w-md bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-2xl relative">
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="flex items-center gap-3 mb-6">
          <div className="p-2.5 rounded-xl bg-cyan-950 border border-cyan-800 text-cyan-400">
            <UserPlus className="w-5 h-5" />
          </div>
          <div>
            <h3 className="text-lg font-bold text-white tracking-tight">Find a User</h3>
            <p className="text-xs text-slate-400">
              Search by registered email address or phone number
            </p>
          </div>
        </div>

        <form onSubmit={handleSearch} className="mb-6">
          <div className="relative">
            <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-500" />
            <input
              type="text"
              autoFocus
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              placeholder="e.g. arun@gmail.com or 9876543210"
              className="w-full pl-10 pr-24 py-2.5 bg-slate-950 border border-slate-800 rounded-xl text-slate-100 placeholder-slate-600 text-sm focus:outline-none focus:border-cyan-500 transition-all font-mono"
            />
            <button
              type="submit"
              disabled={searching || !searchTerm.trim()}
              className="absolute right-1.5 top-1/2 -translate-y-1/2 px-3 py-1.5 bg-cyan-500 hover:bg-cyan-400 disabled:opacity-50 text-slate-950 font-bold text-xs rounded-lg font-mono transition-all"
            >
              {searching ? 'Searching...' : 'Search'}
            </button>
          </div>
        </form>

        {error && (
          <div className="p-3 mb-4 rounded-xl bg-red-950/60 border border-red-800 text-red-300 text-xs flex items-center gap-2 font-mono">
            <AlertCircle className="w-4 h-4 text-red-400 flex-shrink-0" />
            {error}
          </div>
        )}

        {/* Search Results */}
        {hasSearched && (
          <div className="mt-4">
            {foundUser ? (
              <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 flex items-center justify-between gap-3 shadow-inner">
                <div className="flex items-center gap-3 overflow-hidden">
                  <Avatar
                    name={foundUser.fullName}
                    avatarUrl={foundUser.avatarUrl}
                    online={foundUser.online}
                    size="md"
                  />
                  <div className="min-w-0">
                    <h4 className="text-sm font-semibold text-white truncate">
                      {foundUser.fullName}
                    </h4>
                    <p className="text-xs text-slate-400 font-mono truncate">
                      {foundUser.email}
                    </p>
                    {foundUser.phone && (
                      <p className="text-[11px] text-slate-500 font-mono">
                        {foundUser.phone}
                      </p>
                    )}
                  </div>
                </div>

                <button
                  onClick={handleStartChat}
                  disabled={startingChat}
                  className="px-4 py-2 bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold text-xs rounded-xl shadow-[0_0_15px_rgba(16,185,129,0.3)] flex items-center gap-1.5 flex-shrink-0 font-mono transition-all disabled:opacity-50"
                >
                  <MessageSquare className="w-3.5 h-3.5" />
                  {startingChat ? 'Starting...' : 'START CHAT'}
                </button>
              </div>
            ) : (
              <div className="p-6 text-center rounded-xl bg-slate-950/60 border border-slate-800/80 text-slate-400 text-xs font-mono">
                <p className="text-slate-300 font-semibold mb-1">No registered user found.</p>
                <p className="text-slate-500 text-[11px]">
                  Ensure the exact email or phone number matches a registered user profile.
                </p>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
};

