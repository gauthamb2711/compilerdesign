import React from 'react';
import {
  X,
  Terminal,
  Code2,
  ChevronRight
} from 'lucide-react';
import { CompilerResult, ParseTreeNode } from '../../compiler/types';
import { compileMessage } from '../../compiler/compiler';
import { ClassificationBadge, ThreatBadge } from '../common/Badge';
import { ErrorBoundary } from '../common/ErrorBoundary';

interface CompilerAnalysisPanelProps {
  analysis?: CompilerResult | null;
  onClose?: () => void;
}

const renderParseTreeNode = (node?: ParseTreeNode | null, depth = 0) => {
  if (!node) return null;
  const children = Array.isArray(node.children) ? node.children : [];
  return (
    <div key={`${node.label || 'node'}_${depth}`} className="ml-3 my-1 border-l border-cyan-800/60 pl-2">
      <div className="flex items-center gap-1.5 text-xs font-mono text-cyan-300">
        <ChevronRight className="w-3 h-3 text-cyan-500" />
        <span className="font-bold">{node.label || 'ROOT'}</span>
        {node.value && <span className="text-slate-400 font-sans text-[11px]">: "{node.value}"</span>}
      </div>
      {children.length > 0 && (
        <div className="ml-2">
          {children.map((child, idx) => renderParseTreeNode(child, depth + 1))}
        </div>
      )}
    </div>
  );
};

export const CompilerAnalysisPanel: React.FC<CompilerAnalysisPanelProps> = ({
  analysis,
  onClose
}) => {
  if (!analysis || typeof analysis !== 'object') {
    return (
      <div className="w-full lg:w-[480px] bg-slate-950 border-l border-slate-800/80 flex flex-col h-full overflow-hidden shadow-2xl z-30 p-6 items-center justify-center text-center">
        <div className="p-3 rounded-2xl bg-slate-900 border border-slate-800 text-slate-500 mb-3">
          <Terminal className="w-8 h-8" />
        </div>
        <h3 className="text-sm font-bold text-slate-300 font-mono">No Analysis Available Yet</h3>
        <p className="text-xs text-slate-500 mt-1 max-w-xs">
          Select a message from the chat to inspect its 6-phase compiler pipeline and security AST analysis.
        </p>
        {onClose && (
          <button
            onClick={onClose}
            className="mt-4 px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs rounded-xl font-mono transition-colors"
          >
            Close Panel
          </button>
        )}
      </div>
    );
  }

  // Auto-recompile if raw text is present but 6-phase AST analysis is missing or partial
  let safeAnalysis = analysis;
  const targetRawText =
    analysis.originalText ||
    analysis.processedText ||
    (analysis as any).text ||
    '';

  if (
    targetRawText &&
    (!analysis.lexical || !Array.isArray(analysis.lexical.tokens) || analysis.lexical.tokens.length === 0)
  ) {
    try {
      safeAnalysis = compileMessage(targetRawText);
    } catch (e) {
      console.warn('Auto-recompile of message failed:', e);
    }
  }

  const originalText = safeAnalysis.originalText || targetRawText || '';

  const lexical = safeAnalysis.lexical || {
    tokens: [],
    urls: [],
    emails: [],
    phoneNumbers: [],
    keywords: [],
    tokenCount: 0
  };

  const syntax = safeAnalysis.syntax || {
    patternsDetected: [],
    suspiciousStructure: false,
    syntaxRisk: 0,
    parseTree: { label: 'PROGRAM', children: [] }
  };

  const semantic = safeAnalysis.semantic || {
    flags: {} as any,
    riskReasons: [],
    riskScore: 0,
    confidence: 100,
    classification: 'SAFE',
    threatLevel: 'LOW'
  };

  const intermediateCode = safeAnalysis.intermediateCode || {
    messageType: 'SAFE',
    riskScore: 0,
    threatLevel: 'LOW',
    flags: {} as any,
    operations: []
  };

  const optimization = safeAnalysis.optimization || {
    transformationsPerformed: [],
    removedUrls: [],
    optimizedText: originalText,
    removedUrlCount: 0
  };

  const codeGen = safeAnalysis.codeGen || {
    targetText: originalText,
    securityWarningRequired: false,
    warningHeader: '',
    warningReasons: [],
    classificationBadge: 'SAFE',
    confidence: 100,
    riskScore: 0,
    threatLevel: 'LOW'
  };

  const tokens = Array.isArray(lexical.tokens) ? lexical.tokens : [];
  const urls = Array.isArray(lexical.urls) ? lexical.urls : [];
  const patternsDetected = Array.isArray(syntax.patternsDetected) ? syntax.patternsDetected : [];
  const riskReasons = Array.isArray(semantic.riskReasons) ? semantic.riskReasons : [];
  const operations = Array.isArray(intermediateCode.operations) ? intermediateCode.operations : [];
  const transformationsPerformed = Array.isArray(optimization.transformationsPerformed)
    ? optimization.transformationsPerformed
    : [];
  const warningReasons = Array.isArray(codeGen.warningReasons) ? codeGen.warningReasons : [];

  return (
    <ErrorBoundary>
      <div className="w-full lg:w-[480px] bg-slate-950 border-l border-slate-800/80 flex flex-col h-full overflow-hidden shadow-2xl z-30">
        {/* Header */}
        <div className="p-4 border-b border-slate-800 bg-slate-900/90 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-xl bg-cyan-950 border border-cyan-800 text-cyan-400">
              <Terminal className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-white uppercase tracking-wider font-mono">
                Compiler Analysis
              </h3>
              <p className="text-[11px] text-slate-400">6-Phase Security & Compiler Pipeline</p>
            </div>
          </div>

          {onClose && (
            <button
              onClick={onClose}
              className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          )}
        </div>

        {/* Content Body */}
        <div className="flex-1 overflow-y-auto p-4 space-y-6 text-slate-200">
          {/* SOURCE PROGRAM */}
          <div className="p-3.5 bg-slate-900 border border-slate-800 rounded-xl">
            <div className="flex items-center justify-between mb-2">
              <span className="text-[11px] font-mono text-cyan-400 font-bold uppercase tracking-wider flex items-center gap-1.5">
                <Code2 className="w-3.5 h-3.5" /> Source Message
              </span>
              <span className="text-[10px] font-mono text-slate-500">INPUT</span>
            </div>
            <div className="p-2.5 bg-slate-950 rounded-lg text-xs font-mono text-slate-300 break-words border border-slate-800/60">
              "{originalText}"
            </div>
          </div>

          {/* PHASE 1: LEXICAL ANALYSIS */}
          <div className="p-4 bg-slate-900/80 border border-slate-800 rounded-xl space-y-3">
            <div className="flex items-center justify-between">
              <h4 className="text-xs font-bold font-mono text-cyan-400 flex items-center gap-2 uppercase">
                <span className="w-5 h-5 rounded bg-cyan-950 border border-cyan-800 flex items-center justify-center text-[10px]">
                  1
                </span>
                Lexical Analysis
              </h4>
              <span className="text-[10px] font-mono text-slate-400">
                Tokens: {lexical.tokenCount ?? tokens.length}
              </span>
            </div>

            <p className="text-[11px] text-slate-400">
              Tokenizes input string into categorized language tokens.
            </p>

            <div className="flex flex-wrap gap-1.5">
              {tokens.map((token, idx) => (
                <span
                  key={idx}
                  className="px-2 py-1 rounded bg-slate-950 border border-slate-800 text-[10px] font-mono flex items-center gap-1"
                >
                  <span className="text-cyan-400 font-semibold">{token.type}:</span>
                  <span className="text-slate-300">"{token.raw}"</span>
                </span>
              ))}
            </div>

            {urls.length > 0 && (
              <div className="p-2 bg-slate-950 rounded border border-slate-800/60 text-[11px] font-mono">
                <span className="text-amber-400 font-bold">Detected URLs: </span>
                {urls.join(', ')}
              </div>
            )}
          </div>

          {/* PHASE 2: SYNTAX ANALYSIS */}
          <div className="p-4 bg-slate-900/80 border border-slate-800 rounded-xl space-y-3">
            <div className="flex items-center justify-between">
              <h4 className="text-xs font-bold font-mono text-cyan-400 flex items-center gap-2 uppercase">
                <span className="w-5 h-5 rounded bg-cyan-950 border border-cyan-800 flex items-center justify-center text-[10px]">
                  2
                </span>
                Syntax Analysis
              </h4>
              <span className="text-[10px] font-mono text-amber-400">
                Risk: {syntax.syntaxRisk ?? 0}/100
              </span>
            </div>

            {patternsDetected.length > 0 ? (
              <div className="space-y-1.5">
                {patternsDetected.map((pattern, idx) => (
                  <div
                    key={idx}
                    className="p-2 bg-slate-950 border border-slate-800 rounded text-xs flex items-center justify-between"
                  >
                    <span className="font-mono text-cyan-300 font-bold">{pattern}</span>
                  </div>
                ))}
              </div>
            ) : (
              <p className="text-[11px] text-emerald-400 font-mono">No suspicious syntax patterns detected.</p>
            )}

            <div className="p-3 bg-slate-950 rounded border border-slate-800">
              <span className="text-[10px] font-mono text-slate-400 uppercase font-bold block mb-1">
                Generated Parse Tree
              </span>
              {renderParseTreeNode(syntax.parseTree)}
            </div>
          </div>

          {/* PHASE 3: SEMANTIC ANALYSIS */}
          <div className="p-4 bg-slate-900/80 border border-slate-800 rounded-xl space-y-3">
            <div className="flex items-center justify-between">
              <h4 className="text-xs font-bold font-mono text-cyan-400 flex items-center gap-2 uppercase">
                <span className="w-5 h-5 rounded bg-cyan-950 border border-cyan-800 flex items-center justify-center text-[10px]">
                  3
                </span>
                Semantic Analysis
              </h4>
              <ClassificationBadge type={semantic.classification ?? 'SAFE'} size="sm" />
            </div>

            <div className="grid grid-cols-2 gap-2 text-xs font-mono">
              <div className="p-2 bg-slate-950 rounded border border-slate-800">
                <span className="text-slate-500 block text-[10px]">Risk Score</span>
                <span className="text-base font-bold text-cyan-400">{semantic.riskScore ?? 0}/100</span>
              </div>
              <div className="p-2 bg-slate-950 rounded border border-slate-800">
                <span className="text-slate-500 block text-[10px]">Confidence</span>
                <span className="text-base font-bold text-emerald-400">{semantic.confidence ?? 100}%</span>
              </div>
            </div>

            <div className="space-y-1">
              <span className="text-[10px] font-mono text-slate-400 uppercase font-bold">Threat Reasons</span>
              {riskReasons.length > 0 ? (
                <ul className="list-disc list-inside text-xs text-slate-300 space-y-1">
                  {riskReasons.map((reason, idx) => (
                    <li key={idx}>{reason}</li>
                  ))}
                </ul>
              ) : (
                <p className="text-[11px] text-slate-500 font-mono">None</p>
              )}
            </div>
          </div>

          {/* PHASE 4: INTERMEDIATE CODE GENERATION */}
          <div className="p-4 bg-slate-900/80 border border-slate-800 rounded-xl space-y-3">
            <div className="flex items-center justify-between">
              <h4 className="text-xs font-bold font-mono text-cyan-400 flex items-center gap-2 uppercase">
                <span className="w-5 h-5 rounded bg-cyan-950 border border-cyan-800 flex items-center justify-center text-[10px]">
                  4
                </span>
                Intermediate Code (IR)
              </h4>
              <ThreatBadge level={intermediateCode.threatLevel ?? 'LOW'} />
            </div>

            <div className="p-2.5 bg-slate-950 rounded font-mono text-[11px] text-cyan-300 space-y-1 border border-slate-800">
              <div><span className="text-slate-500">messageType:</span> "{intermediateCode.messageType ?? 'SAFE'}"</div>
              <div><span className="text-slate-500">riskScore:</span> {intermediateCode.riskScore ?? 0}</div>
              <div><span className="text-slate-500">operations:</span> [{operations.map((op) => `"${op}"`).join(', ')}]</div>
            </div>
          </div>

          {/* PHASE 5: CODE OPTIMIZATION */}
          <div className="p-4 bg-slate-900/80 border border-slate-800 rounded-xl space-y-3">
            <div className="flex items-center justify-between">
              <h4 className="text-xs font-bold font-mono text-cyan-400 flex items-center gap-2 uppercase">
                <span className="w-5 h-5 rounded bg-cyan-950 border border-cyan-800 flex items-center justify-center text-[10px]">
                  5
                </span>
                Code Optimization
              </h4>
              <span className="text-[10px] font-mono text-amber-400">
                Removed Links: {optimization.removedUrlCount ?? 0}
              </span>
            </div>

            <p className="text-[11px] text-slate-400">
              Neutralizes dangerous links, masks credentials & normalizes spam.
            </p>

            {transformationsPerformed.length > 0 ? (
              <ul className="list-disc list-inside text-xs text-slate-300 space-y-1 font-mono">
                {transformationsPerformed.map((trans, idx) => (
                  <li key={idx}>{trans}</li>
                ))}
              </ul>
            ) : (
              <p className="text-[11px] text-slate-500 font-mono">No transformations required.</p>
            )}
          </div>

          {/* PHASE 6: CODE GENERATION & TARGET OUTPUT */}
          <div className="p-4 bg-slate-900/80 border border-slate-800 rounded-xl space-y-3">
            <div className="flex items-center justify-between">
              <h4 className="text-xs font-bold font-mono text-cyan-400 flex items-center gap-2 uppercase">
                <span className="w-5 h-5 rounded bg-cyan-950 border border-cyan-800 flex items-center justify-center text-[10px]">
                  6
                </span>
                Code Generation
              </h4>
              <span className="text-[10px] font-mono text-emerald-400 font-bold">TARGET GENERATED</span>
            </div>

            {codeGen.securityWarningRequired && (
              <div className="p-3 bg-red-950/40 border border-red-800/80 rounded-xl space-y-1.5">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-red-400 font-mono">{codeGen.warningHeader || 'Security Notice'}</span>
                </div>
                {warningReasons.length > 0 && (
                  <ul className="list-disc list-inside text-xs text-red-300/80">
                    {warningReasons.map((r, idx) => (
                      <li key={idx}>{r}</li>
                    ))}
                  </ul>
                )}
              </div>
            )}

            <div className="p-3 bg-slate-950 rounded-xl border border-slate-800 text-xs font-mono text-slate-100">
              <span className="text-[10px] text-slate-500 block mb-1">PROCESSED TARGET OUTPUT:</span>
              "{codeGen.targetText || originalText}"
            </div>
          </div>
        </div>
      </div>
    </ErrorBoundary>
  );
};

