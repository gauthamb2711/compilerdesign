import React from 'react';
import {
  Binary,
  BookOpen,
  Boxes,
  Code2,
  Cpu,
  GitBranch,
  History,
  Layers,
  Sparkles,
  Table,
  Terminal,
  Zap
} from 'lucide-react';

export type WorkbenchView =
  | 'workbench'
  | 'pipeline'
  | 'tokens'
  | 'parsetree'
  | 'symbols'
  | 'ir'
  | 'optimization'
  | 'targetcode'
  | 'grammar'
  | 'history';

interface CompilerHeaderProps {
  currentView: WorkbenchView;
  onSelectView: (view: WorkbenchView) => void;
  isCompiling: boolean;
  onRunCompile: () => void;
  historyCount: number;
}

export const CompilerHeader: React.FC<CompilerHeaderProps> = ({
  currentView,
  onSelectView,
  isCompiling,
  onRunCompile,
  historyCount
}) => {
  const navItems: { id: WorkbenchView; label: string; icon: React.ReactNode; badge?: string | number }[] = [
    { id: 'workbench', label: 'Workbench', icon: <Terminal className="w-3.5 h-3.5" /> },
    { id: 'pipeline', label: 'Pipeline', icon: <Layers className="w-3.5 h-3.5" /> },
    { id: 'tokens', label: 'Tokens', icon: <Boxes className="w-3.5 h-3.5" /> },
    { id: 'parsetree', label: 'Parse Tree', icon: <GitBranch className="w-3.5 h-3.5" /> },
    { id: 'symbols', label: 'Symbol Table', icon: <Table className="w-3.5 h-3.5" /> },
    { id: 'ir', label: 'Intermediate Code', icon: <Code2 className="w-3.5 h-3.5" /> },
    { id: 'optimization', label: 'Optimization', icon: <Zap className="w-3.5 h-3.5" /> },
    { id: 'targetcode', label: 'Target Code', icon: <Binary className="w-3.5 h-3.5" /> },
    { id: 'grammar', label: 'Grammar', icon: <BookOpen className="w-3.5 h-3.5" /> },
    { id: 'history', label: 'History', icon: <History className="w-3.5 h-3.5" />, badge: historyCount }
  ];

  return (
    <header className="bg-white border-b border-slate-200 sticky top-0 z-30 shadow-xs">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="h-16 flex items-center justify-between gap-4">
          {/* Brand Identity */}
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-lg bg-indigo-600 flex items-center justify-center text-white shadow-xs font-mono font-bold text-sm">
              <Cpu className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="font-bold tracking-tight text-base text-slate-900">
                  SecureChat Compiler
                </span>
                <span className="text-[10px] font-mono uppercase bg-indigo-50 text-indigo-700 font-semibold px-2 py-0.5 rounded border border-indigo-200/80">
                  Workbench v2.4
                </span>
              </div>
              <p className="text-[11px] text-slate-500 font-medium">
                Interactive 6-Phase Compiler Design & Language Analyzer
              </p>
            </div>
          </div>

          {/* Quick Action Button */}
          <div className="flex items-center gap-2">
            <button
              id="header-run-compile-btn"
              onClick={onRunCompile}
              disabled={isCompiling}
              className={`px-4 py-2 text-xs font-semibold rounded-lg flex items-center gap-2 transition-all shadow-xs ${
                isCompiling
                  ? 'bg-indigo-400 text-white cursor-not-allowed'
                  : 'bg-indigo-600 hover:bg-indigo-700 text-white hover:shadow-indigo-100'
              }`}
            >
              <Sparkles className={`w-3.5 h-3.5 ${isCompiling ? 'animate-spin' : ''}`} />
              <span>{isCompiling ? 'Compiling Pipeline...' : 'Run Compiler (F5)'}</span>
            </button>
          </div>
        </div>

        {/* Horizontal Navigation Tabs */}
        <nav className="flex items-center gap-1 overflow-x-auto no-scrollbar border-t border-slate-100 py-1.5 -mx-4 px-4 sm:mx-0 sm:px-0">
          {navItems.map((item) => {
            const active = currentView === item.id;
            return (
              <button
                key={item.id}
                id={`nav-tab-${item.id}`}
                onClick={() => onSelectView(item.id)}
                className={`px-3 py-1.5 rounded-md text-xs font-medium flex items-center gap-1.5 whitespace-nowrap transition-colors ${
                  active
                    ? 'bg-indigo-50 text-indigo-700 font-semibold border border-indigo-200/60'
                    : 'text-slate-600 hover:text-slate-900 hover:bg-slate-50 border border-transparent'
                }`}
              >
                <span className={active ? 'text-indigo-600' : 'text-slate-400'}>
                  {item.icon}
                </span>
                <span>{item.label}</span>
                {item.badge !== undefined && Number(item.badge) > 0 && (
                  <span className="text-[10px] font-mono px-1.5 py-0.2 rounded-full bg-slate-100 text-slate-600 border border-slate-200">
                    {item.badge}
                  </span>
                )}
              </button>
            );
          })}
        </nav>
      </div>
    </header>
  );
};
