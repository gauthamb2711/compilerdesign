import React, { useState } from 'react';
import { BookOpen, Code2, GitBranch, Layers, Search, Sparkles } from 'lucide-react';
import { GRAMMAR_RULES } from '../../compiler/parser';

export const GrammarExplorer: React.FC = () => {
  const [search, setSearch] = useState('');

  const terminals = [
    'message', 'send', 'url', 'IDENTIFIER', 'STRING_LITERAL', 'NUMBER_LITERAL',
    'URL_LITERAL', '(', ')', ';', ',', '=', '+', '-', '*', '/'
  ];

  const nonTerminals = [
    'S (Start)', 'PROGRAM', 'STATEMENT_LIST', 'STATEMENT', 'MESSAGE_DECL',
    'ARG_LIST', 'SECURITY_PHRASE', 'URL_EXPRESSION', 'EXPRESSION'
  ];

  const filteredRules = GRAMMAR_RULES.filter(
    (r) =>
      r.raw.toLowerCase().includes(search.toLowerCase()) ||
      r.head.toLowerCase().includes(search.toLowerCase()) ||
      (r.description && r.description.toLowerCase().includes(search.toLowerCase()))
  );

  return (
    <div className="space-y-6">
      {/* Banner */}
      <div className="bg-slate-50 border border-slate-200 rounded-xl p-5 space-y-2">
        <div className="flex items-center gap-2">
          <BookOpen className="w-5 h-5 text-indigo-600" />
          <h2 className="text-base font-bold text-slate-900 tracking-tight">
            Formal Context-Free Grammar (CFG) Explorer
          </h2>
        </div>
        <p className="text-xs text-slate-600 max-w-3xl leading-relaxed">
          The SecureChat Language Specification is defined as a 4-tuple <span className="font-mono font-semibold text-indigo-700">G = (V, Σ, R, S)</span> where <strong className="text-slate-800">V</strong> represents the non-terminals, <strong className="text-slate-800">Σ</strong> represents the terminal alphabet, <strong className="text-slate-800">R</strong> denotes production rewrite rules, and <strong className="text-slate-800">S</strong> is the start axiom.
        </p>
      </div>

      {/* Grammar Components Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {/* Terminals Set */}
        <div className="bg-white border border-slate-200 rounded-xl p-4 space-y-3 shadow-2xs">
          <div className="flex items-center justify-between">
            <span className="text-xs font-mono font-bold uppercase text-slate-700">
              TERMINALS (Σ) — TOKENS & ALPHABET
            </span>
            <span className="text-[10px] font-mono text-slate-400">{terminals.length} Terminals</span>
          </div>
          <div className="flex flex-wrap gap-1.5">
            {terminals.map((term, i) => (
              <span
                key={i}
                className="px-2 py-1 rounded bg-slate-100 border border-slate-200 font-mono text-xs text-slate-800 font-semibold"
              >
                {term}
              </span>
            ))}
          </div>
        </div>

        {/* Non-Terminals Set */}
        <div className="bg-white border border-slate-200 rounded-xl p-4 space-y-3 shadow-2xs">
          <div className="flex items-center justify-between">
            <span className="text-xs font-mono font-bold uppercase text-slate-700">
              NON-TERMINALS (V) — SYNTACTIC VARIABLES
            </span>
            <span className="text-[10px] font-mono text-slate-400">{nonTerminals.length} Variables</span>
          </div>
          <div className="flex flex-wrap gap-1.5">
            {nonTerminals.map((nt, i) => (
              <span
                key={i}
                className="px-2 py-1 rounded bg-indigo-50 border border-indigo-200 font-mono text-xs text-indigo-700 font-semibold"
              >
                {nt}
              </span>
            ))}
          </div>
        </div>
      </div>

      {/* Production Rules List */}
      <div className="bg-white border border-slate-200 rounded-xl overflow-hidden shadow-2xs space-y-3 p-4">
        <div className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-100 pb-3">
          <div className="flex items-center gap-2">
            <Code2 className="w-4 h-4 text-indigo-600" />
            <h3 className="text-xs font-mono font-bold uppercase text-slate-800">
              PRODUCTION REWRITE RULES (R)
            </h3>
          </div>

          <div className="flex items-center gap-2">
            <Search className="w-3.5 h-3.5 text-slate-400" />
            <input
              type="text"
              placeholder="Search grammar rules..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="text-xs font-mono bg-white border border-slate-200 rounded-md px-2.5 py-1 text-slate-700"
            />
          </div>
        </div>

        <div className="space-y-2.5">
          {filteredRules.map((rule) => (
            <div
              key={rule.id}
              className="p-3.5 rounded-lg border border-slate-200 bg-slate-50 font-mono text-xs space-y-1.5 hover:border-indigo-200 transition-colors"
            >
              <div className="flex items-center justify-between">
                <span className="font-bold text-indigo-900 text-sm">{rule.raw}</span>
                <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-indigo-100 text-indigo-800">
                  {rule.id}
                </span>
              </div>
              <p className="text-[11px] text-slate-600 font-sans">{rule.description}</p>
              <div className="text-[10px] text-slate-400 font-mono pt-1">
                Head: <strong className="text-slate-600">{rule.head}</strong> • Body symbols:{' '}
                {rule.body.join(' ')}
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
