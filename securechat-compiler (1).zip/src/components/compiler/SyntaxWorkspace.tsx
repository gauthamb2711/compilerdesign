import React, { useState } from 'react';
import {
  AlertTriangle,
  BookOpen,
  ChevronDown,
  ChevronRight,
  GitBranch,
  GitCommit,
  Layers,
  ZoomIn,
  ZoomOut
} from 'lucide-react';
import { ParseTreeNode, SyntaxResult } from '../../compiler/types';

interface SyntaxWorkspaceProps {
  syntax: SyntaxResult;
}

const TreeNodeView: React.FC<{ node: ParseTreeNode; depth?: number }> = ({ node, depth = 0 }) => {
  const [expanded, setExpanded] = useState<boolean>(true);
  const hasChildren = node.children && node.children.length > 0;

  return (
    <div className="space-y-1">
      <div
        className="flex items-center gap-1.5 py-1 px-2 rounded-lg hover:bg-slate-100/80 cursor-pointer transition-colors select-none font-mono text-xs w-fit"
        style={{ marginLeft: `${depth * 20}px` }}
        onClick={() => hasChildren && setExpanded(!expanded)}
      >
        {hasChildren ? (
          <span className="text-slate-400">
            {expanded ? <ChevronDown className="w-3.5 h-3.5" /> : <ChevronRight className="w-3.5 h-3.5" />}
          </span>
        ) : (
          <span className="w-3.5 flex justify-center text-slate-300">
            <GitCommit className="w-3 h-3" />
          </span>
        )}

        <span
          className={`px-2 py-0.5 rounded text-[11px] font-semibold border ${
            node.type === 'NON_TERMINAL' || !node.type
              ? 'bg-indigo-50 text-indigo-700 border-indigo-200'
              : node.type === 'STATEMENT'
              ? 'bg-violet-50 text-violet-700 border-violet-200'
              : node.type === 'EXPRESSION'
              ? 'bg-sky-50 text-sky-700 border-sky-200'
              : node.type === 'LITERAL'
              ? 'bg-emerald-50 text-emerald-700 border-emerald-200'
              : 'bg-slate-100 text-slate-700 border-slate-200'
          }`}
        >
          {node.label}
        </span>

        {node.value && (
          <span className="text-slate-600 font-normal bg-slate-50 border border-slate-200/80 px-2 py-0.5 rounded text-[11px]">
            "{node.value}"
          </span>
        )}
      </div>

      {hasChildren && expanded && (
        <div className="border-l-2 border-slate-200 ml-4 pl-1 space-y-1">
          {node.children!.map((child, idx) => (
            <TreeNodeView key={idx} node={child} depth={0} />
          ))}
        </div>
      )}
    </div>
  );
};

export const SyntaxWorkspace: React.FC<SyntaxWorkspaceProps> = ({ syntax }) => {
  const [treeMode, setTreeMode] = useState<'AST' | 'CST'>('AST');

  return (
    <div className="space-y-4">
      {/* Top Controls for Visualizer */}
      <div className="bg-slate-50 border border-slate-200 rounded-xl p-3.5 flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-2">
          <GitBranch className="w-4 h-4 text-indigo-600" />
          <span className="text-xs font-bold font-mono uppercase text-slate-700">
            PARSER SYNTAX TREE VIEWER
          </span>
        </div>

        {/* Tree Mode Selector */}
        <div className="flex items-center gap-2">
          <div className="bg-white border border-slate-200 p-0.5 rounded-lg flex items-center gap-1 text-xs font-mono">
            <button
              onClick={() => setTreeMode('AST')}
              className={`px-3 py-1 rounded-md font-semibold transition-colors ${
                treeMode === 'AST'
                  ? 'bg-indigo-600 text-white shadow-2xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Abstract Syntax Tree (AST)
            </button>
            <button
              onClick={() => setTreeMode('CST')}
              className={`px-3 py-1 rounded-md font-semibold transition-colors ${
                treeMode === 'CST'
                  ? 'bg-indigo-600 text-white shadow-2xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Concrete Parse Tree (CST)
            </button>
          </div>
        </div>
      </div>

      {/* Main Parse Tree Canvas Viewer */}
      <div className="bg-white border border-slate-200 rounded-xl p-4 shadow-2xs overflow-x-auto min-h-64">
        <div className="mb-3 pb-2 border-b border-slate-100 flex items-center justify-between text-[11px] font-mono text-slate-400">
          <span>Hierarchy Root: {treeMode === 'AST' ? 'AST::Root' : 'CST::Program'}</span>
          <span>Click nodes with arrows to expand / collapse branches</span>
        </div>

        <div className="p-2">
          <TreeNodeView node={treeMode === 'AST' ? syntax.ast : syntax.parseTree} />
        </div>
      </div>

      {/* Grammar Production Rules & Derivations Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {/* Grammar Rules Section */}
        <div className="bg-white border border-slate-200 rounded-xl p-4 space-y-3 shadow-2xs">
          <div className="flex items-center gap-2">
            <BookOpen className="w-4 h-4 text-indigo-600" />
            <h4 className="text-xs font-bold font-mono uppercase text-slate-800">
              ACTIVE GRAMMAR PRODUCTION RULES
            </h4>
          </div>

          <div className="space-y-2 max-h-56 overflow-y-auto">
            {syntax.grammarRulesUsed.map((rule, idx) => (
              <div
                key={idx}
                className="p-2.5 bg-slate-50 border border-slate-200 rounded-lg space-y-1 font-mono text-xs"
              >
                <div className="flex items-center justify-between">
                  <span className="text-indigo-700 font-bold">{rule.raw}</span>
                  <span className="text-[10px] bg-slate-200/80 px-1.5 py-0.2 rounded text-slate-700">
                    {rule.id}
                  </span>
                </div>
                {rule.description && (
                  <p className="text-[11px] text-slate-500 font-sans">{rule.description}</p>
                )}
              </div>
            ))}
          </div>
        </div>

        {/* Leftmost Derivation & Syntactic Patterns */}
        <div className="bg-white border border-slate-200 rounded-xl p-4 space-y-3 shadow-2xs">
          <div className="flex items-center gap-2">
            <Layers className="w-4 h-4 text-violet-600" />
            <h4 className="text-xs font-bold font-mono uppercase text-slate-800">
              SYNTACTIC PATTERNS & DERIVATION
            </h4>
          </div>

          {syntax.derivationSteps && (
            <div className="space-y-1 bg-slate-50 border border-slate-200 rounded-lg p-3 font-mono text-xs text-slate-700">
              <span className="text-[10px] uppercase font-bold text-slate-400 block mb-1">
                Leftmost Derivation Sequence:
              </span>
              {syntax.derivationSteps.map((step, idx) => (
                <div key={idx} className="text-indigo-900 font-semibold">
                  {step}
                </div>
              ))}
            </div>
          )}

          <div className="space-y-1.5 pt-1">
            <span className="text-[10px] font-mono uppercase font-bold text-slate-500 block">
              Recognized Structural Constructs:
            </span>
            <div className="flex flex-wrap gap-1.5">
              {syntax.patternsDetected.map((pattern, idx) => (
                <span
                  key={idx}
                  className="px-2 py-1 rounded bg-indigo-50 border border-indigo-200 text-indigo-700 font-mono text-xs"
                >
                  {pattern}
                </span>
              ))}
              {syntax.patternsDetected.length === 0 && (
                <span className="text-xs font-mono text-slate-400 italic">
                  Standard sentence structure
                </span>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
