import React from 'react';
import { Check, Clock, History, Play, Trash2, X } from 'lucide-react';
import { CompilerResult } from '../../compiler/types';

export interface HistoryItem {
  id: string;
  timestamp: string;
  sourceCode: string;
  result: CompilerResult;
}

interface CompilationHistoryModalProps {
  history: HistoryItem[];
  onSelectRun: (item: HistoryItem) => void;
  onClearHistory: () => void;
}

export const CompilationHistoryModal: React.FC<CompilationHistoryModalProps> = ({
  history,
  onSelectRun,
  onClearHistory
}) => {
  return (
    <div className="bg-white border border-slate-200 rounded-xl p-5 space-y-4 shadow-2xs">
      <div className="flex items-center justify-between border-b border-slate-100 pb-3">
        <div className="flex items-center gap-2">
          <History className="w-5 h-5 text-indigo-600" />
          <h3 className="text-sm font-mono font-bold uppercase text-slate-800">
            COMPILATION RUNS HISTORY ({history.length})
          </h3>
        </div>

        {history.length > 0 && (
          <button
            onClick={onClearHistory}
            className="text-xs font-mono text-rose-600 hover:text-rose-700 flex items-center gap-1 bg-rose-50 px-2.5 py-1 rounded-md border border-rose-200"
          >
            <Trash2 className="w-3.5 h-3.5" />
            <span>Clear History</span>
          </button>
        )}
      </div>

      <div className="space-y-3 max-h-96 overflow-y-auto">
        {history.map((item, idx) => (
          <div
            key={item.id}
            className="p-3.5 bg-slate-50 border border-slate-200 rounded-xl space-y-2 hover:border-indigo-300 transition-colors"
          >
            <div className="flex items-center justify-between font-mono text-xs">
              <div className="flex items-center gap-2">
                <span className="font-bold text-slate-900">Run #{history.length - idx}</span>
                <span className="text-[10px] text-slate-400">[{item.timestamp}]</span>
              </div>
              <div className="flex items-center gap-2">
                <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-indigo-100 text-indigo-800">
                  {item.result.classification}
                </span>
                <button
                  onClick={() => onSelectRun(item)}
                  className="px-3 py-1 rounded text-xs font-semibold bg-indigo-600 text-white hover:bg-indigo-700 transition-colors flex items-center gap-1 shadow-2xs"
                >
                  <Play className="w-3 h-3 fill-current" />
                  <span>Load into Studio</span>
                </button>
              </div>
            </div>

            <p className="text-xs font-mono text-slate-700 truncate bg-white p-2 rounded border border-slate-200/80">
              {item.sourceCode}
            </p>

            <div className="flex items-center gap-4 text-[11px] font-mono text-slate-500 pt-1">
              <span>{item.result.statistics.tokensGenerated} Tokens</span>
              <span>{item.result.statistics.syntaxNodes} AST Nodes</span>
              <span>{item.result.statistics.optimizationsApplied} Passes</span>
              <span>{item.result.statistics.compilationTimeMs} ms</span>
            </div>
          </div>
        ))}

        {history.length === 0 && (
          <div className="text-center py-12 text-slate-400 font-mono text-xs">
            No previous compilation runs recorded. Click "Run Compiler" to generate your first run.
          </div>
        )}
      </div>
    </div>
  );
};
