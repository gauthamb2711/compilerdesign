import React, { useState } from 'react';
import { Boxes, Filter, Hash, Search, Tag } from 'lucide-react';
import { LexicalResult, Token, TokenType } from '../../compiler/types';

interface LexicalWorkspaceProps {
  lexical: LexicalResult;
}

export const LexicalWorkspace: React.FC<LexicalWorkspaceProps> = ({ lexical }) => {
  const [selectedToken, setSelectedToken] = useState<Token | null>(lexical.tokens[0] || null);
  const [categoryFilter, setCategoryFilter] = useState<string>('ALL');
  const [searchQuery, setSearchQuery] = useState<string>('');

  const filteredTokens = lexical.tokens.filter((t) => {
    const matchesCat =
      categoryFilter === 'ALL' ||
      t.category === categoryFilter ||
      t.type === categoryFilter;
    const matchesSearch =
      searchQuery === '' ||
      t.raw.toLowerCase().includes(searchQuery.toLowerCase()) ||
      t.type.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesCat && matchesSearch;
  });

  const categories = Array.from(
    new Set(lexical.tokens.map((t) => t.category || t.type))
  );

  return (
    <div className="space-y-4">
      {/* Metrics Banner */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        <div className="bg-slate-50 border border-slate-200 rounded-lg p-3">
          <div className="text-[10px] font-mono uppercase text-slate-500 font-semibold">Total Tokens</div>
          <div className="text-xl font-bold font-mono text-slate-900 mt-1">{lexical.tokenCount}</div>
        </div>
        <div className="bg-slate-50 border border-slate-200 rounded-lg p-3">
          <div className="text-[10px] font-mono uppercase text-slate-500 font-semibold">Identifiers</div>
          <div className="text-xl font-bold font-mono text-indigo-600 mt-1">{lexical.identifierCount || 0}</div>
        </div>
        <div className="bg-slate-50 border border-slate-200 rounded-lg p-3">
          <div className="text-[10px] font-mono uppercase text-slate-500 font-semibold">Literals & URLs</div>
          <div className="text-xl font-bold font-mono text-violet-600 mt-1">{lexical.literalCount || 0}</div>
        </div>
        <div className="bg-slate-50 border border-slate-200 rounded-lg p-3">
          <div className="text-[10px] font-mono uppercase text-slate-500 font-semibold">Operators / Delimiters</div>
          <div className="text-xl font-bold font-mono text-slate-700 mt-1">
            {(lexical.operatorCount || 0) + (lexical.delimiterCount || 0)}
          </div>
        </div>
      </div>

      {/* Token Stream Badge Ribbon */}
      <div className="bg-slate-50 border border-slate-200 rounded-xl p-3.5 space-y-2">
        <div className="flex items-center justify-between">
          <span className="text-[11px] font-mono uppercase font-bold text-slate-600 flex items-center gap-1.5">
            <Boxes className="w-3.5 h-3.5 text-indigo-600" />
            TOKEN STREAM INSPECTOR (CLICK TOKEN TO INSPECT)
          </span>
          <span className="text-[10px] font-mono text-slate-400">Sequence: Left-to-Right</span>
        </div>

        <div className="flex flex-wrap gap-1.5 p-2 bg-white rounded-lg border border-slate-200 max-h-36 overflow-y-auto">
          {lexical.tokens.map((token, idx) => {
            const isSelected = selectedToken?.index === token.index;
            return (
              <button
                key={idx}
                id={`token-badge-${idx}`}
                onClick={() => setSelectedToken(token)}
                className={`px-2 py-1 rounded text-xs font-mono transition-all flex items-center gap-1 border ${
                  isSelected
                    ? 'bg-indigo-600 text-white border-indigo-700 shadow-xs'
                    : token.category === 'URL_LITERAL' || token.type === 'URL'
                    ? 'bg-rose-50 text-rose-700 border-rose-200 hover:bg-rose-100'
                    : token.category === 'SECURITY_TOKEN'
                    ? 'bg-amber-50 text-amber-800 border-amber-200 hover:bg-amber-100'
                    : token.category === 'STRING_LITERAL'
                    ? 'bg-emerald-50 text-emerald-700 border-emerald-200 hover:bg-emerald-100'
                    : token.category === 'KEYWORD'
                    ? 'bg-indigo-50 text-indigo-700 border-indigo-200 hover:bg-indigo-100'
                    : 'bg-slate-100 text-slate-700 border-slate-200 hover:bg-slate-200'
                }`}
              >
                <span className="text-[9.5px] opacity-70">#{idx}</span>
                <span className="font-semibold">{token.raw}</span>
              </button>
            );
          })}
        </div>
      </div>

      {/* Selected Token Detail Inspector */}
      {selectedToken && (
        <div className="bg-indigo-50/50 border border-indigo-200/80 rounded-xl p-3 flex flex-wrap items-center justify-between gap-4 text-xs font-mono text-slate-700">
          <div className="flex items-center gap-3">
            <span className="font-bold text-indigo-900 bg-indigo-100 px-2 py-0.5 rounded">
              Selected: &lt;{selectedToken.category || selectedToken.type}, "{selectedToken.raw}"&gt;
            </span>
          </div>
          <div className="flex items-center gap-4 text-[11px] text-slate-600">
            <span>Line: <strong className="text-slate-900">{selectedToken.line}</strong></span>
            <span>Column: <strong className="text-slate-900">{selectedToken.col}</strong></span>
            <span>Index: <strong className="text-slate-900">{selectedToken.index}</strong></span>
            <span>Category: <strong className="text-indigo-700">{selectedToken.category || selectedToken.type}</strong></span>
          </div>
        </div>
      )}

      {/* Detailed Lexeme Table */}
      <div className="bg-white border border-slate-200 rounded-xl overflow-hidden shadow-2xs">
        {/* Table Filters */}
        <div className="bg-slate-50 border-b border-slate-200 p-3 flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-2 flex-1 max-w-sm">
            <Search className="w-3.5 h-3.5 text-slate-400" />
            <input
              type="text"
              placeholder="Search lexemes or types..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full text-xs font-mono bg-white border border-slate-200 rounded-md px-2.5 py-1 text-slate-700 focus:outline-hidden focus:ring-1 focus:ring-indigo-500"
            />
          </div>

          <div className="flex items-center gap-2">
            <Filter className="w-3.5 h-3.5 text-slate-400" />
            <select
              value={categoryFilter}
              onChange={(e) => setCategoryFilter(e.target.value)}
              className="text-xs font-mono bg-white border border-slate-200 rounded-md px-2 py-1 text-slate-700"
            >
              <option value="ALL">All Categories ({lexical.tokens.length})</option>
              {categories.map((c) => (
                <option key={c} value={c}>
                  {c}
                </option>
              ))}
            </select>
          </div>
        </div>

        {/* Table Content */}
        <div className="overflow-x-auto max-h-80 overflow-y-auto">
          <table className="w-full text-left text-xs font-mono">
            <thead className="bg-slate-50 border-b border-slate-200 text-[11px] text-slate-500 uppercase tracking-wider sticky top-0">
              <tr>
                <th className="px-4 py-2.5">Idx</th>
                <th className="px-4 py-2.5">Lexeme Value</th>
                <th className="px-4 py-2.5">Token Category</th>
                <th className="px-4 py-2.5">Type Classification</th>
                <th className="px-4 py-2.5">Location</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filteredTokens.map((token, i) => (
                <tr
                  key={i}
                  onClick={() => setSelectedToken(token)}
                  className={`cursor-pointer transition-colors ${
                    selectedToken?.index === token.index
                      ? 'bg-indigo-50/60 font-semibold'
                      : 'hover:bg-slate-50'
                  }`}
                >
                  <td className="px-4 py-2 text-slate-400">#{token.index}</td>
                  <td className="px-4 py-2 font-bold text-slate-800">{token.raw}</td>
                  <td className="px-4 py-2">
                    <span className="px-1.5 py-0.5 rounded text-[10px] bg-slate-100 border border-slate-200 text-slate-700">
                      {token.category || 'TOKEN'}
                    </span>
                  </td>
                  <td className="px-4 py-2 text-indigo-600">{token.type}</td>
                  <td className="px-4 py-2 text-slate-400">
                    L{token.line}:C{token.col}
                  </td>
                </tr>
              ))}
              {filteredTokens.length === 0 && (
                <tr>
                  <td colSpan={5} className="px-4 py-6 text-center text-slate-400 italic">
                    No tokens match the selected filter.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
