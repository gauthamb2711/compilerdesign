import React, { useState } from 'react';
import {
  AlertCircle,
  AlertTriangle,
  CheckCircle2,
  ChevronDown,
  ChevronUp,
  Copy,
  Info,
  Terminal,
  Trash2
} from 'lucide-react';
import { CompilerConsoleLog } from '../../compiler/types';

interface CompilerConsoleProps {
  logs: CompilerConsoleLog[];
  processedText: string;
  onClearLogs?: () => void;
}

export const CompilerConsole: React.FC<CompilerConsoleProps> = ({
  logs,
  processedText,
  onClearLogs
}) => {
  const [isExpanded, setIsExpanded] = useState<boolean>(true);
  const [activeTab, setActiveTab] = useState<'ALL' | 'ERRORS' | 'WARNINGS' | 'OUTPUT'>('ALL');
  const [copied, setCopied] = useState(false);

  const errors = logs.filter((l) => l.type === 'ERROR');
  const warnings = logs.filter((l) => l.type === 'WARNING');

  const filteredLogs = logs.filter((l) => {
    if (activeTab === 'ERRORS') return l.type === 'ERROR';
    if (activeTab === 'WARNINGS') return l.type === 'WARNING';
    return true;
  });

  const handleCopyOutput = async () => {
    try {
      await navigator.clipboard.writeText(processedText);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch (err) {
      console.error('Failed to copy', err);
    }
  };

  return (
    <div className="bg-white border border-slate-200 rounded-xl overflow-hidden shadow-2xs">
      {/* Console Top Header */}
      <div className="bg-slate-50 border-b border-slate-200 px-4 py-2.5 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="flex items-center gap-1.5 text-xs font-mono font-bold text-slate-800">
            <Terminal className="w-4 h-4 text-indigo-600" />
            <span>COMPILER CONSOLE</span>
          </div>

          {/* Console Tabs */}
          <div className="flex items-center gap-1">
            <button
              onClick={() => setActiveTab('ALL')}
              className={`px-2.5 py-1 rounded text-xs font-mono transition-colors ${
                activeTab === 'ALL'
                  ? 'bg-slate-200 text-slate-900 font-semibold'
                  : 'text-slate-500 hover:text-slate-800'
              }`}
            >
              All Logs ({logs.length})
            </button>
            <button
              onClick={() => setActiveTab('ERRORS')}
              className={`px-2.5 py-1 rounded text-xs font-mono transition-colors flex items-center gap-1 ${
                activeTab === 'ERRORS'
                  ? 'bg-rose-100 text-rose-800 font-semibold'
                  : 'text-slate-500 hover:text-rose-700'
              }`}
            >
              <AlertCircle className="w-3 h-3 text-rose-600" />
              <span>Errors ({errors.length})</span>
            </button>
            <button
              onClick={() => setActiveTab('WARNINGS')}
              className={`px-2.5 py-1 rounded text-xs font-mono transition-colors flex items-center gap-1 ${
                activeTab === 'WARNINGS'
                  ? 'bg-amber-100 text-amber-800 font-semibold'
                  : 'text-slate-500 hover:text-amber-700'
              }`}
            >
              <AlertTriangle className="w-3 h-3 text-amber-600" />
              <span>Warnings ({warnings.length})</span>
            </button>
            <button
              onClick={() => setActiveTab('OUTPUT')}
              className={`px-2.5 py-1 rounded text-xs font-mono transition-colors flex items-center gap-1 ${
                activeTab === 'OUTPUT'
                  ? 'bg-emerald-100 text-emerald-800 font-semibold'
                  : 'text-slate-500 hover:text-emerald-700'
              }`}
            >
              <CheckCircle2 className="w-3 h-3 text-emerald-600" />
              <span>Final Target Output</span>
            </button>
          </div>
        </div>

        {/* Toggle Expand / Collapse */}
        <div className="flex items-center gap-2">
          <button
            onClick={() => setIsExpanded(!isExpanded)}
            className="p-1 text-slate-500 hover:text-slate-800 hover:bg-slate-200 rounded transition-colors"
          >
            {isExpanded ? <ChevronDown className="w-4 h-4" /> : <ChevronUp className="w-4 h-4" />}
          </button>
        </div>
      </div>

      {/* Console Content Area */}
      {isExpanded && (
        <div className="p-3 bg-slate-950 text-slate-200 font-mono text-xs max-h-56 overflow-y-auto space-y-1.5">
          {activeTab === 'OUTPUT' ? (
            <div className="space-y-2 p-1">
              <div className="flex items-center justify-between text-[11px] text-slate-400 border-b border-slate-800 pb-1">
                <span>COMPILED TARGET PAYLOAD STREAM</span>
                <button
                  onClick={handleCopyOutput}
                  className="text-cyan-400 hover:text-cyan-300 transition-colors flex items-center gap-1"
                >
                  <Copy className="w-3 h-3" />
                  <span>{copied ? 'Copied' : 'Copy'}</span>
                </button>
              </div>
              <p className="text-emerald-300 font-sans text-sm leading-relaxed whitespace-pre-wrap">
                {processedText}
              </p>
            </div>
          ) : (
            filteredLogs.map((log) => (
              <div
                key={log.id}
                className="flex items-start gap-2.5 py-0.5 leading-relaxed hover:bg-slate-900 px-1.5 rounded"
              >
                <span className="text-slate-500 select-none text-[10px]">[{log.timestamp}]</span>
                <span
                  className={`text-[10px] font-bold px-1.5 py-0.2 rounded shrink-0 ${
                    log.type === 'ERROR'
                      ? 'bg-rose-500/20 text-rose-300 border border-rose-500/40'
                      : log.type === 'WARNING'
                      ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40'
                      : log.type === 'SUCCESS'
                      ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40'
                      : 'bg-indigo-500/20 text-indigo-300 border border-indigo-500/40'
                  }`}
                >
                  P{log.phase}: {log.type}
                </span>
                <span className="text-slate-300 flex-1">{log.message}</span>
              </div>
            ))
          )}

          {filteredLogs.length === 0 && activeTab !== 'OUTPUT' && (
            <div className="text-slate-500 italic py-3 text-center">
              No console logs for selected filter.
            </div>
          )}
        </div>
      )}
    </div>
  );
};
