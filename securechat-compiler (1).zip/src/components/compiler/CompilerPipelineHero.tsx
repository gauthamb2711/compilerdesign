import React from 'react';
import {
  ArrowRight,
  Binary,
  Boxes,
  CheckCircle2,
  Code2,
  Cpu,
  GitBranch,
  Table,
  Zap
} from 'lucide-react';
import { CompilerResult } from '../../compiler/types';

interface CompilerPipelineHeroProps {
  compilerResult: CompilerResult | null;
  activePhase: number;
  onSelectPhase: (phaseNum: number) => void;
  isCompiling: boolean;
}

export const CompilerPipelineHero: React.FC<CompilerPipelineHeroProps> = ({
  compilerResult,
  activePhase,
  onSelectPhase,
  isCompiling
}) => {
  const phases = [
    {
      num: 1,
      name: 'LEXICAL ANALYSIS',
      subtitle: 'Scanner & Tokenization',
      icon: <Boxes className="w-4 h-4" />,
      stats: compilerResult ? `${compilerResult.lexical.tokenCount} Tokens` : 'Waiting...',
      detail: compilerResult
        ? `${compilerResult.lexical.identifierCount || 0} ID • ${compilerResult.lexical.literalCount || 0} Lit`
        : 'Tokens & Lexemes'
    },
    {
      num: 2,
      name: 'SYNTAX ANALYSIS',
      subtitle: 'Parser & Parse Tree',
      icon: <GitBranch className="w-4 h-4" />,
      stats: compilerResult ? `${compilerResult.syntax.grammarRulesUsed.length} Grammar Rules` : 'Waiting...',
      detail: compilerResult
        ? `${compilerResult.statistics.syntaxNodes} AST Nodes`
        : 'CST & AST Trees'
    },
    {
      num: 3,
      name: 'SEMANTIC ANALYSIS',
      subtitle: 'Type & Scope Checking',
      icon: <Table className="w-4 h-4" />,
      stats: compilerResult ? `${compilerResult.semantic.symbolTable.length} Symbols Bound` : 'Waiting...',
      detail: compilerResult
        ? `${compilerResult.semantic.semanticChecks.length} Invariant Checks`
        : 'Symbol Table & Scopes'
    },
    {
      num: 4,
      name: 'INTERMEDIATE CODE',
      subtitle: 'TAC & Quadruples',
      icon: <Code2 className="w-4 h-4" />,
      stats: compilerResult ? `${compilerResult.intermediateCode.threeAddressCode.length} TAC Instr` : 'Waiting...',
      detail: compilerResult
        ? `${compilerResult.intermediateCode.quadruples.length} Quadruples`
        : 'Three-Address Code'
    },
    {
      num: 5,
      name: 'CODE OPTIMIZATION',
      subtitle: 'Passes & Reduction',
      icon: <Zap className="w-4 h-4" />,
      stats: compilerResult ? `${compilerResult.optimization.passes.length} Passes Applied` : 'Waiting...',
      detail: compilerResult
        ? `${compilerResult.optimization.improvementPercentage}% Estimated Gain`
        : 'Constant Folding & DCE'
    },
    {
      num: 6,
      name: 'TARGET CODE GEN',
      subtitle: 'Assembly & Registers',
      icon: <Binary className="w-4 h-4" />,
      stats: compilerResult ? `${compilerResult.codeGen.totalInstructions} ASM Instructions` : 'Waiting...',
      detail: compilerResult ? 'x86-64 / ARM / MIPS' : 'Target Synthesis'
    }
  ];

  return (
    <div className="space-y-3">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Cpu className="w-4 h-4 text-indigo-600" />
          <h2 className="text-xs font-bold font-mono uppercase tracking-wider text-slate-800">
            6-PHASE COMPILER PIPELINE
          </h2>
        </div>
        <div className="text-[11px] font-mono text-slate-500 flex items-center gap-2">
          <span>Click any phase card to inspect internal compiler workspace</span>
        </div>
      </div>

      {/* 6 Horizontal Phase Cards Container */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-6 gap-3">
        {phases.map((phase, idx) => {
          const isSelected = activePhase === phase.num;
          const isDone = !!compilerResult && (!isCompiling || activePhase >= phase.num);
          const isCurrentlyActive = isCompiling && activePhase === phase.num;

          return (
            <div key={phase.num} className="relative group flex">
              <button
                id={`pipeline-phase-card-${phase.num}`}
                onClick={() => onSelectPhase(phase.num)}
                className={`w-full text-left p-3.5 rounded-xl border transition-all relative flex flex-col justify-between ${
                  isSelected
                    ? 'bg-indigo-50/70 border-indigo-300 ring-2 ring-indigo-500/20 shadow-xs'
                    : 'bg-white border-slate-200 hover:border-slate-300 hover:bg-slate-50/60 shadow-2xs'
                }`}
              >
                {/* Header with Phase number & Status */}
                <div className="flex items-center justify-between mb-2">
                  <span
                    className={`text-[10px] font-mono font-bold px-1.5 py-0.5 rounded ${
                      isSelected
                        ? 'bg-indigo-600 text-white'
                        : 'bg-slate-100 text-slate-600 border border-slate-200'
                    }`}
                  >
                    0{phase.num}
                  </span>
                  <div className="flex items-center gap-1">
                    {isCurrentlyActive ? (
                      <span className="w-2 h-2 rounded-full bg-amber-500 animate-ping" />
                    ) : isDone ? (
                      <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                    ) : (
                      <span className="w-2 h-2 rounded-full bg-slate-300" />
                    )}
                  </div>
                </div>

                {/* Phase Name & Subtitle */}
                <div className="space-y-0.5">
                  <div className="flex items-center gap-1.5 text-xs font-bold text-slate-800 tracking-tight">
                    <span className={isSelected ? 'text-indigo-600' : 'text-slate-500'}>
                      {phase.icon}
                    </span>
                    <span className="truncate">{phase.name}</span>
                  </div>
                  <p className="text-[10px] text-slate-500 truncate">{phase.subtitle}</p>
                </div>

                {/* Metric Summary */}
                <div className="mt-3 pt-2.5 border-t border-slate-100/90 flex flex-col">
                  <span className="text-[11px] font-mono font-semibold text-slate-800 truncate">
                    {phase.stats}
                  </span>
                  <span className="text-[9.5px] font-mono text-slate-400 truncate">
                    {phase.detail}
                  </span>
                </div>
              </button>

              {/* Arrow Connector on desktop between cards */}
              {idx < phases.length - 1 && (
                <div className="hidden lg:flex items-center absolute -right-2 top-1/2 -translate-y-1/2 z-10 pointer-events-none text-slate-300">
                  <ArrowRight className="w-3.5 h-3.5" />
                </div>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
};
