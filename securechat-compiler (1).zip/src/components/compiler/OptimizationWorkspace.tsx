import React from 'react';
import {
  ArrowRight,
  CheckCircle2,
  Cpu,
  Flame,
  MinusCircle,
  TrendingUp,
  Zap
} from 'lucide-react';
import { OptimizationResult } from '../../compiler/types';

interface OptimizationWorkspaceProps {
  optimization: OptimizationResult;
  originalText: string;
}

export const OptimizationWorkspace: React.FC<OptimizationWorkspaceProps> = ({
  optimization,
  originalText
}) => {
  return (
    <div className="space-y-4">
      {/* Optimization Performance Metrics */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        <div className="bg-slate-50 border border-slate-200 rounded-lg p-3">
          <div className="text-[10px] font-mono uppercase text-slate-500 font-semibold">Passes Applied</div>
          <div className="text-xl font-bold font-mono text-indigo-600 mt-1">
            {optimization.passes.length} Passes
          </div>
        </div>
        <div className="bg-slate-50 border border-slate-200 rounded-lg p-3">
          <div className="text-[10px] font-mono uppercase text-slate-500 font-semibold">Instructions Eliminated</div>
          <div className="text-xl font-bold font-mono text-emerald-600 mt-1">
            -{optimization.instructionReductionCount} Units
          </div>
        </div>
        <div className="bg-slate-50 border border-slate-200 rounded-lg p-3">
          <div className="text-[10px] font-mono uppercase text-slate-500 font-semibold">Estimated Gain</div>
          <div className="text-xl font-bold font-mono text-violet-600 mt-1">
            {optimization.improvementPercentage}% Gain
          </div>
        </div>
        <div className="bg-slate-50 border border-slate-200 rounded-lg p-3">
          <div className="text-[10px] font-mono uppercase text-slate-500 font-semibold">Links Neutralized</div>
          <div className="text-xl font-bold font-mono text-slate-800 mt-1">
            {optimization.removedUrlCount} URLs
          </div>
        </div>
      </div>

      {/* Side-by-Side Before vs After Code Diff */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {/* Before Optimization */}
        <div className="bg-white border border-slate-200 rounded-xl overflow-hidden shadow-2xs">
          <div className="bg-rose-50/70 border-b border-rose-200/80 px-4 py-2.5 flex items-center justify-between">
            <span className="text-xs font-mono font-bold text-rose-800 flex items-center gap-1.5">
              <MinusCircle className="w-3.5 h-3.5 text-rose-600" />
              BEFORE OPTIMIZATION (RAW STREAM)
            </span>
            <span className="text-[10px] font-mono text-rose-600">Unoptimized</span>
          </div>
          <div className="p-4 bg-slate-900 text-slate-200 font-mono text-xs overflow-x-auto min-h-[140px] leading-relaxed">
            <p className="text-slate-100">{originalText}</p>
          </div>
        </div>

        {/* After Optimization */}
        <div className="bg-white border border-slate-200 rounded-xl overflow-hidden shadow-2xs">
          <div className="bg-emerald-50/70 border-b border-emerald-200/80 px-4 py-2.5 flex items-center justify-between">
            <span className="text-xs font-mono font-bold text-emerald-800 flex items-center gap-1.5">
              <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
              AFTER OPTIMIZATION (TRANSFORMED PAYLOAD)
            </span>
            <span className="text-[10px] font-mono text-emerald-600">Optimized</span>
          </div>
          <div className="p-4 bg-slate-900 text-emerald-300 font-mono text-xs overflow-x-auto min-h-[140px] leading-relaxed">
            <p>{optimization.optimizedText}</p>
          </div>
        </div>
      </div>

      {/* Optimization Passes Breakdown List */}
      <div className="bg-white border border-slate-200 rounded-xl p-4 space-y-3 shadow-2xs">
        <div className="flex items-center gap-2">
          <Zap className="w-4 h-4 text-amber-500" />
          <h4 className="text-xs font-bold font-mono uppercase text-slate-800">
            COMPILER OPTIMIZATION PASSES PIPELINE
          </h4>
        </div>

        <div className="space-y-3">
          {optimization.passes.map((pass, idx) => (
            <div
              key={idx}
              className="p-3.5 bg-slate-50 border border-slate-200 rounded-xl space-y-2 font-mono text-xs"
            >
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <span className="w-5 h-5 rounded-full bg-indigo-100 text-indigo-700 flex items-center justify-center font-bold text-[10px]">
                    {idx + 1}
                  </span>
                  <span className="font-bold text-slate-800">{pass.name}</span>
                </div>
                <span className="text-[10px] px-2 py-0.5 rounded bg-emerald-100 text-emerald-800 font-semibold">
                  {pass.technique}
                </span>
              </div>

              <p className="text-[11px] text-slate-600 font-sans leading-relaxed">
                {pass.description}
              </p>

              {pass.instructionsRemoved > 0 && (
                <div className="text-[10px] text-emerald-700 font-mono flex items-center gap-1">
                  <TrendingUp className="w-3 h-3" />
                  <span>Eliminated {pass.instructionsRemoved} redundant IR instruction(s)</span>
                </div>
              )}
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
