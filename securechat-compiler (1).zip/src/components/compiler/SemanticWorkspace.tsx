import React, { useState } from 'react';
import {
  CheckCircle2,
  Filter,
  Layers,
  Search,
  ShieldCheck,
  Table as TableIcon,
  XCircle
} from 'lucide-react';
import { SemanticResult, SymbolTableEntry } from '../../compiler/types';

interface SemanticWorkspaceProps {
  semantic: SemanticResult;
}

export const SemanticWorkspace: React.FC<SemanticWorkspaceProps> = ({ semantic }) => {
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [scopeFilter, setScopeFilter] = useState<string>('ALL');

  const filteredSymbols = semantic.symbolTable.filter((sym) => {
    const matchesScope = scopeFilter === 'ALL' || sym.scope === scopeFilter;
    const matchesSearch =
      searchQuery === '' ||
      sym.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      sym.type.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesScope && matchesSearch;
  });

  return (
    <div className="space-y-4">
      {/* Semantic Summary Cards */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        <div className="bg-slate-50 border border-slate-200 rounded-lg p-3">
          <div className="text-[10px] font-mono uppercase text-slate-500 font-semibold">Tracked Symbols</div>
          <div className="text-xl font-bold font-mono text-slate-900 mt-1">{semantic.symbolTable.length}</div>
        </div>
        <div className="bg-slate-50 border border-slate-200 rounded-lg p-3">
          <div className="text-[10px] font-mono uppercase text-slate-500 font-semibold">Semantic Checks</div>
          <div className="text-xl font-bold font-mono text-indigo-600 mt-1">
            {semantic.semanticChecks.length} Passed
          </div>
        </div>
        <div className="bg-slate-50 border border-slate-200 rounded-lg p-3">
          <div className="text-[10px] font-mono uppercase text-slate-500 font-semibold">Classification</div>
          <div className="text-base font-bold font-mono text-indigo-700 mt-1 truncate">
            [{semantic.classification}]
          </div>
        </div>
        <div className="bg-slate-50 border border-slate-200 rounded-lg p-3">
          <div className="text-[10px] font-mono uppercase text-slate-500 font-semibold">Type / Scope Errors</div>
          <div className="text-xl font-bold font-mono text-emerald-600 mt-1">
            {semantic.typeErrors.length + semantic.scopeErrors.length} Errors
          </div>
        </div>
      </div>

      {/* Symbol Table Header & Search Filter */}
      <div className="bg-white border border-slate-200 rounded-xl overflow-hidden shadow-2xs">
        <div className="bg-slate-50 border-b border-slate-200 p-3 flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-2">
            <TableIcon className="w-4 h-4 text-indigo-600" />
            <span className="text-xs font-bold font-mono uppercase text-slate-800">
              SYMBOL TABLE (DATA DICTIONARY)
            </span>
          </div>

          <div className="flex items-center gap-3">
            <div className="flex items-center gap-2">
              <Search className="w-3.5 h-3.5 text-slate-400" />
              <input
                type="text"
                placeholder="Search symbol name..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="text-xs font-mono bg-white border border-slate-200 rounded-md px-2.5 py-1 text-slate-700 focus:outline-hidden focus:ring-1 focus:ring-indigo-500"
              />
            </div>

            <div className="flex items-center gap-1.5">
              <Filter className="w-3.5 h-3.5 text-slate-400" />
              <select
                value={scopeFilter}
                onChange={(e) => setScopeFilter(e.target.value)}
                className="text-xs font-mono bg-white border border-slate-200 rounded-md px-2 py-1 text-slate-700"
              >
                <option value="ALL">All Scopes</option>
                <option value="Global">Global</option>
                <option value="Local">Local</option>
                <option value="Parameter">Parameter</option>
              </select>
            </div>
          </div>
        </div>

        {/* Symbol Table Grid */}
        <div className="overflow-x-auto max-h-72 overflow-y-auto">
          <table className="w-full text-left text-xs font-mono">
            <thead className="bg-slate-50 border-b border-slate-200 text-[11px] text-slate-500 uppercase tracking-wider sticky top-0">
              <tr>
                <th className="px-4 py-2.5">Identifier Name</th>
                <th className="px-4 py-2.5">Data Type</th>
                <th className="px-4 py-2.5">Scope</th>
                <th className="px-4 py-2.5">Memory Offset</th>
                <th className="px-4 py-2.5">Line</th>
                <th className="px-4 py-2.5">Initial Value</th>
                <th className="px-4 py-2.5">Ref Count</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filteredSymbols.map((sym, idx) => (
                <tr key={idx} className="hover:bg-slate-50 transition-colors">
                  <td className="px-4 py-2 font-bold text-indigo-900">{sym.name}</td>
                  <td className="px-4 py-2">
                    <span className="px-2 py-0.5 rounded text-[10px] font-semibold bg-indigo-50 text-indigo-700 border border-indigo-200">
                      {sym.type}
                    </span>
                  </td>
                  <td className="px-4 py-2 text-slate-600">{sym.scope}</td>
                  <td className="px-4 py-2 text-slate-500 font-mono">{sym.memoryOffset}</td>
                  <td className="px-4 py-2 text-slate-400">Line {sym.line}</td>
                  <td className="px-4 py-2 text-slate-600 truncate max-w-xs">{sym.initialValue}</td>
                  <td className="px-4 py-2 text-slate-700">{sym.refCount} refs</td>
                </tr>
              ))}
              {filteredSymbols.length === 0 && (
                <tr>
                  <td colSpan={7} className="px-4 py-6 text-center text-slate-400 italic">
                    No symbol entries match filter.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Semantic Verifications List */}
      <div className="bg-white border border-slate-200 rounded-xl p-4 space-y-3 shadow-2xs">
        <div className="flex items-center gap-2">
          <ShieldCheck className="w-4 h-4 text-emerald-600" />
          <h4 className="text-xs font-bold font-mono uppercase text-slate-800">
            SEMANTIC INVARIANTS & TYPE CHECKING RECORD
          </h4>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
          {semantic.semanticChecks.map((chk, idx) => (
            <div
              key={idx}
              className="p-3 rounded-lg border border-slate-200 bg-slate-50 flex items-start gap-2.5 font-mono text-xs"
            >
              {chk.passed ? (
                <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
              ) : (
                <XCircle className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
              )}
              <div className="space-y-0.5 flex-1">
                <div className="flex items-center justify-between">
                  <span className="font-bold text-slate-800">{chk.checkName}</span>
                  <span className="text-[10px] text-slate-500 bg-white border border-slate-200 px-1.5 rounded">
                    {chk.category}
                  </span>
                </div>
                <p className="text-[11px] text-slate-500 font-sans">{chk.details}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
