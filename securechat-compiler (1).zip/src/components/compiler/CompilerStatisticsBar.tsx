import React from 'react';
import { Activity, BarChart2, Check, Clock, Cpu, Zap } from 'lucide-react';
import { CompilationStatistics } from '../../compiler/types';

interface CompilerStatisticsBarProps {
  stats: CompilationStatistics;
}

export const CompilerStatisticsBar: React.FC<CompilerStatisticsBarProps> = ({ stats }) => {
  const metrics = [
    {
      label: 'Tokens Generated',
      value: stats.tokensGenerated,
      unit: 'Tokens',
      percent: Math.min(100, Math.max(15, stats.tokensGenerated * 4)),
      color: 'bg-indigo-600',
      textColor: 'text-indigo-600'
    },
    {
      label: 'AST Syntax Nodes',
      value: stats.syntaxNodes,
      unit: 'Nodes',
      percent: Math.min(100, Math.max(20, stats.syntaxNodes * 8)),
      color: 'bg-violet-600',
      textColor: 'text-violet-600'
    },
    {
      label: 'Symbol Table Records',
      value: stats.symbolCount,
      unit: 'Symbols',
      percent: Math.min(100, Math.max(20, stats.symbolCount * 12)),
      color: 'bg-sky-600',
      textColor: 'text-sky-600'
    },
    {
      label: 'TAC IR Instructions',
      value: stats.irInstructions,
      unit: 'Instructions',
      percent: Math.min(100, Math.max(25, stats.irInstructions * 10)),
      color: 'bg-amber-600',
      textColor: 'text-amber-600'
    },
    {
      label: 'Optimization Reduction',
      value: `${stats.codeReductionPercent}%`,
      unit: 'Gain',
      percent: stats.codeReductionPercent,
      color: 'bg-emerald-600',
      textColor: 'text-emerald-600'
    },
    {
      label: 'Final Target Code',
      value: stats.finalInstructions,
      unit: 'ASM Lines',
      percent: Math.min(100, Math.max(30, stats.finalInstructions * 4)),
      color: 'bg-slate-800',
      textColor: 'text-slate-800'
    }
  ];

  return (
    <div className="bg-white border border-slate-200 rounded-xl p-4 space-y-3 shadow-2xs">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <BarChart2 className="w-4 h-4 text-indigo-600" />
          <h3 className="text-xs font-mono font-bold uppercase text-slate-800">
            COMPILER PIPELINE METRICS & PERFORMANCE
          </h3>
        </div>
        <div className="flex items-center gap-3 text-xs font-mono text-slate-500">
          <span className="flex items-center gap-1">
            <Clock className="w-3 h-3 text-indigo-600" />
            Time: <strong className="text-slate-800">{stats.compilationTimeMs} ms</strong>
          </span>
          <span className="flex items-center gap-1 text-emerald-600 font-semibold">
            <Check className="w-3 h-3" />
            Status: Fully Compiled
          </span>
        </div>
      </div>

      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
        {metrics.map((m, idx) => (
          <div key={idx} className="bg-slate-50 border border-slate-200/80 rounded-lg p-2.5 space-y-1.5 font-mono">
            <div className="text-[10px] text-slate-500 uppercase tracking-tight truncate">
              {m.label}
            </div>
            <div className="flex items-baseline justify-between">
              <span className={`text-base font-bold ${m.textColor}`}>
                {m.value}
              </span>
              <span className="text-[10px] text-slate-400">{m.unit}</span>
            </div>
            {/* Visual Progress Bar */}
            <div className="w-full h-1.5 bg-slate-200 rounded-full overflow-hidden">
              <div
                className={`h-full ${m.color} rounded-full transition-all duration-500`}
                style={{ width: `${m.percent}%` }}
              />
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
