import React, { useState } from 'react';
import {
  ArrowDown,
  Code2,
  Copy,
  FileCode,
  Layers,
  Table as TableIcon
} from 'lucide-react';
import { IntermediateRepresentation } from '../../compiler/types';

interface IntermediateWorkspaceProps {
  ir: IntermediateRepresentation;
}

export const IntermediateWorkspace: React.FC<IntermediateWorkspaceProps> = ({ ir }) => {
  const [activeSubTab, setActiveSubTab] = useState<'TAC' | 'QUADRUPLES' | 'BLOCKS'>('TAC');
  const [copied, setCopied] = useState(false);

  const handleCopy = async () => {
    try {
      await navigator.clipboard.writeText(ir.irCodeText);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch (err) {
      console.error('Failed to copy', err);
    }
  };

  return (
    <div className="space-y-4">
      {/* Subtab Navigation */}
      <div className="bg-slate-50 border border-slate-200 rounded-xl p-3 flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-2">
          <Code2 className="w-4 h-4 text-indigo-600" />
          <span className="text-xs font-bold font-mono uppercase text-slate-800">
            INTERMEDIATE CODE REPRESENTATION (IR)
          </span>
        </div>

        <div className="flex items-center gap-2">
          <div className="bg-white border border-slate-200 p-0.5 rounded-lg flex items-center gap-1 text-xs font-mono">
            <button
              onClick={() => setActiveSubTab('TAC')}
              className={`px-3 py-1 rounded-md font-semibold transition-colors ${
                activeSubTab === 'TAC'
                  ? 'bg-indigo-600 text-white shadow-2xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Three-Address Code (TAC)
            </button>
            <button
              onClick={() => setActiveSubTab('QUADRUPLES')}
              className={`px-3 py-1 rounded-md font-semibold transition-colors ${
                activeSubTab === 'QUADRUPLES'
                  ? 'bg-indigo-600 text-white shadow-2xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Quadruples Table
            </button>
            <button
              onClick={() => setActiveSubTab('BLOCKS')}
              className={`px-3 py-1 rounded-md font-semibold transition-colors ${
                activeSubTab === 'BLOCKS'
                  ? 'bg-indigo-600 text-white shadow-2xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Basic Blocks (CFG)
            </button>
          </div>
        </div>
      </div>

      {/* 1. Three-Address Code (TAC) View */}
      {activeSubTab === 'TAC' && (
        <div className="bg-white border border-slate-200 rounded-xl overflow-hidden shadow-2xs">
          <div className="bg-slate-50 border-b border-slate-200 px-4 py-2.5 flex items-center justify-between">
            <div className="flex items-center gap-2 text-xs font-mono text-slate-700 font-semibold">
              <FileCode className="w-3.5 h-3.5 text-indigo-600" />
              <span>TAC LINEAR INSTRUCTION STREAM ({ir.threeAddressCode.length} INSTRUCTIONS)</span>
            </div>
            <button
              onClick={handleCopy}
              className="text-xs font-mono text-slate-500 hover:text-slate-900 px-2 py-1 rounded bg-white border border-slate-200 transition-colors"
            >
              {copied ? '✓ Copied' : 'Copy TAC'}
            </button>
          </div>

          <div className="p-4 bg-slate-900 text-slate-100 font-mono text-xs overflow-x-auto space-y-1">
            {ir.threeAddressCode.map((instr, idx) => (
              <div key={idx} className="flex items-start gap-4 hover:bg-slate-800/80 px-2 py-1 rounded">
                <span className="text-slate-500 select-none w-8 text-right">
                  {String(idx + 1).padStart(2, '0')}
                </span>
                <span className="text-cyan-300 font-bold min-w-[280px]">
                  {instr.code}
                </span>
                {instr.comment && (
                  <span className="text-slate-400 italic">// {instr.comment}</span>
                )}
              </div>
            ))}
          </div>
        </div>
      )}

      {/* 2. Quadruples Table View */}
      {activeSubTab === 'QUADRUPLES' && (
        <div className="bg-white border border-slate-200 rounded-xl overflow-hidden shadow-2xs">
          <div className="bg-slate-50 border-b border-slate-200 px-4 py-2.5">
            <span className="text-xs font-mono font-bold text-slate-700 uppercase">
              QUADRUPLE DATA MATRIX [OP, ARG1, ARG2, RESULT]
            </span>
          </div>

          <div className="overflow-x-auto max-h-80 overflow-y-auto">
            <table className="w-full text-left text-xs font-mono">
              <thead className="bg-slate-50 border-b border-slate-200 text-[11px] text-slate-500 uppercase tracking-wider sticky top-0">
                <tr>
                  <th className="px-4 py-2.5">#</th>
                  <th className="px-4 py-2.5">Operator (Op)</th>
                  <th className="px-4 py-2.5">Argument 1 (Arg1)</th>
                  <th className="px-4 py-2.5">Argument 2 (Arg2)</th>
                  <th className="px-4 py-2.5">Result</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {ir.quadruples.map((q) => (
                  <tr key={q.index} className="hover:bg-slate-50 transition-colors">
                    <td className="px-4 py-2 text-slate-400">({q.index})</td>
                    <td className="px-4 py-2 font-bold text-indigo-700">{q.op}</td>
                    <td className="px-4 py-2 text-slate-700">{q.arg1}</td>
                    <td className="px-4 py-2 text-slate-500">{q.arg2}</td>
                    <td className="px-4 py-2 font-semibold text-emerald-700">{q.result}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* 3. Basic Blocks Control Flow Graph */}
      {activeSubTab === 'BLOCKS' && (
        <div className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {ir.basicBlocks.map((block) => (
              <div
                key={block.id}
                className="bg-white border border-slate-200 rounded-xl p-4 space-y-3 shadow-2xs"
              >
                <div className="flex items-center justify-between border-b border-slate-100 pb-2">
                  <span className="font-mono text-xs font-bold text-indigo-700">
                    {block.label}
                  </span>
                  <span className="text-[10px] font-mono px-1.5 py-0.5 rounded bg-indigo-50 border border-indigo-200 text-indigo-700">
                    {block.id}
                  </span>
                </div>

                <div className="bg-slate-50 border border-slate-200 rounded-lg p-2.5 space-y-1 font-mono text-[11px] text-slate-800 max-h-40 overflow-y-auto">
                  {block.instructions.map((inst, i) => (
                    <div key={i} className="truncate">
                      {inst.code}
                    </div>
                  ))}
                </div>

                <div className="text-[10px] font-mono text-slate-500 flex justify-between pt-1">
                  <span>Pred: {block.predecessors.join(', ')}</span>
                  <span>Succ: {block.successors.join(', ')}</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};
