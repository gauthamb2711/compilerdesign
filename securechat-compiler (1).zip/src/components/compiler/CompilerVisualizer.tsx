import React, { useState } from 'react';
import { Play, Sparkles, Terminal, Code2, AlertTriangle, ShieldCheck, Cpu } from 'lucide-react';
import { compileMessage } from '../../compiler/compiler';
import { CompilerResult } from '../../compiler/types';
import { CompilerAnalysisPanel } from '../chat/CompilerAnalysisPanel';

const SAMPLE_PROMPTS = [
  { label: 'Phishing Link', text: 'Hey click here http://evil-phish.ru/login to reset password urgently!' },
  { label: 'SQL Injection', text: "ADMIN' OR '1'='1' -- bypass authentication drop table users;" },
  { label: 'Profanity Threat', text: 'Shut up you idiot asshole I will destroy you' },
  { label: 'Safe Greeting', text: 'Hello! Let us schedule our team sync meeting for tomorrow morning.' },
];

export const CompilerVisualizer: React.FC = () => {
  const [inputText, setInputText] = useState(SAMPLE_PROMPTS[0].text);
  const [result, setResult] = useState<CompilerResult | null>(null);
  const [isCompiling, setIsCompiling] = useState(false);

  const handleRunCompiler = () => {
    if (!inputText.trim()) return;
    setIsCompiling(true);
    setTimeout(() => {
      const res = compileMessage(inputText);
      setResult(res);
      setIsCompiling(false);
    }, 200);
  };

  return (
    <div className="space-y-6">
      <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 shadow-2xl space-y-4">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
          <div>
            <h2 className="text-xl font-extrabold text-white flex items-center gap-2">
              <Cpu className="w-6 h-6 text-cyan-400" />
              6-Phase Compiler Laboratory
            </h2>
            <p className="text-xs text-slate-400 mt-1">
              Test custom messages directly against Lexer, Parser, Semantic Analysis, Intermediate Representation (IR), Optimizer, and CodeGen phases.
            </p>
          </div>

          <button
            onClick={handleRunCompiler}
            disabled={isCompiling}
            className="px-6 py-3 bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-bold rounded-xl shadow-[0_0_20px_rgba(6,182,212,0.3)] transition-all font-mono text-xs flex items-center gap-2 shrink-0 disabled:opacity-50"
          >
            {isCompiling ? (
              <>
                <div className="w-4 h-4 border-2 border-slate-950 border-t-transparent rounded-full animate-spin" />
                Compiling AST...
              </>
            ) : (
              <>
                <Play className="w-4 h-4 fill-current" />
                Run Compiler Pipeline
              </>
            )}
          </button>
        </div>

        {/* Input box */}
        <div className="space-y-2">
          <label className="block text-xs font-mono text-slate-400 font-bold uppercase">
            Input Raw String
          </label>
          <textarea
            value={inputText}
            onChange={(e) => setInputText(e.target.value)}
            rows={3}
            className="w-full p-4 bg-slate-950 border border-slate-800 rounded-2xl text-sm font-mono text-slate-100 focus:outline-none focus:border-cyan-500 transition-all"
            placeholder="Type any message or malicious payload to observe the compiler execution..."
          />
        </div>

        {/* Quick Sample Chips */}
        <div className="flex flex-wrap items-center gap-2 pt-1">
          <span className="text-xs font-mono text-slate-500 font-bold uppercase mr-1">
            Presets:
          </span>
          {SAMPLE_PROMPTS.map((sample, idx) => (
            <button
              key={idx}
              onClick={() => {
                setInputText(sample.text);
                const res = compileMessage(sample.text);
                setResult(res);
              }}
              className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 border border-slate-700 rounded-xl text-xs font-mono text-slate-300 transition-all flex items-center gap-1.5"
            >
              <Sparkles className="w-3 h-3 text-cyan-400" />
              {sample.label}
            </button>
          ))}
        </div>
      </div>

      {result && (
        <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 shadow-2xl space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-extrabold text-white uppercase font-mono tracking-wider flex items-center gap-2">
              <Terminal className="w-4 h-4 text-cyan-400" />
              Compilation Output & Security Evaluation
            </h3>

            <div className="flex items-center gap-2">
              <span className={`px-3 py-1 rounded-full text-xs font-mono font-bold ${
                result.classification === 'SAFE'
                  ? 'bg-emerald-950 border border-emerald-800 text-emerald-400'
                  : 'bg-rose-950 border border-rose-800 text-rose-400'
              }`}>
                {result.classification}
              </span>
              <span className="text-xs font-mono text-slate-400">
                Risk Score: <strong className="text-cyan-400">{result.riskScore}/100</strong>
              </span>
            </div>
          </div>

          <CompilerAnalysisPanel analysis={result} onClose={() => {}} />
        </div>
      )}
    </div>
  );
};
