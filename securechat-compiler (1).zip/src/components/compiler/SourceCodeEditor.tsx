import React, { useState } from 'react';
import {
  Check,
  Code2,
  Copy,
  FileCode,
  Play,
  RotateCcw,
  Sparkles,
  Trash2
} from 'lucide-react';

export interface CodePreset {
  id: string;
  name: string;
  category: string;
  code: string;
  description: string;
}

export const CODE_PRESETS: CodePreset[] = [
  {
    id: 'preset-dsl-basic',
    name: 'Message DSL Program',
    category: 'Standard DSL',
    code: `// SecureChat Compiler DSL Program
message("Hello team, please review the project submission.");
url = "https://example-university.edu/portal";
send(message, url);`,
    description: 'Standard language statement with message string literal and identifier dispatch.'
  },
  {
    id: 'preset-arithmetic',
    name: 'Constant Folding & Math',
    category: 'Optimization Demo',
    code: `// Arithmetic optimization test
let compute = 10 * 5 + 20 - 5;
let buffer_size = 1024 / 2;
message("Allocating buffer size: " + buffer_size);`,
    description: 'Demonstrates compile-time constant folding and strength reduction passes.'
  },
  {
    id: 'preset-college-chat',
    name: 'Conversational Message',
    category: 'Safe Passthrough',
    code: `Hi Arun, are you coming to the compiler design lab tomorrow at 10 AM?`,
    description: 'Natural language safe pass-through without external threat vectors.'
  },
  {
    id: 'preset-phishing-threat',
    name: 'Phishing Threat Payload',
    category: 'Security Analysis',
    code: `URGENT! Your banking account has been locked. Verify immediately at http://fake-bank-login.com to prevent suspension.`,
    description: 'High-risk urgency + credential harvesting link interception.'
  },
  {
    id: 'preset-otp-fraud',
    name: 'OTP Solicitation Attack',
    category: 'Security Analysis',
    code: `I am calling from bank support. Send me your 6-digit OTP 492018 immediately to unlock your account.`,
    description: 'Credential solicitation triggering sensitive code masking & fraud interception.'
  },
  {
    id: 'preset-spam-promo',
    name: 'Promotional Spam String',
    category: 'Optimization Demo',
    code: `CONGRATULATIONS!!! YOU WON 100% FREE PRIZE NOW!!! CLAIM TODAY AT HTTP://FREE-REWARDS-CLAIM.XYZ!!!`,
    description: 'Excessive punctuation normalization and promotional spam filters.'
  }
];

interface SourceCodeEditorProps {
  sourceCode: string;
  onChangeSourceCode: (code: string) => void;
  onRunCompile: () => void;
  isCompiling: boolean;
  activePhase: number;
}

export const SourceCodeEditor: React.FC<SourceCodeEditorProps> = ({
  sourceCode,
  onChangeSourceCode,
  onRunCompile,
  isCompiling,
  activePhase
}) => {
  const [copied, setCopied] = useState(false);
  const [selectedPresetId, setSelectedPresetId] = useState<string>('preset-dsl-basic');

  const lines = sourceCode.split('\n');

  const handleCopy = async () => {
    try {
      await navigator.clipboard.writeText(sourceCode);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch (err) {
      console.error('Failed to copy', err);
    }
  };

  const handleClear = () => {
    onChangeSourceCode('');
  };

  const handleSelectPreset = (preset: CodePreset) => {
    setSelectedPresetId(preset.id);
    onChangeSourceCode(preset.code);
  };

  return (
    <div className="bg-white border border-slate-200 rounded-xl shadow-xs overflow-hidden">
      {/* Editor Top Bar */}
      <div className="bg-slate-50 border-b border-slate-200 px-4 py-2.5 flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-2">
          <div className="flex items-center gap-1.5 text-slate-700 font-semibold text-xs">
            <FileCode className="w-4 h-4 text-indigo-600" />
            <span>SOURCE INPUT BUFFER</span>
          </div>
          <span className="text-[11px] text-slate-400 font-mono">
            ({lines.length} lines • {sourceCode.length} chars)
          </span>
        </div>

        {/* Preset Selector & Action Toolbar */}
        <div className="flex items-center gap-2">
          <div className="flex items-center gap-1.5">
            <span className="text-[11px] font-medium text-slate-500 hidden sm:inline">
              Presets:
            </span>
            <select
              id="source-preset-selector"
              value={selectedPresetId}
              onChange={(e) => {
                const preset = CODE_PRESETS.find((p) => p.id === e.target.value);
                if (preset) handleSelectPreset(preset);
              }}
              className="text-xs font-mono bg-white border border-slate-200 rounded-lg px-2.5 py-1 text-slate-700 focus:outline-hidden focus:ring-1 focus:ring-indigo-500"
            >
              {CODE_PRESETS.map((p) => (
                <option key={p.id} value={p.id}>
                  {p.name} ({p.category})
                </option>
              ))}
            </select>
          </div>

          <div className="h-4 w-px bg-slate-200" />

          <button
            id="editor-copy-btn"
            onClick={handleCopy}
            title="Copy Source"
            className="p-1.5 text-slate-500 hover:text-slate-800 hover:bg-slate-100 rounded-md transition-colors"
          >
            {copied ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
          </button>

          <button
            id="editor-clear-btn"
            onClick={handleClear}
            title="Clear Editor"
            className="p-1.5 text-slate-500 hover:text-rose-600 hover:bg-rose-50 rounded-md transition-colors"
          >
            <Trash2 className="w-3.5 h-3.5" />
          </button>

          <button
            id="editor-run-btn"
            onClick={onRunCompile}
            disabled={isCompiling || !sourceCode.trim()}
            className={`px-3.5 py-1.5 text-xs font-semibold rounded-lg flex items-center gap-1.5 transition-all shadow-xs ${
              isCompiling || !sourceCode.trim()
                ? 'bg-indigo-300 text-white cursor-not-allowed'
                : 'bg-indigo-600 hover:bg-indigo-700 text-white shadow-indigo-100'
            }`}
          >
            <Play className={`w-3.5 h-3.5 fill-current ${isCompiling ? 'animate-pulse' : ''}`} />
            <span>{isCompiling ? 'Compiling...' : 'Run ▶'}</span>
          </button>
        </div>
      </div>

      {/* Editor Body with Line Numbers */}
      <div className="flex font-mono text-xs text-slate-800 bg-white relative">
        {/* Line Numbers Gutter */}
        <div className="bg-slate-50/70 border-r border-slate-200 select-none py-3 px-3 text-right text-slate-400 font-mono text-[11px] min-w-10">
          {lines.map((_, i) => (
            <div key={i} className="leading-6">
              {String(i + 1).padStart(2, '0')}
            </div>
          ))}
        </div>

        {/* Textarea Input */}
        <div className="flex-1 relative">
          <textarea
            id="source-code-textarea"
            rows={Math.max(4, Math.min(8, lines.length))}
            value={sourceCode}
            onChange={(e) => onChangeSourceCode(e.target.value)}
            placeholder="Type or paste source statements (e.g., message('Hello'); url = 'https://...'; send(message, url);)..."
            spellCheck={false}
            className="w-full h-full p-3 font-mono text-xs leading-6 text-slate-800 bg-transparent resize-y focus:outline-hidden focus:ring-0 border-none"
          />
        </div>
      </div>
    </div>
  );
};
