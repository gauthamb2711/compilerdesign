import React, { useState } from 'react';
import {
  Binary,
  Check,
  Clock,
  Copy,
  Cpu,
  FileCode,
  HardDrive,
  Layers,
  Sparkles
} from 'lucide-react';
import { CodeGeneratorResult, TargetArchitecture } from '../../compiler/types';

interface TargetCodeWorkspaceProps {
  codeGen: CodeGeneratorResult;
}

export const TargetCodeWorkspace: React.FC<TargetCodeWorkspaceProps> = ({ codeGen }) => {
  const [selectedArch, setSelectedArch] = useState<TargetArchitecture>('x86_64');
  const [copied, setCopied] = useState(false);

  const currentOutput = codeGen.assemblyOutputs[selectedArch];

  const handleCopy = async () => {
    try {
      await navigator.clipboard.writeText(currentOutput.code);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch (err) {
      console.error('Failed to copy assembly', err);
    }
  };

  const architectures: { id: TargetArchitecture; label: string; tag: string }[] = [
    { id: 'x86_64', label: 'x86-64 (Intel/AMD)', tag: 'x86_64' },
    { id: 'ARM64', label: 'ARM64 (AArch64)', tag: 'ARM64' },
    { id: 'MIPS', label: 'MIPS32 Architecture', tag: 'MIPS32' },
    { id: 'PSEUDO_ASSEMBLY', label: 'Pseudo Assembly VM', tag: 'Virtual Machine' }
  ];

  return (
    <div className="space-y-4">
      {/* Architecture Selector Bar */}
      <div className="bg-slate-50 border border-slate-200 rounded-xl p-3 flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-2">
          <Binary className="w-4 h-4 text-indigo-600" />
          <span className="text-xs font-bold font-mono uppercase text-slate-800">
            TARGET CODE SYNTHESIS & REGISTER ALLOCATION
          </span>
        </div>

        {/* Architecture Buttons */}
        <div className="flex items-center gap-1.5 overflow-x-auto">
          {architectures.map((arch) => (
            <button
              key={arch.id}
              onClick={() => setSelectedArch(arch.id)}
              className={`px-3 py-1 rounded-lg text-xs font-mono font-semibold transition-colors whitespace-nowrap ${
                selectedArch === arch.id
                  ? 'bg-indigo-600 text-white shadow-2xs'
                  : 'bg-white text-slate-600 hover:text-slate-900 border border-slate-200 hover:bg-slate-100'
              }`}
            >
              {arch.label}
            </button>
          ))}
        </div>
      </div>

      {/* Target Metrics */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        <div className="bg-slate-50 border border-slate-200 rounded-lg p-3">
          <div className="text-[10px] font-mono uppercase text-slate-500 font-semibold">Assembly Instructions</div>
          <div className="text-xl font-bold font-mono text-indigo-600 mt-1">
            {currentOutput.instructionsCount} OpCodes
          </div>
        </div>
        <div className="bg-slate-50 border border-slate-200 rounded-lg p-3">
          <div className="text-[10px] font-mono uppercase text-slate-500 font-semibold">Estimated Clock Cycles</div>
          <div className="text-xl font-bold font-mono text-violet-600 mt-1">
            ~{currentOutput.estimatedCycles} Cycles
          </div>
        </div>
        <div className="bg-slate-50 border border-slate-200 rounded-lg p-3">
          <div className="text-[10px] font-mono uppercase text-slate-500 font-semibold">Binary Footprint</div>
          <div className="text-xl font-bold font-mono text-emerald-600 mt-1">
            {currentOutput.byteSize} Bytes
          </div>
        </div>
        <div className="bg-slate-50 border border-slate-200 rounded-lg p-3">
          <div className="text-[10px] font-mono uppercase text-slate-500 font-semibold">Registers Assigned</div>
          <div className="text-xl font-bold font-mono text-slate-800 mt-1">
            {Object.keys(currentOutput.registerAllocation).length} Regs
          </div>
        </div>
      </div>

      {/* Generated Target Assembly Code Console */}
      <div className="bg-white border border-slate-200 rounded-xl overflow-hidden shadow-2xs">
        <div className="bg-slate-50 border-b border-slate-200 px-4 py-2.5 flex items-center justify-between">
          <div className="flex items-center gap-2 text-xs font-mono text-slate-700 font-semibold">
            <FileCode className="w-3.5 h-3.5 text-indigo-600" />
            <span>EMITTED TARGET ASSEMBLY ({selectedArch.toUpperCase()})</span>
          </div>
          <button
            onClick={handleCopy}
            className="text-xs font-mono text-slate-600 hover:text-slate-900 px-2.5 py-1 rounded bg-white border border-slate-200 transition-colors flex items-center gap-1.5"
          >
            {copied ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
            <span>{copied ? 'Copied' : 'Copy Code'}</span>
          </button>
        </div>

        <div className="p-4 bg-slate-950 text-slate-100 font-mono text-xs overflow-x-auto max-h-80 overflow-y-auto leading-relaxed">
          <pre className="text-emerald-300">{currentOutput.code}</pre>
        </div>
      </div>

      {/* Register Allocation Matrix */}
      <div className="bg-white border border-slate-200 rounded-xl p-4 space-y-3 shadow-2xs">
        <div className="flex items-center gap-2">
          <Cpu className="w-4 h-4 text-indigo-600" />
          <h4 className="text-xs font-bold font-mono uppercase text-slate-800">
            REGISTER ALLOCATION MAPPING TABLE ({selectedArch})
          </h4>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-2.5">
          {Object.entries(currentOutput.registerAllocation).map(([reg, desc], idx) => (
            <div
              key={idx}
              className="p-2.5 bg-slate-50 border border-slate-200 rounded-lg flex items-center justify-between font-mono text-xs"
            >
              <span className="font-bold text-indigo-700 bg-indigo-50 px-2 py-0.5 rounded border border-indigo-200">
                {reg}
              </span>
              <span className="text-slate-600 text-[11px] truncate max-w-[160px]">{desc}</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
