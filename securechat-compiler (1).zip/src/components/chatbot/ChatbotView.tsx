import React, { useEffect, useRef, useState } from 'react';
import Markdown from 'react-markdown';
import {
  Bot,
  User,
  Send,
  Sparkles,
  Trash2,
  Copy,
  Check,
  Cpu,
  Shield,
  Zap,
  SlidersHorizontal,
  Download,
  Terminal,
  Settings2,
  Code2
} from 'lucide-react';
import {
  ChatMessageItem,
  COMPILER_AI_PERSONAS,
  ChatbotRolePersona,
  sendCompilerAIMessage
} from '../../services/chatbotService';

interface ChatbotViewProps {
  initialPersonaId?: string;
  isCompact?: boolean;
}

export const ChatbotView: React.FC<ChatbotViewProps> = ({
  initialPersonaId = 'compiler-architect',
  isCompact = false
}) => {
  const [selectedPersona, setSelectedPersona] = useState<ChatbotRolePersona>(() => {
    const found = COMPILER_AI_PERSONAS.find((p) => p.id === initialPersonaId);
    return found || COMPILER_AI_PERSONAS[0];
  });

  const [customSystemPrompt, setCustomSystemPrompt] = useState<string>(selectedPersona.systemInstruction);
  const [isCustomPromptOpen, setIsCustomPromptOpen] = useState<boolean>(false);
  const [messages, setMessages] = useState<ChatMessageItem[]>([
    {
      id: 'init-msg',
      role: 'model',
      text: `Hello! I am **Compiler AI**, your dedicated compiler construction and language processing assistant. 

Ask me anything about:
- **Phase 1**: Lexical Analysis, Regular Expressions & Tokens
- **Phase 2**: CFG Grammars, Parse Trees & AST Design
- **Phase 3**: Symbol Tables, Scope Management & Type Checking
- **Phase 4**: Three-Address Code (TAC), Quadruples & Control Flow Graphs
- **Phase 5**: Multi-Pass Optimizations & Constant Folding
- **Phase 6**: Target Assembly Generation (x86-64, ARM64, MIPS) & Register Allocation`,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    }
  ]);
  const [inputPrompt, setInputPrompt] = useState<string>('');
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [copiedId, setCopiedId] = useState<string | null>(null);

  const messagesEndRef = useRef<HTMLDivElement | null>(null);
  const textareaRef = useRef<HTMLTextAreaElement | null>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages, isLoading]);

  const handleSelectPersona = (persona: ChatbotRolePersona) => {
    setSelectedPersona(persona);
    setCustomSystemPrompt(persona.systemInstruction);
  };

  const handleSendMessage = async (textToSend?: string) => {
    const content = (textToSend || inputPrompt).trim();
    if (!content || isLoading) return;

    const userMessage: ChatMessageItem = {
      id: `user-${Date.now()}`,
      role: 'user',
      text: content,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    };

    const newHistory = [...messages, userMessage];
    setMessages(newHistory);
    setInputPrompt('');
    setIsLoading(true);

    try {
      const activeSystemInstruction = customSystemPrompt.trim() || selectedPersona.systemInstruction;
      const modelReply = await sendCompilerAIMessage(newHistory, activeSystemInstruction);

      const modelMessage: ChatMessageItem = {
        id: `model-${Date.now()}`,
        role: 'model',
        text: modelReply,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
      };

      setMessages((prev) => [...prev, modelMessage]);
    } catch (error: any) {
      const errorMessage: ChatMessageItem = {
        id: `err-${Date.now()}`,
        role: 'model',
        text: `⚠️ **Error communicating with Compiler AI**: ${error.message || 'Unable to generate reply. Please check your connection or try again.'}`,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
      };
      setMessages((prev) => [...prev, errorMessage]);
    } finally {
      setIsLoading(false);
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  };

  const handleCopyMessage = (id: string, text: string) => {
    navigator.clipboard.writeText(text);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  const handleClearHistory = () => {
    setMessages([
      {
        id: `init-${Date.now()}`,
        role: 'model',
        text: `Conversation cleared. I am ready for your next question as **Compiler AI (${selectedPersona.name})**.`,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
      }
    ]);
  };

  const handleExportChat = () => {
    const transcript = messages
      .map((m) => `[${m.timestamp}] ${m.role === 'model' ? 'COMPILER AI' : 'YOU'}:\n${m.text}\n`)
      .join('\n---\n\n');
    const blob = new Blob([transcript], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `compiler-ai-transcript-${Date.now()}.txt`;
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div
      className={`flex flex-col bg-white border border-slate-200 rounded-2xl shadow-sm overflow-hidden ${
        isCompact ? 'h-[540px]' : 'h-[calc(100vh-140px)] min-h-[600px]'
      }`}
    >
      {/* Top Header & Controls */}
      <div className="bg-slate-900 text-white p-4 border-b border-slate-800 flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-3">
          <div className="p-2 bg-indigo-600/30 border border-indigo-500/40 rounded-xl text-indigo-400">
            <Cpu className="w-5 h-5" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-sm font-bold tracking-tight text-white flex items-center gap-1.5 font-mono">
                Compiler AI
              </h2>
              <span className="px-2 py-0.5 rounded-full bg-emerald-950/80 border border-emerald-700/60 text-emerald-400 text-[10px] font-mono flex items-center gap-1">
                <Zap className="w-2.5 h-2.5 fill-current" /> Fast Engine
              </span>
            </div>
            <p className="text-[11px] text-slate-400 font-sans">
              Active Mode: <span className="text-indigo-300 font-medium">{selectedPersona.name}</span>
            </p>
          </div>
        </div>

        {/* Header Action Buttons */}
        <div className="flex items-center gap-2">
          <button
            onClick={() => setIsCustomPromptOpen(!isCustomPromptOpen)}
            title="Configure System Persona"
            className={`p-2 rounded-lg border transition-colors text-xs flex items-center gap-1.5 font-mono ${
              isCustomPromptOpen
                ? 'bg-indigo-600 text-white border-indigo-500'
                : 'bg-slate-800 border-slate-700 text-slate-300 hover:bg-slate-700'
            }`}
          >
            <SlidersHorizontal className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">Persona Prompt</span>
          </button>

          <button
            onClick={handleExportChat}
            title="Export conversation transcript"
            className="p-2 bg-slate-800 border border-slate-700 text-slate-300 hover:bg-slate-700 rounded-lg transition-colors"
          >
            <Download className="w-3.5 h-3.5" />
          </button>

          <button
            onClick={handleClearHistory}
            title="Clear conversation"
            className="p-2 bg-slate-800 border border-slate-700 text-rose-400 hover:bg-rose-950/40 hover:border-rose-800 rounded-lg transition-colors"
          >
            <Trash2 className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      {/* Role Preset Tabs */}
      <div className="bg-slate-100/80 border-b border-slate-200 px-4 py-2.5 flex items-center gap-2 overflow-x-auto text-xs scrollbar-none">
        <span className="text-[11px] font-mono text-slate-400 uppercase tracking-wider font-semibold mr-1 shrink-0">
          Compiler Mode:
        </span>
        {COMPILER_AI_PERSONAS.map((persona) => {
          const isSelected = selectedPersona.id === persona.id;
          return (
            <button
              key={persona.id}
              onClick={() => handleSelectPersona(persona)}
              className={`px-3 py-1 rounded-lg font-medium whitespace-nowrap transition-all flex items-center gap-1.5 ${
                isSelected
                  ? 'bg-indigo-600 text-white shadow-xs'
                  : 'bg-white text-slate-600 border border-slate-200 hover:bg-slate-50'
              }`}
            >
              {persona.id === 'compiler-architect' && <Cpu className="w-3.5 h-3.5" />}
              {persona.id === 'frontend-analyzer' && <Code2 className="w-3.5 h-3.5" />}
              {persona.id === 'backend-optimizer' && <Terminal className="w-3.5 h-3.5" />}
              {persona.id === 'fast-assistant' && <Zap className="w-3.5 h-3.5" />}
              <span>{persona.name}</span>
            </button>
          );
        })}
      </div>

      {/* Custom System Instruction Drawer */}
      {isCustomPromptOpen && (
        <div className="bg-slate-900/95 border-b border-slate-800 p-4 text-slate-200 space-y-2 animate-in fade-in duration-150">
          <div className="flex items-center justify-between text-xs">
            <span className="font-mono font-bold text-indigo-400 uppercase tracking-wider flex items-center gap-1.5">
              <Settings2 className="w-3.5 h-3.5" /> System Prompt (Compiler AI Behavior Rules)
            </span>
            <span className="text-[11px] text-slate-400 font-sans">
              Defines the focus, tone, and technical depth for Compiler AI.
            </span>
          </div>
          <textarea
            value={customSystemPrompt}
            onChange={(e) => setCustomSystemPrompt(e.target.value)}
            rows={3}
            className="w-full bg-slate-950 border border-slate-800 rounded-xl p-3 text-xs font-mono text-slate-200 focus:outline-none focus:border-indigo-500 resize-none leading-relaxed"
            placeholder="Enter custom instructions for Compiler AI..."
          />
        </div>
      )}

      {/* Messages Scrollable Thread */}
      <div className="flex-1 overflow-y-auto p-4 sm:p-6 space-y-5 bg-slate-50/50">
        {messages.map((message) => {
          const isUser = message.role === 'user';
          return (
            <div
              key={message.id}
              className={`flex gap-3 max-w-3xl ${isUser ? 'ml-auto flex-row-reverse' : 'mr-auto'}`}
            >
              {/* Avatar Icon */}
              <div
                className={`w-8 h-8 rounded-xl flex items-center justify-center shrink-0 shadow-xs ${
                  isUser
                    ? 'bg-slate-900 text-white'
                    : 'bg-indigo-600 text-white border border-indigo-500'
                }`}
              >
                {isUser ? <User className="w-4 h-4" /> : <Cpu className="w-4 h-4" />}
              </div>

              {/* Message Bubble Card */}
              <div
                className={`group relative rounded-2xl p-4 text-sm leading-relaxed transition-all shadow-xs ${
                  isUser
                    ? 'bg-slate-900 text-white rounded-tr-xs'
                    : 'bg-white border border-slate-200 text-slate-800 rounded-tl-xs'
                }`}
              >
                {/* Meta info header */}
                <div className="flex items-center justify-between gap-4 mb-2 pb-1.5 border-b border-slate-100/20 text-[10px] font-mono opacity-80">
                  <span className="font-semibold">
                    {isUser ? 'You' : 'Compiler AI'}
                  </span>
                  <div className="flex items-center gap-2">
                    <span>{message.timestamp}</span>
                    <button
                      onClick={() => handleCopyMessage(message.id, message.text)}
                      title="Copy message content"
                      className="opacity-0 group-hover:opacity-100 transition-opacity p-0.5 hover:text-indigo-400"
                    >
                      {copiedId === message.id ? (
                        <Check className="w-3 h-3 text-emerald-500" />
                      ) : (
                        <Copy className="w-3 h-3" />
                      )}
                    </button>
                  </div>
                </div>

                {/* Message Body with Markdown Rendering */}
                <div className={isUser ? 'text-white' : 'text-slate-800'}>
                  {isUser ? (
                    <p className="whitespace-pre-wrap">{message.text}</p>
                  ) : (
                    <div className="markdown-body text-xs sm:text-sm prose prose-slate max-w-none prose-p:my-1.5 prose-pre:my-2 prose-pre:p-3 prose-pre:bg-slate-950 prose-pre:text-slate-100 prose-pre:rounded-xl prose-code:text-indigo-600 prose-code:bg-indigo-50 prose-code:px-1 prose-code:py-0.5 prose-code:rounded">
                      <Markdown>{message.text}</Markdown>
                    </div>
                  )}
                </div>
              </div>
            </div>
          );
        })}

        {/* Typing Loading Indicator */}
        {isLoading && (
          <div className="flex gap-3 max-w-3xl mr-auto">
            <div className="w-8 h-8 rounded-xl bg-indigo-600 text-white flex items-center justify-center shrink-0 animate-pulse">
              <Cpu className="w-4 h-4" />
            </div>
            <div className="bg-white border border-slate-200 rounded-2xl rounded-tl-xs p-4 shadow-xs text-xs font-mono text-slate-500 flex items-center gap-2">
              <div className="flex items-center gap-1.5">
                <span className="w-2 h-2 rounded-full bg-indigo-600 animate-bounce" />
                <span className="w-2 h-2 rounded-full bg-indigo-600 animate-bounce [animation-delay:0.2s]" />
                <span className="w-2 h-2 rounded-full bg-indigo-600 animate-bounce [animation-delay:0.4s]" />
              </div>
              <span className="ml-1 text-slate-400">Compiler AI is analyzing...</span>
            </div>
          </div>
        )}

        <div ref={messagesEndRef} />
      </div>

      {/* Suggested Starter Prompts */}
      {messages.length <= 2 && (
        <div className="bg-white border-t border-slate-100 px-4 py-2.5 flex items-center gap-2 overflow-x-auto text-xs scrollbar-none">
          <span className="text-[10px] font-mono text-slate-400 uppercase font-semibold shrink-0">
            Suggested:
          </span>
          {selectedPersona.suggestedPrompts.map((prompt, idx) => (
            <button
              key={idx}
              onClick={() => handleSendMessage(prompt)}
              className="px-2.5 py-1 bg-indigo-50/70 hover:bg-indigo-100 border border-indigo-100 text-indigo-700 rounded-lg text-xs transition-colors shrink-0 max-w-[280px] truncate text-left font-mono"
            >
              {prompt}
            </button>
          ))}
        </div>
      )}

      {/* Bottom Message Input Box */}
      <div className="p-3 sm:p-4 bg-white border-t border-slate-200">
        <form
          onSubmit={(e) => {
            e.preventDefault();
            handleSendMessage();
          }}
          className="flex items-end gap-2 bg-slate-50 border border-slate-200 rounded-xl p-2 focus-within:border-indigo-500 focus-within:ring-2 focus-within:ring-indigo-100 transition-all"
        >
          <textarea
            ref={textareaRef}
            value={inputPrompt}
            onChange={(e) => setInputPrompt(e.target.value)}
            onKeyDown={handleKeyDown}
            rows={isCompact ? 2 : 2}
            placeholder={`Ask Compiler AI as ${selectedPersona.name}... (Press Enter to send, Shift+Enter for new line)`}
            className="flex-1 bg-transparent border-0 text-xs sm:text-sm text-slate-800 placeholder-slate-400 focus:outline-none resize-none max-h-32 leading-relaxed font-sans"
          />

          <button
            type="submit"
            disabled={!inputPrompt.trim() || isLoading}
            className="p-2.5 bg-indigo-600 hover:bg-indigo-700 disabled:opacity-40 disabled:hover:bg-indigo-600 text-white rounded-lg transition-all shadow-xs shrink-0 flex items-center justify-center cursor-pointer disabled:cursor-not-allowed"
          >
            <Send className="w-4 h-4" />
          </button>
        </form>

        <div className="flex items-center justify-between mt-2 text-[10px] text-slate-400 font-mono">
          <span className="flex items-center gap-1">
            <Zap className="w-3 h-3 text-emerald-500 fill-current" />
            Compiler AI Real-Time Processing Engine
          </span>
          <span className="hidden sm:inline">Shift + Enter for new line • Enter to send</span>
        </div>
      </div>
    </div>
  );
};
