import React, { useState } from 'react';
import { Cpu, X, Maximize2, Minimize2, Zap } from 'lucide-react';
import { ChatbotView } from './ChatbotView';

export const FloatingChatbot: React.FC = () => {
  const [isOpen, setIsOpen] = useState<boolean>(false);
  const [isExpanded, setIsExpanded] = useState<boolean>(false);

  return (
    <div className="fixed bottom-6 right-6 z-50 flex flex-col items-end">
      {/* Expanded Chat Drawer */}
      {isOpen && (
        <div
          className={`mb-4 bg-white border border-slate-200 rounded-3xl shadow-2xl overflow-hidden transition-all duration-200 flex flex-col ${
            isExpanded
              ? 'w-[90vw] sm:w-[680px] h-[80vh] max-h-[750px]'
              : 'w-[90vw] sm:w-[420px] h-[540px]'
          }`}
        >
          {/* Drawer Top Navigation Bar */}
          <div className="bg-slate-900 text-white px-4 py-3 border-b border-slate-800 flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <div className="p-1.5 bg-indigo-600 rounded-xl text-white">
                <Cpu className="w-4 h-4" />
              </div>
              <div>
                <h3 className="text-xs font-bold text-white flex items-center gap-1.5 font-mono">
                  Compiler AI
                </h3>
                <span className="text-[10px] text-emerald-400 font-mono flex items-center gap-1">
                  <Zap className="w-2.5 h-2.5 fill-current" /> Fast Engine Active
                </span>
              </div>
            </div>

            <div className="flex items-center gap-1">
              <button
                onClick={() => setIsExpanded(!isExpanded)}
                title={isExpanded ? 'Collapse size' : 'Expand size'}
                className="p-1.5 text-slate-400 hover:text-white hover:bg-slate-800 rounded-lg transition-colors"
              >
                {isExpanded ? <Minimize2 className="w-3.5 h-3.5" /> : <Maximize2 className="w-3.5 h-3.5" />}
              </button>
              <button
                onClick={() => setIsOpen(false)}
                title="Close Compiler AI"
                className="p-1.5 text-slate-400 hover:text-white hover:bg-slate-800 rounded-lg transition-colors"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
          </div>

          {/* Embedded Compiler AI View */}
          <div className="flex-1 overflow-hidden">
            <ChatbotView isCompact={!isExpanded} />
          </div>
        </div>
      )}

      {/* Floating Action Launcher Button */}
      <button
        onClick={() => setIsOpen(!isOpen)}
        className="group relative flex items-center gap-2.5 px-4 py-3.5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-2xl shadow-xl shadow-indigo-600/30 hover:shadow-indigo-600/40 transition-all duration-200 cursor-pointer border border-indigo-500 font-mono"
      >
        <div className="relative">
          <Cpu className="w-5 h-5 transition-transform group-hover:scale-110" />
          <span className="absolute -top-1 -right-1 w-2.5 h-2.5 bg-emerald-400 rounded-full ring-2 ring-indigo-600 animate-pulse" />
        </div>
        <span className="text-xs font-bold font-mono tracking-wide">
          {isOpen ? 'Close' : 'Ask Compiler AI'}
        </span>
      </button>
    </div>
  );
};
