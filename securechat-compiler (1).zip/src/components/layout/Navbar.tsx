import React from 'react';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import {
  Bot,
  Cpu,
  LogOut,
  MessageSquare,
  Shield,
  Terminal,
  User as UserIcon,
  Zap
} from 'lucide-react';
import { logoutUser } from '../../services/authService';
import { UserProfile } from '../../types';

interface NavbarProps {
  profile: UserProfile | null;
}

export const Navbar: React.FC<NavbarProps> = ({ profile }) => {
  const location = useLocation();
  const navigate = useNavigate();

  const isActive = (path: string) => location.pathname === path;

  const handleLogout = async () => {
    try {
      await logoutUser();
      navigate('/login');
    } catch (err) {
      console.error('Logout error:', err);
    }
  };

  return (
    <nav className="bg-white/90 border-b border-slate-200/80 backdrop-blur-md sticky top-0 z-40 text-slate-800 shadow-sm">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
        {/* Brand Logo */}
        <Link to="/" className="flex items-center gap-3 group">
          <div className="w-9 h-9 rounded-xl bg-indigo-600 flex items-center justify-center text-white shadow-md shadow-indigo-200 group-hover:scale-105 transition-transform">
            <Shield className="w-5 h-5" />
          </div>
          <div>
            <span className="font-bold tracking-tight text-lg text-slate-800 flex items-center gap-1.5">
              SecureChat <span className="text-indigo-600 font-mono text-xs border border-indigo-200 px-2 py-0.5 rounded-full bg-indigo-50 font-semibold">COMPILER</span>
            </span>
          </div>
        </Link>

        {/* Navigation Links */}
        <div className="hidden md:flex items-center gap-1.5 text-xs">
          <Link
            to="/chat"
            className={`px-3.5 py-2 rounded-lg font-medium flex items-center gap-2 transition-colors ${
              isActive('/chat')
                ? 'bg-indigo-50 text-indigo-700 font-semibold'
                : 'text-slate-500 hover:text-slate-800 hover:bg-slate-50'
            }`}
          >
            <MessageSquare className="w-4 h-4" />
            Chat
          </Link>

          <Link
            to="/chatbot"
            className={`px-3.5 py-2 rounded-lg font-medium flex items-center gap-2 transition-colors ${
              isActive('/chatbot')
                ? 'bg-indigo-50 text-indigo-700 font-semibold'
                : 'text-slate-500 hover:text-slate-800 hover:bg-slate-50'
            }`}
          >
            <Cpu className="w-4 h-4 text-indigo-600" />
            Compiler AI
          </Link>

          <Link
            to="/compiler"
            className={`px-3.5 py-2 rounded-lg font-medium flex items-center gap-2 transition-colors ${
              isActive('/compiler')
                ? 'bg-indigo-50 text-indigo-700 font-semibold'
                : 'text-slate-500 hover:text-slate-800 hover:bg-slate-50'
            }`}
          >
            <Terminal className="w-4 h-4" />
            Compiler Lab
          </Link>

          <Link
            to="/security"
            className={`px-3.5 py-2 rounded-lg font-medium flex items-center gap-2 transition-colors ${
              isActive('/security')
                ? 'bg-indigo-50 text-indigo-700 font-semibold'
                : 'text-slate-500 hover:text-slate-800 hover:bg-slate-50'
            }`}
          >
            <Shield className="w-4 h-4" />
            Dashboard
          </Link>
        </div>

        {/* Right Actions */}
        <div className="flex items-center gap-3">
          {profile ? (
            <div className="flex items-center gap-3">
              <Link
                to="/profile"
                className="flex items-center gap-2 px-3 py-1.5 rounded-xl border border-slate-200 hover:border-slate-300 bg-slate-50 transition-colors"
              >
                <img
                  src={profile.avatarUrl}
                  alt={profile.fullName}
                  className="w-6 h-6 rounded-full bg-slate-200"
                />
                <span className="text-xs font-semibold text-slate-700 hidden sm:inline">
                  {profile.fullName}
                </span>
              </Link>
              <button
                onClick={handleLogout}
                title="Log Out"
                className="p-2 rounded-lg text-slate-400 hover:text-rose-600 hover:bg-rose-50 transition-colors"
              >
                <LogOut className="w-4 h-4" />
              </button>
            </div>
          ) : (
            <div className="flex items-center gap-2">
              <Link
                to="/login"
                className="px-3.5 py-2 text-xs font-semibold text-slate-600 hover:text-slate-900 transition-colors"
              >
                Login
              </Link>
              <Link
                to="/register"
                className="px-3.5 py-2 text-xs font-semibold bg-indigo-600 hover:bg-indigo-700 text-white rounded-lg transition-colors shadow-sm shadow-indigo-200"
              >
                Get Started
              </Link>
            </div>
          )}
        </div>
      </div>
    </nav>
  );
};
