import React from 'react';
import { ShieldAlert, Terminal } from 'lucide-react';
import { Message } from '../../types/chat';

interface RecentDetectionsTableProps {
  messages: Message[];
  onSelectMessage: (msg: Message) => void;
}

export const RecentDetectionsTable: React.FC<RecentDetectionsTableProps> = ({
  messages,
  onSelectMessage
}) => {
  const threats = messages.filter((m) => m.classification !== 'SAFE');

  return (
    <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 shadow-2xl space-y-4">
      <h3 className="text-sm font-extrabold text-white uppercase font-mono tracking-wider flex items-center gap-2">
        <ShieldAlert className="w-4 h-4 text-rose-400" />
        Recent Neutralized Threats & Flagged Messages
      </h3>

      {threats.length === 0 ? (
        <div className="text-center py-12 text-slate-500 font-mono text-xs">
          No security threats detected in current chat streams.
        </div>
      ) : (
        <div className="overflow-x-auto">
          <table className="w-full text-left font-mono text-xs">
            <thead>
              <tr className="border-b border-slate-800 text-slate-400 uppercase">
                <th className="pb-3 font-bold">Category</th>
                <th className="pb-3 font-bold">Threat Level</th>
                <th className="pb-3 font-bold">Risk Score</th>
                <th className="pb-3 font-bold">Original Raw Content</th>
                <th className="pb-3 font-bold text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60">
              {threats.map((msg) => (
                <tr key={msg.id} className="hover:bg-slate-800/40">
                  <td className="py-3 text-rose-400 font-bold">{msg.classification}</td>
                  <td className="py-3 uppercase text-slate-300">{msg.threatLevel}</td>
                  <td className="py-3 text-cyan-400 font-bold">{msg.riskScore}/100</td>
                  <td className="py-3 text-slate-300 max-w-md truncate">{msg.originalText}</td>
                  <td className="py-3 text-right">
                    <button
                      onClick={() => onSelectMessage(msg)}
                      className="px-3 py-1 bg-cyan-950 border border-cyan-800 text-cyan-400 hover:bg-cyan-900 rounded-lg text-[11px] font-bold flex items-center gap-1 ml-auto"
                    >
                      <Terminal className="w-3.5 h-3.5" /> AST Analysis
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
};
