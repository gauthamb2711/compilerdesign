import React from 'react';
import { ShieldCheck, ShieldAlert, AlertTriangle, MessageSquare } from 'lucide-react';
import { Message } from '../../types/chat';

interface SecurityStatsProps {
  messages: Message[];
}

export const SecurityStats: React.FC<SecurityStatsProps> = ({ messages }) => {
  const total = messages.length;
  const threats = messages.filter((m) => m.classification !== 'SAFE').length;
  const safe = total - threats;
  const threatPercentage = total > 0 ? Math.round((threats / total) * 100) : 0;

  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
      <div className="p-5 bg-slate-900 border border-slate-800 rounded-2xl flex items-center gap-4">
        <div className="p-3 bg-cyan-950 border border-cyan-800 rounded-xl text-cyan-400">
          <MessageSquare className="w-6 h-6" />
        </div>
        <div>
          <p className="text-xs font-mono text-slate-400 font-bold uppercase">Total Analyzed</p>
          <p className="text-2xl font-extrabold text-white">{total}</p>
        </div>
      </div>

      <div className="p-5 bg-slate-900 border border-slate-800 rounded-2xl flex items-center gap-4">
        <div className="p-3 bg-emerald-950 border border-emerald-800 rounded-xl text-emerald-400">
          <ShieldCheck className="w-6 h-6" />
        </div>
        <div>
          <p className="text-xs font-mono text-slate-400 font-bold uppercase">Safe Messages</p>
          <p className="text-2xl font-extrabold text-emerald-400">{safe}</p>
        </div>
      </div>

      <div className="p-5 bg-slate-900 border border-slate-800 rounded-2xl flex items-center gap-4">
        <div className="p-3 bg-rose-950 border border-rose-800 rounded-xl text-rose-400">
          <ShieldAlert className="w-6 h-6" />
        </div>
        <div>
          <p className="text-xs font-mono text-slate-400 font-bold uppercase">Threats Detected</p>
          <p className="text-2xl font-extrabold text-rose-400">{threats}</p>
        </div>
      </div>

      <div className="p-5 bg-slate-900 border border-slate-800 rounded-2xl flex items-center gap-4">
        <div className="p-3 bg-amber-950 border border-amber-800 rounded-xl text-amber-400">
          <AlertTriangle className="w-6 h-6" />
        </div>
        <div>
          <p className="text-xs font-mono text-slate-400 font-bold uppercase">Threat Rate</p>
          <p className="text-2xl font-extrabold text-amber-400">{threatPercentage}%</p>
        </div>
      </div>
    </div>
  );
};
