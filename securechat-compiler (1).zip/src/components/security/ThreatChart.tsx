import React from 'react';
import { Message } from '../../types/chat';

interface ThreatChartProps {
  messages: Message[];
}

export const ThreatChart: React.FC<ThreatChartProps> = ({ messages }) => {
  const categories = {
    SAFE: 0,
    PHISHING: 0,
    MALWARE: 0,
    PROFANITY: 0,
    SUSPICIOUS: 0
  };

  messages.forEach((msg) => {
    if (categories[msg.classification] !== undefined) {
      categories[msg.classification]++;
    }
  });

  const total = messages.length || 1;

  const colorMap: Record<string, string> = {
    SAFE: 'bg-emerald-500',
    PHISHING: 'bg-rose-500',
    MALWARE: 'bg-purple-500',
    PROFANITY: 'bg-amber-500',
    SUSPICIOUS: 'bg-blue-500'
  };

  return (
    <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 shadow-2xl space-y-4">
      <h3 className="text-sm font-extrabold text-white uppercase font-mono tracking-wider">
        Threat Breakdown by Compiler Classification
      </h3>

      <div className="space-y-3 font-mono text-xs">
        {Object.entries(categories).map(([cat, count]) => {
          const pct = Math.round((count / total) * 100);
          return (
            <div key={cat} className="space-y-1">
              <div className="flex justify-between text-slate-300">
                <span className="font-bold">{cat}</span>
                <span>{count} ({pct}%)</span>
              </div>
              <div className="h-3 bg-slate-950 border border-slate-800 rounded-full overflow-hidden">
                <div
                  className={`h-full ${colorMap[cat] || 'bg-cyan-500'} transition-all duration-500`}
                  style={{ width: `${pct}%` }}
                />
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
