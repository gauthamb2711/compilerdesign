import {
  GrammarProductionRule,
  LexicalResult,
  ParseTreeNode,
  SyntaxResult
} from './types';

export const GRAMMAR_RULES: GrammarProductionRule[] = [
  {
    id: 'R1',
    head: 'PROGRAM',
    body: ['STATEMENT_LIST'],
    raw: 'S → STATEMENT_LIST',
    description: 'Program root node decomposes into sequence of statements'
  },
  {
    id: 'R2',
    head: 'STATEMENT_LIST',
    body: ['STATEMENT', "STATEMENT_LIST'"],
    raw: 'STATEMENT_LIST → STATEMENT STATEMENT_LIST | ε',
    description: 'Recursive list of statements or empty tail'
  },
  {
    id: 'R3',
    head: 'STATEMENT',
    body: ['MESSAGE_DECL', '|', 'FUNCTION_CALL', '|', 'ASSIGNMENT', '|', 'EXPRESSION'],
    raw: 'STATEMENT → MESSAGE_DECL | FUNCTION_CALL | ASSIGNMENT | EXPRESSION',
    description: 'Individual syntactic construct'
  },
  {
    id: 'R4',
    head: 'MESSAGE_DECL',
    body: ['ID', 'ASSIGN', 'STRING_LITERAL', 'DELIMITER'],
    raw: 'MESSAGE_DECL → message ( ARG_LIST ) ;',
    description: 'Message declaration or dispatch function'
  },
  {
    id: 'R5',
    head: 'ARG_LIST',
    body: ['ARGUMENT', 'ARG_TAIL'],
    raw: 'ARG_LIST → ARGUMENT , ARG_LIST | ARGUMENT',
    description: 'Comma separated list of expressions or identifiers'
  },
  {
    id: 'R6',
    head: 'SECURITY_PHRASE',
    body: ['URGENT_MODIFIER', 'ACTION_PREDICATE', 'TARGET_OBJECT'],
    raw: 'SECURITY_PHRASE → URGENT_MODIFIER ACTION_PREDICATE TARGET_OBJECT',
    description: 'High-risk security semantics compound structure'
  },
  {
    id: 'R7',
    head: 'URL_EXPRESSION',
    body: ['PROTOCOL', 'DOMAIN', 'PATH'],
    raw: 'URL_EXPRESSION → PROTOCOL DOMAIN PATH',
    description: 'Uniform Resource Locator syntax decomposition'
  }
];

export function syntaxAnalysis(lexicalResult: LexicalResult): SyntaxResult {
  const patternsDetected: string[] = [];
  const syntaxErrors: string[] = [];
  const syntaxWarnings: string[] = [];
  const rulesUsed: GrammarProductionRule[] = [];
  let syntaxRisk = 0;

  const tokens = lexicalResult.tokens;
  const tokenValues = tokens.map((t) => t.value);
  const textLower = tokenValues.join(' ');
  const hasUrl = lexicalResult.urls.length > 0;

  // Track standard grammar production usage
  rulesUsed.push(GRAMMAR_RULES[0]); // R1: S -> STATEMENT_LIST
  rulesUsed.push(GRAMMAR_RULES[1]); // R2: STATEMENT_LIST -> STATEMENT
  rulesUsed.push(GRAMMAR_RULES[2]); // R3: STATEMENT -> ...

  // Pattern detection for language constructs and high risk security triggers
  if (textLower.includes('click') && hasUrl) {
    patternsDetected.push('CLICK_ACTION + URL_TARGET');
    syntaxRisk += 15;
    rulesUsed.push(GRAMMAR_RULES[5]);
  }

  if ((textLower.includes('login') || textLower.includes('signin')) && hasUrl) {
    patternsDetected.push('AUTH_HARVEST + EXTERNAL_URL');
    syntaxRisk += 25;
    rulesUsed.push(GRAMMAR_RULES[5]);
  }

  if (textLower.includes('verify') && (textLower.includes('account') || textLower.includes('bank'))) {
    patternsDetected.push('VERIFICATION_CALL + ACCOUNT_IDENTIFIER');
    syntaxRisk += 20;
    rulesUsed.push(GRAMMAR_RULES[4]);
  }

  if (textLower.includes('verify') && hasUrl) {
    patternsDetected.push('ACCOUNT_VERIFICATION + EXTERNAL_DEST');
    syntaxRisk += 25;
  }

  if ((textLower.includes('claim') || textLower.includes('get')) && (textLower.includes('prize') || textLower.includes('reward') || textLower.includes('lottery'))) {
    patternsDetected.push('REWARD_CLAIM + VALUE_PROMISE');
    syntaxRisk += 20;
  }

  if ((textLower.includes('send') || textLower.includes('share') || textLower.includes('give')) && (textLower.includes('otp') || textLower.includes('pin') || textLower.includes('password'))) {
    patternsDetected.push('CREDENTIAL_DISCLOSURE_REQUEST');
    syntaxRisk += 35;
  }

  if (textLower.includes('account') && (textLower.includes('blocked') || textLower.includes('suspended') || textLower.includes('frozen'))) {
    patternsDetected.push('URGENCY_ASSERTION + SUSPENSION_NOTICE');
    syntaxRisk += 25;
  }

  if ((textLower.includes('transfer') || textLower.includes('pay')) && (textLower.includes('money') || textLower.includes('fee') || textLower.includes('$'))) {
    patternsDetected.push('FINANCIAL_DISPATCH + MONETARY_LITERAL');
    syntaxRisk += 20;
  }

  if (hasUrl) {
    rulesUsed.push(GRAMMAR_RULES[6]); // URL_EXPRESSION
  }

  // Syntax Diagnostic Checks
  let openParenCount = 0;
  let openQuoteCount = 0;
  tokens.forEach((token) => {
    if (token.raw === '(') openParenCount++;
    if (token.raw === ')') openParenCount--;
    if (token.raw === '"' || token.raw === "'") openQuoteCount++;
  });

  if (openParenCount !== 0) {
    syntaxErrors.push(`SyntaxError: Unbalanced parentheses (delta: ${openParenCount})`);
  }

  if (openQuoteCount % 2 !== 0) {
    syntaxWarnings.push('SyntaxWarning: Unclosed string literal quotes detected');
  }

  const suspiciousStructure = syntaxRisk >= 35 || patternsDetected.length >= 2;

  // Build Comprehensive Parse Tree (CST)
  const parseTreeChildren: ParseTreeNode[] = [];

  // Urgency phrase node
  const urgentTokens = tokens.filter((t) => t.type === 'URGENT_KEYWORD');
  if (urgentTokens.length > 0 || textLower.includes('urgent')) {
    parseTreeChildren.push({
      id: 'node-urgency',
      label: 'URGENCY_PHRASE',
      type: 'STATEMENT',
      value: urgentTokens.map((t) => t.raw).join(' ') || 'URGENT!',
      children: urgentTokens.map((t, idx) => ({
        id: `node-urg-${idx}`,
        label: 'URGENT_MODIFIER',
        type: 'TERMINAL',
        value: t.raw
      }))
    });
  }

  // Account / Financial node
  const finTokens = tokens.filter((t) => t.type === 'FINANCIAL_KEYWORD' || t.type === 'CREDENTIAL_KEYWORD');
  if (finTokens.length > 0 || textLower.includes('bank') || textLower.includes('account')) {
    parseTreeChildren.push({
      id: 'node-account',
      label: 'FINANCIAL_CONTEXT',
      type: 'NON_TERMINAL',
      value: finTokens.map((t) => t.raw).join(' ') || 'Account Subject',
      children: finTokens.map((t, idx) => ({
        id: `node-fin-${idx}`,
        label: 'FINANCIAL_TOKEN',
        type: 'TERMINAL',
        value: t.raw
      }))
    });
  }

  // Action / Demand Request node
  const actionTokens = tokens.filter((t) => t.type === 'ACTION_KEYWORD' || t.type === 'OTP');
  if (actionTokens.length > 0) {
    parseTreeChildren.push({
      id: 'node-action',
      label: 'ACTION_REQUEST',
      type: 'STATEMENT',
      value: actionTokens.map((t) => t.raw).join(' '),
      children: actionTokens.map((t, idx) => ({
        id: `node-act-${idx}`,
        label: 'ACTION_VERB',
        type: 'TERMINAL',
        value: t.raw
      }))
    });
  }

  // External URLs
  if (lexicalResult.urls.length > 0) {
    parseTreeChildren.push({
      id: 'node-url-expr',
      label: 'EXTERNAL_RESOURCE',
      type: 'EXPRESSION',
      value: lexicalResult.urls.join(', '),
      children: lexicalResult.urls.map((url, idx) => ({
        id: `node-url-${idx}`,
        label: 'URL_LITERAL',
        type: 'LITERAL',
        value: url
      }))
    });
  }

  // General Statements / Expressions
  const identifiers = tokens.filter((t) => t.category === 'IDENTIFIER' || t.category === 'KEYWORD');
  if (identifiers.length > 0 && parseTreeChildren.length === 0) {
    parseTreeChildren.push({
      id: 'node-stmt',
      label: 'EXPRESSION_STATEMENT',
      type: 'STATEMENT',
      value: identifiers.map((t) => t.raw).join(' '),
      children: tokens.slice(0, 8).map((t, idx) => ({
        id: `node-tok-${idx}`,
        label: t.category || 'TOKEN',
        type: 'TERMINAL',
        value: t.raw
      }))
    });
  }

  const parseTree: ParseTreeNode = {
    id: 'node-root',
    label: 'PROGRAM_ROOT',
    type: 'NON_TERMINAL',
    value: 'Source Entry (Line 1)',
    children: parseTreeChildren.length > 0 ? parseTreeChildren : [
      {
        id: 'node-empty',
        label: 'EMPTY_BODY',
        type: 'TERMINAL',
        value: 'Pass-through'
      }
    ]
  };

  // Build Abstract Syntax Tree (AST) - Compact, semantic-focused
  const astChildren: ParseTreeNode[] = [];

  if (lexicalResult.urls.length > 0) {
    astChildren.push({
      id: 'ast-url',
      label: 'ExternalLink',
      type: 'EXPRESSION',
      value: lexicalResult.urls[0]
    });
  }

  if (urgentTokens.length > 0) {
    astChildren.push({
      id: 'ast-urgency',
      label: 'UrgencyAttribute',
      type: 'LITERAL',
      value: urgentTokens[0].raw
    });
  }

  if (actionTokens.length > 0) {
    astChildren.push({
      id: 'ast-action',
      label: 'ActionDispatch',
      type: 'STATEMENT',
      value: actionTokens[0].raw
    });
  }

  const otherKeywords = tokens.filter((t) => t.category === 'IDENTIFIER' || t.category === 'KEYWORD');
  if (otherKeywords.length > 0) {
    astChildren.push({
      id: 'ast-ident',
      label: 'IdentifierRef',
      type: 'IDENTIFIER',
      value: otherKeywords[0].raw
    });
  }

  const ast: ParseTreeNode = {
    id: 'ast-root',
    label: 'AST: MessageBlock',
    type: 'NON_TERMINAL',
    children: astChildren.length > 0 ? astChildren : [
      {
        id: 'ast-default',
        label: 'MessageLiteral',
        type: 'LITERAL',
        value: tokens.map((t) => t.raw).slice(0, 4).join(' ') || 'Empty'
      }
    ]
  };

  // Derivation steps (Leftmost derivation S => ...)
  const derivationSteps = [
    'S',
    '⇒ STATEMENT_LIST',
    '⇒ STATEMENT STATEMENT_LIST',
    `⇒ ${parseTreeChildren[0]?.label || 'EXPR'} STATEMENT_LIST`,
    `⇒ ${parseTreeChildren[0]?.value || 'ID'} ( ARG_LIST )`
  ];

  return {
    patternsDetected,
    suspiciousStructure,
    syntaxRisk: Math.min(100, syntaxRisk),
    parseTree,
    ast,
    grammarRulesUsed: rulesUsed,
    syntaxErrors,
    syntaxWarnings,
    derivationSteps
  };
}
