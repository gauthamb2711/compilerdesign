import {
  ClassificationCategory,
  LexicalResult,
  SemanticCheckRecord,
  SemanticFlags,
  SemanticResult,
  SymbolDataType,
  SymbolTableEntry,
  SyntaxResult,
  ThreatLevel
} from './types';
import {
  ACTION_KEYWORDS,
  CREDENTIAL_KEYWORDS,
  FINANCIAL_KEYWORDS,
  OTP_KEYWORDS,
  REWARD_KEYWORDS,
  SUSPICIOUS_DOMAINS,
  URGENT_KEYWORDS
} from './securityRules';

export function semanticAnalysis(
  lexicalResult: LexicalResult,
  syntaxResult: SyntaxResult,
  originalMessage: string
): SemanticResult {
  const flags: SemanticFlags = {
    urgency: false,
    financialRequest: false,
    credentialRequest: false,
    otpRequest: false,
    passwordRequest: false,
    accountVerification: false,
    bankImpersonation: false,
    fakeReward: false,
    prizeClaim: false,
    externalUrl: false,
    suspiciousUrl: false,
    promotionalSpam: false,
    repeatedSpam: false,
    threateningAction: false,
    personalConversation: false,
    misleadingClaims: false
  };

  const riskReasons: string[] = [];
  const typeErrors: string[] = [];
  const scopeErrors: string[] = [];
  const semanticChecks: SemanticCheckRecord[] = [];
  const symbolTable: SymbolTableEntry[] = [];

  let riskScore = 0;
  const messageLower = originalMessage.toLowerCase();
  const tokens = lexicalResult.tokens;
  const tokenTypes = tokens.map((t) => t.type);

  // 1. SYMBOL TABLE GENERATION
  const encounteredSymbols = new Map<string, SymbolTableEntry>();

  // Add standard program symbols
  tokens.forEach((t) => {
    const symName = t.raw.replace(/[^a-zA-Z0-9_]/g, '');
    if (symName && symName.length > 1 && !encounteredSymbols.has(symName.toLowerCase())) {
      let dType: SymbolDataType = 'String';
      let isConst = false;

      if (t.category === 'NUMBER_LITERAL' || /^\d+$/.test(symName)) {
        dType = 'Integer';
        isConst = true;
      } else if (t.category === 'URL_LITERAL' || t.type === 'URL') {
        dType = 'URL';
        isConst = true;
      } else if (t.category === 'KEYWORD') {
        dType = 'Void';
        isConst = true;
      }

      const entry: SymbolTableEntry = {
        name: symName,
        type: dType,
        scope: t.line === 1 ? 'Global' : 'Local',
        memoryOffset: `0x${(0x1000 + encounteredSymbols.size * 16).toString(16).toUpperCase()}`,
        line: t.line || 1,
        col: t.col || 1,
        initialValue: `"${t.raw.slice(0, 16)}"`,
        refCount: tokens.filter((x) => x.value === t.value).length,
        isConstant: isConst,
        isSanitized: false
      };

      encounteredSymbols.set(symName.toLowerCase(), entry);
      symbolTable.push(entry);
    }
  });

  // Ensure baseline symbols exist for empty/short inputs
  if (symbolTable.length === 0) {
    symbolTable.push({
      name: 'msg_payload',
      type: 'String',
      scope: 'Global',
      memoryOffset: '0x1000',
      line: 1,
      col: 1,
      initialValue: '""',
      refCount: 1,
      isConstant: false,
      isSanitized: true
    });
  }

  // 2. SEMANTIC TYPE & SCOPE CHECKS
  semanticChecks.push({
    checkName: 'Symbol Scope Resolution',
    category: 'SCOPE_CHECK',
    passed: true,
    details: `Resolved ${symbolTable.length} identifiers within Global/Local scope hierarchy`
  });

  semanticChecks.push({
    checkName: 'Static Type Binding',
    category: 'TYPE_CHECK',
    passed: true,
    details: 'All message parameters and argument types conform to String/Resource type bounds'
  });

  // 3. SEMANTIC SECURITY / FRAUD EVALUATION
  // Urgency
  const hasUrgentKeyword = tokens.some((t) => t.type === 'URGENT_KEYWORD');
  if (hasUrgentKeyword || messageLower.includes('urgent') || messageLower.includes('immediately')) {
    flags.urgency = true;
    riskScore += 20;
    riskReasons.push('Urgent language asserting artificial time pressure');
  }

  // OTP / Pin Request
  const hasOtp = tokens.some((t) => t.type === 'OTP') || messageLower.includes('otp');
  if (hasOtp) {
    flags.otpRequest = true;
    flags.credentialRequest = true;
    riskScore += 45;
    riskReasons.push('Direct solicitation of One-Time Password (OTP) or authentication code');
  }

  // Password / Pin Request
  if (messageLower.includes('password') || messageLower.includes('pin') || messageLower.includes('cvv')) {
    flags.passwordRequest = true;
    flags.credentialRequest = true;
    riskScore += 45;
    riskReasons.push('Solicitation of password, PIN, or confidential security credentials');
  }

  // Financial / Money Demand
  const hasFinancial = tokens.some((t) => t.type === 'FINANCIAL_KEYWORD' || t.type === 'CURRENCY');
  if (hasFinancial || messageLower.includes('bank') || messageLower.includes('account') || messageLower.includes('transfer')) {
    flags.financialRequest = true;
    if (flags.urgency || flags.credentialRequest) {
      riskScore += 25;
      riskReasons.push('High-risk combination of financial references with urgency/credentials');
    }
  }

  // Bank Impersonation
  if (messageLower.includes('bank') && (messageLower.includes('support') || messageLower.includes('manager') || messageLower.includes('officer') || messageLower.includes('team'))) {
    flags.bankImpersonation = true;
    riskScore += 35;
    riskReasons.push('Impersonation of official banking or customer support authority');
  }

  // URLs & Suspicious domains
  if (lexicalResult.urls.length > 0) {
    flags.externalUrl = true;
    riskScore += 15;

    for (const url of lexicalResult.urls) {
      const urlLower = url.toLowerCase();
      const isSuspicious = Array.from(SUSPICIOUS_DOMAINS).some((domain) => urlLower.includes(domain));
      if (isSuspicious || urlLower.includes('bit.ly') || urlLower.includes('tinyurl') || urlLower.includes('free') || urlLower.includes('claim')) {
        flags.suspiciousUrl = true;
        riskScore += 30;
        riskReasons.push(`Suspicious external redirect link: ${url}`);
        break;
      }
    }
  }

  // Fake Reward & Lottery
  const hasReward = tokens.some((t) => t.type === 'REWARD_KEYWORD');
  if (hasReward || messageLower.includes('lottery') || messageLower.includes('prize') || messageLower.includes('winner') || messageLower.includes('congratulations')) {
    flags.fakeReward = true;
    flags.prizeClaim = true;
    riskScore += 30;
    riskReasons.push('Deceptive prize / lottery winning lure');
  }

  // Spam Punctuation
  if (/!{3,}|\?{3,}/.test(originalMessage) || (originalMessage.length > 20 && originalMessage === originalMessage.toUpperCase())) {
    flags.promotionalSpam = true;
    flags.repeatedSpam = true;
    riskScore += 15;
    riskReasons.push('Excessive capitalization and aggressive spam punctuation');
  }

  // Misleading viral chains
  if (messageLower.includes('forward this') || messageLower.includes('share to') || messageLower.includes('100% real')) {
    flags.misleadingClaims = true;
    riskScore += 20;
    riskReasons.push('Chain-forward viral disinformation indicators');
  }

  // Normal conversation check
  if (
    !flags.urgency &&
    !flags.credentialRequest &&
    !flags.otpRequest &&
    !flags.fakeReward &&
    !flags.suspiciousUrl &&
    !flags.bankImpersonation &&
    !flags.misleadingClaims
  ) {
    flags.personalConversation = true;
  }

  // Final Risk Score Bounds
  riskScore = Math.min(100, Math.max(0, riskScore));

  // Determine Classification Category
  let classification: ClassificationCategory = 'SAFE';
  let threatLevel: ThreatLevel = 'LOW';

  if (flags.suspiciousUrl && (flags.credentialRequest || flags.accountVerification || flags.urgency)) {
    classification = 'PHISHING';
    threatLevel = 'CRITICAL';
  } else if (flags.otpRequest || flags.bankImpersonation || (flags.financialRequest && flags.urgency)) {
    classification = 'FRAUD';
    threatLevel = 'HIGH';
  } else if (flags.fakeReward || flags.prizeClaim) {
    classification = 'FRAUD';
    threatLevel = 'HIGH';
  } else if (flags.misleadingClaims) {
    classification = 'MISLEADING';
    threatLevel = 'MEDIUM';
  } else if (flags.promotionalSpam || flags.repeatedSpam) {
    classification = 'SPAM';
    threatLevel = 'MEDIUM';
  } else if (riskScore >= 40) {
    classification = 'SUSPICIOUS';
    threatLevel = 'MEDIUM';
  } else {
    classification = 'SAFE';
    threatLevel = 'LOW';
  }

  // Confidence Calculation
  const confidence = Math.min(99, Math.max(82, 85 + tokens.length * 2 - (riskScore % 7)));

  semanticChecks.push({
    checkName: 'Threat & Malice Semantic Invariant',
    category: 'SECURITY_RULE',
    passed: classification === 'SAFE',
    details: classification === 'SAFE'
      ? 'Invariant satisfied: Zero malicious or phishing signatures detected'
      : `Invariant violated: Flagged as [${classification}] with risk score ${riskScore}/100`
  });

  return {
    flags,
    riskReasons,
    riskScore,
    confidence,
    classification,
    threatLevel,
    symbolTable,
    semanticChecks,
    typeErrors,
    scopeErrors
  };
}
