export type StandardTokenType =
  | 'KEYWORD'
  | 'IDENTIFIER'
  | 'STRING_LITERAL'
  | 'NUMBER_LITERAL'
  | 'OPERATOR'
  | 'DELIMITER'
  | 'URL_LITERAL'
  | 'EMAIL_LITERAL'
  | 'PHONE_LITERAL'
  | 'CURRENCY_LITERAL'
  | 'SECURITY_TOKEN'
  | 'SPECIAL_SYMBOL'
  | 'COMMENT';

export type TokenType =
  | StandardTokenType
  | 'WORD'
  | 'NUMBER'
  | 'URL'
  | 'EMAIL'
  | 'PHONE_NUMBER'
  | 'CURRENCY'
  | 'OTP'
  | 'URGENT_KEYWORD'
  | 'FINANCIAL_KEYWORD'
  | 'CREDENTIAL_KEYWORD'
  | 'ACTION_KEYWORD'
  | 'REWARD_KEYWORD'
  | 'SPECIAL_CHARACTER';

export interface Token {
  type: TokenType;
  category?: StandardTokenType;
  value: string;
  raw: string;
  index: number;
  line: number;
  col: number;
}

export interface LexicalResult {
  tokens: Token[];
  urls: string[];
  emails: string[];
  phoneNumbers: string[];
  keywords: { word: string; category: TokenType }[];
  tokenCount: number;
  identifierCount?: number;
  literalCount?: number;
  operatorCount?: number;
  delimiterCount?: number;
}

export interface ParseTreeNode {
  id?: string;
  label: string;
  value?: string;
  type?: 'NON_TERMINAL' | 'TERMINAL' | 'STATEMENT' | 'EXPRESSION' | 'LITERAL' | 'IDENTIFIER';
  children?: ParseTreeNode[];
  expanded?: boolean;
}

export interface GrammarProductionRule {
  id: string;
  head: string;
  body: string[];
  raw: string;
  description?: string;
}

export interface SyntaxResult {
  patternsDetected: string[];
  suspiciousStructure: boolean;
  syntaxRisk: number;
  parseTree: ParseTreeNode;
  ast: ParseTreeNode;
  grammarRulesUsed: GrammarProductionRule[];
  syntaxErrors: string[];
  syntaxWarnings: string[];
  derivationSteps?: string[];
}

export type ClassificationCategory =
  | 'SAFE'
  | 'SPAM'
  | 'SUSPICIOUS'
  | 'MISLEADING'
  | 'FRAUD'
  | 'PHISHING';

export type Classification = ClassificationCategory;

export type ThreatLevel = 'LOW' | 'MEDIUM' | 'HIGH' | 'CRITICAL';

export interface SemanticFlags {
  urgency: boolean;
  financialRequest: boolean;
  credentialRequest: boolean;
  otpRequest: boolean;
  passwordRequest: boolean;
  accountVerification: boolean;
  bankImpersonation: boolean;
  fakeReward: boolean;
  prizeClaim: boolean;
  externalUrl: boolean;
  suspiciousUrl: boolean;
  promotionalSpam: boolean;
  repeatedSpam: boolean;
  threateningAction: boolean;
  personalConversation: boolean;
  misleadingClaims: boolean;
}

export type SymbolDataType =
  | 'String'
  | 'Number'
  | 'Integer'
  | 'Float'
  | 'Boolean'
  | 'URL'
  | 'Function'
  | 'Pointer'
  | 'Void'
  | 'Unknown';

export type SymbolScope = 'Global' | 'Function' | 'Local' | 'Block' | 'Parameter';

export interface SymbolTableEntry {
  name: string;
  type: SymbolDataType;
  scope: SymbolScope;
  memoryOffset: string;
  line: number;
  col?: number;
  initialValue: string;
  refCount: number;
  isConstant: boolean;
  isSanitized: boolean;
}

export interface SemanticCheckRecord {
  checkName: string;
  category: 'TYPE_CHECK' | 'SCOPE_CHECK' | 'DECLARATION' | 'SECURITY_RULE' | 'ATTRIBUTE_EVAL';
  passed: boolean;
  details: string;
}

export interface SemanticResult {
  flags: SemanticFlags;
  riskReasons: string[];
  riskScore: number;
  confidence: number;
  classification: ClassificationCategory;
  threatLevel: ThreatLevel;
  symbolTable: SymbolTableEntry[];
  semanticChecks: SemanticCheckRecord[];
  typeErrors: string[];
  scopeErrors: string[];
}

export type TargetOperation =
  | 'REMOVE_SUSPICIOUS_URL'
  | 'NEUTRALIZE_URL'
  | 'MASK_SENSITIVE_DATA'
  | 'NORMALIZE_REPEATED_TEXT'
  | 'REMOVE_EXCESSIVE_SPAM'
  | 'NEUTRALIZE_FULL_MESSAGE'
  | 'TRANSFORM_SUSPICIOUS_PAYLOAD'
  | 'ADD_SECURITY_WARNING'
  | 'SAFE_DELIVERY';

export interface ThreeAddressCodeInstruction {
  index: number;
  op: string;
  arg1?: string;
  arg2?: string;
  result?: string;
  code: string;
  comment?: string;
}

export interface Quadruple {
  index: number;
  op: string;
  arg1: string;
  arg2: string;
  result: string;
}

export interface BasicBlock {
  id: string;
  label: string;
  instructions: ThreeAddressCodeInstruction[];
  predecessors: string[];
  successors: string[];
}

export interface IntermediateRepresentation {
  messageType: ClassificationCategory;
  riskScore: number;
  threatLevel: ThreatLevel;
  flags: SemanticFlags;
  operations: TargetOperation[];
  threeAddressCode: ThreeAddressCodeInstruction[];
  quadruples: Quadruple[];
  basicBlocks: BasicBlock[];
  irCodeText: string;
}

export type OptimizationTechnique =
  | 'CONSTANT_FOLDING'
  | 'CONSTANT_PROPAGATION'
  | 'DEAD_CODE_ELIMINATION'
  | 'COMMON_SUBEXPRESSION'
  | 'STRENGTH_REDUCTION'
  | 'COPY_PROPAGATION'
  | 'PAYLOAD_NEUTRALIZATION'
  | 'LINK_SANITIZATION';

export interface OptimizationPass {
  id: string;
  name: string;
  technique: OptimizationTechnique;
  description: string;
  beforeInstructions: string[];
  afterInstructions: string[];
  instructionsRemoved: number;
}

export interface OptimizationResult {
  transformationsPerformed: string[];
  removedUrls: string[];
  optimizedText: string;
  removedUrlCount: number;
  passes: OptimizationPass[];
  beforeIrCode: string[];
  afterIrCode: string[];
  instructionReductionCount: number;
  improvementPercentage: number;
}

export type TargetArchitecture = 'x86_64' | 'ARM64' | 'MIPS' | 'PSEUDO_ASSEMBLY';

export interface TargetAssemblyOutput {
  architecture: TargetArchitecture;
  code: string;
  instructionsCount: number;
  registerAllocation: Record<string, string>;
  estimatedCycles: number;
  byteSize: number;
}

export interface CodeGeneratorResult {
  targetText: string;
  securityWarningRequired: boolean;
  warningHeader?: string;
  warningReasons: string[];
  classificationBadge: ClassificationCategory;
  confidence: number;
  riskScore: number;
  threatLevel: ThreatLevel;
  assemblyOutputs: Record<TargetArchitecture, TargetAssemblyOutput>;
  selectedArch: TargetArchitecture;
  totalInstructions: number;
}

export interface CompilationStatistics {
  tokensGenerated: number;
  syntaxNodes: number;
  symbolCount: number;
  semanticChecks: number;
  irInstructions: number;
  optimizationsApplied: number;
  finalInstructions: number;
  compilationTimeMs: number;
  codeReductionPercent: number;
}

export interface CompilerConsoleLog {
  id: string;
  type: 'ERROR' | 'WARNING' | 'INFO' | 'SUCCESS';
  phase: number;
  phaseName: string;
  message: string;
  line?: number;
  col?: number;
  timestamp: string;
}

export interface CompilerResult {
  originalText: string;
  lexical: LexicalResult;
  syntax: SyntaxResult;
  semantic: SemanticResult;
  intermediateCode: IntermediateRepresentation;
  optimization: OptimizationResult;
  codeGen: CodeGeneratorResult;
  processedText: string;
  classification: ClassificationCategory;
  confidence: number;
  riskScore: number;
  threatLevel: ThreatLevel;
  detectedUrls: string[];
  removedUrls: string[];
  hasUrl: boolean;
  reasons: string[];
  statistics: CompilationStatistics;
  logs: CompilerConsoleLog[];
}
