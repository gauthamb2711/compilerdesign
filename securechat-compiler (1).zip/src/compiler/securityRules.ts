export const URGENT_KEYWORDS = new Set([
  'urgent',
  'immediately',
  'alert',
  'asap',
  'blocked',
  'suspended',
  'warning',
  'expire',
  'expires',
  'expiring',
  'action required',
  'last chance',
  'now',
  'critical',
  'emergency'
]);

export const FINANCIAL_KEYWORDS = new Set([
  'bank',
  'account',
  'rs',
  'rupees',
  'inr',
  'usd',
  'transfer',
  'pay',
  'payment',
  'money',
  'deposit',
  'card',
  'credit',
  'debit',
  'balance',
  'refund',
  'cash',
  'billing',
  'fund',
  'transaction'
]);

export const CREDENTIAL_KEYWORDS = new Set([
  'password',
  'passcode',
  'pin',
  'login',
  'signin',
  'log-in',
  'sign-in',
  'auth',
  'credential',
  'verify',
  'verification',
  'security code',
  'username'
]);

export const OTP_KEYWORDS = new Set([
  'otp',
  'one-time password',
  'one time password',
  'verification code',
  'auth code'
]);

export const ACTION_KEYWORDS = new Set([
  'click',
  'claim',
  'login',
  'verify',
  'download',
  'share',
  'send',
  'update',
  'open',
  'confirm',
  'forward',
  'submit',
  'visit'
]);

export const REWARD_KEYWORDS = new Set([
  'won',
  'winner',
  'prize',
  'reward',
  'lottery',
  'congratulations',
  'congrats',
  'free',
  'guaranteed',
  '100%',
  'bonus',
  'gift',
  'cashback',
  'offer'
]);

export const PERSONAL_WORDS = new Set([
  'hi',
  'hello',
  'hey',
  'bro',
  'dude',
  'friend',
  'tomorrow',
  'today',
  'college',
  'office',
  'class',
  'varuviya',
  'saptiya',
  'paniya',
  'lunch',
  'dinner',
  'breakfast',
  'meeting',
  'going',
  'coming',
  'see you',
  'thanks',
  'thank you',
  'okay',
  'ok'
]);

export const URL_REGEX = /(https?:\/\/[^\s]+|www\.[^\s]+|[a-zA-Z0-9-]+\.(?:com|org|net|xyz|info|top|site|online|tech|co|io|app|live|ru|tk)\b[^\s]*)/gi;
export const EMAIL_REGEX = /\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b/g;
export const PHONE_REGEX = /\b(?:\+?\d{1,3}[-.\s]?)?\(?\d{3}\)?[-.\s]?\d{3}[-.\s]?\d{4}\b/g;
export const CURRENCY_REGEX = /(?:Rs\.?|INR|\$|€|£)\s?[\d,]+(?:\.\d{2})?/gi;
export const OTP_REGEX = /\b(?:\d{4}|\d{6})\b/g;

export const SUSPICIOUS_DOMAINS = [
  'fake-bank',
  'bit.ly',
  'tinyurl',
  'goo.gl',
  'is.gd',
  'buff.ly',
  't.co',
  'xyz',
  'top',
  'free',
  'login-',
  'verify-',
  'secure-bank',
  'update-account',
  'prize-claim'
];
