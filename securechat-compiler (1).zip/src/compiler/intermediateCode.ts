import {
  BasicBlock,
  IntermediateRepresentation,
  Quadruple,
  SemanticResult,
  TargetOperation,
  ThreeAddressCodeInstruction
} from './types';

export function generateIntermediateCode(
  semanticResult: SemanticResult,
  originalMessage: string
): IntermediateRepresentation {
  const { flags, classification, threatLevel, riskScore, symbolTable } = semanticResult;
  const operations: TargetOperation[] = [];
  const tac: ThreeAddressCodeInstruction[] = [];
  const quadruples: Quadruple[] = [];

  // Determine IR target transformation directives
  if (flags.suspiciousUrl || flags.externalUrl) {
    operations.push('REMOVE_SUSPICIOUS_URL');
    operations.push('NEUTRALIZE_URL');
  }

  if (flags.otpRequest || flags.passwordRequest || flags.credentialRequest) {
    operations.push('MASK_SENSITIVE_DATA');
  }

  if (flags.promotionalSpam || flags.repeatedSpam) {
    operations.push('NORMALIZE_REPEATED_TEXT');
    operations.push('REMOVE_EXCESSIVE_SPAM');
  }

  if (classification !== 'SAFE') {
    operations.push('NEUTRALIZE_FULL_MESSAGE');
    operations.push('TRANSFORM_SUSPICIOUS_PAYLOAD');
    operations.push('ADD_SECURITY_WARNING');
  } else {
    operations.push('SAFE_DELIVERY');
  }

  // Generate Three-Address Code (TAC) and Quadruples
  let tempIndex = 1;
  let quadIndex = 0;

  // 1. Initial Load of message buffer
  tac.push({
    index: tac.length,
    op: 'LOAD_STR',
    arg1: `"${originalMessage.slice(0, 24).replace(/"/g, "'")}..."`,
    result: `t${tempIndex}`,
    code: `t${tempIndex} = LOAD_STR "${originalMessage.slice(0, 24)}..."`,
    comment: 'Load raw message stream into temporary buffer'
  });
  quadruples.push({
    index: quadIndex++,
    op: 'LOAD_STR',
    arg1: `"${originalMessage.slice(0, 16)}..."`,
    arg2: '-',
    result: `t${tempIndex}`
  });
  const rawMsgTemp = `t${tempIndex++}`;

  // 2. Token Stream Extraction
  tac.push({
    index: tac.length,
    op: 'TOKEN_SCAN',
    arg1: rawMsgTemp,
    result: `t${tempIndex}`,
    code: `t${tempIndex} = TOKEN_SCAN ${rawMsgTemp}`,
    comment: 'Extract lexemes into structured token array'
  });
  quadruples.push({
    index: quadIndex++,
    op: 'TOKEN_SCAN',
    arg1: rawMsgTemp,
    arg2: '-',
    result: `t${tempIndex}`
  });
  const tokenArrayTemp = `t${tempIndex++}`;

  // 3. Security Inspection Call
  tac.push({
    index: tac.length,
    op: 'EVAL_SEMANTICS',
    arg1: tokenArrayTemp,
    arg2: `SCORE_${riskScore}`,
    result: `t${tempIndex}`,
    code: `t${tempIndex} = EVAL_SEMANTICS ${tokenArrayTemp}, ${riskScore}`,
    comment: `Computed risk classification: ${classification}`
  });
  quadruples.push({
    index: quadIndex++,
    op: 'EVAL_SEMANTICS',
    arg1: tokenArrayTemp,
    arg2: `${riskScore}`,
    result: `t${tempIndex}`
  });
  const evalTemp = `t${tempIndex++}`;

  // 4. Conditional Branch on Malice
  if (classification !== 'SAFE') {
    tac.push({
      index: tac.length,
      op: 'CJUMP_IF_MALICIOUS',
      arg1: evalTemp,
      arg2: 'LABEL_SANITIZE',
      result: '-',
      code: `IF ${evalTemp} == THREAT GOTO LABEL_SANITIZE`,
      comment: 'Branch to optimizer sanitization block'
    });
    quadruples.push({
      index: quadIndex++,
      op: 'CJUMP',
      arg1: evalTemp,
      arg2: 'THREAT',
      result: 'L_SANITIZE'
    });

    tac.push({
      index: tac.length,
      op: 'LABEL',
      result: 'LABEL_SANITIZE',
      code: `LABEL_SANITIZE:`,
      comment: 'Begin security neutralization pipeline'
    });
    quadruples.push({
      index: quadIndex++,
      op: 'LABEL',
      arg1: '-',
      arg2: '-',
      result: 'L_SANITIZE'
    });

    tac.push({
      index: tac.length,
      op: 'APPLY_OPTIMIZER',
      arg1: rawMsgTemp,
      arg2: `MODE_${classification}`,
      result: `t${tempIndex}`,
      code: `t${tempIndex} = APPLY_OPTIMIZER ${rawMsgTemp}, "${classification}"`,
      comment: 'Neutralize links, mask tokens & apply sanitization header'
    });
    quadruples.push({
      index: quadIndex++,
      op: 'APPLY_OPT',
      arg1: rawMsgTemp,
      arg2: classification,
      result: `t${tempIndex}`
    });
    const sanitizedTemp = `t${tempIndex++}`;

    tac.push({
      index: tac.length,
      op: 'DISPATCH_TARGET',
      arg1: sanitizedTemp,
      result: 'OUT_REG',
      code: `OUT_REG = DISPATCH_TARGET ${sanitizedTemp}`,
      comment: 'Emit neutralized payload to target client'
    });
    quadruples.push({
      index: quadIndex++,
      op: 'DISPATCH',
      arg1: sanitizedTemp,
      arg2: '-',
      result: 'OUT_REG'
    });
  } else {
    tac.push({
      index: tac.length,
      op: 'DISPATCH_SAFE',
      arg1: rawMsgTemp,
      result: 'OUT_REG',
      code: `OUT_REG = DISPATCH_SAFE ${rawMsgTemp}`,
      comment: 'Direct zero-copy pass through for verified safe payload'
    });
    quadruples.push({
      index: quadIndex++,
      op: 'DISPATCH_SAFE',
      arg1: rawMsgTemp,
      arg2: '-',
      result: 'OUT_REG'
    });
  }

  tac.push({
    index: tac.length,
    op: 'RET',
    arg1: 'OUT_REG',
    code: `RETURN OUT_REG`,
    comment: 'End of compilation unit'
  });
  quadruples.push({
    index: quadIndex++,
    op: 'RET',
    arg1: 'OUT_REG',
    arg2: '-',
    result: '-'
  });

  // Construct Control Flow Graph Basic Blocks (B1, B2)
  const basicBlocks: BasicBlock[] = [
    {
      id: 'B1',
      label: 'B1: Entry & Lexical Scan',
      instructions: tac.slice(0, 3),
      predecessors: ['ENTRY'],
      successors: classification !== 'SAFE' ? ['B2_SANITIZE', 'B3_EXIT'] : ['B3_EXIT']
    }
  ];

  if (classification !== 'SAFE') {
    basicBlocks.push({
      id: 'B2_SANITIZE',
      label: 'B2: Payload Sanitization & Header Injection',
      instructions: tac.slice(3, tac.length - 1),
      predecessors: ['B1'],
      successors: ['B3_EXIT']
    });
  }

  basicBlocks.push({
    id: 'B3_EXIT',
    label: 'B3: Target Dispatch & Return',
    instructions: [tac[tac.length - 1]],
    predecessors: classification !== 'SAFE' ? ['B2_SANITIZE'] : ['B1'],
    successors: ['EXIT']
  });

  const irCodeText = tac.map((instr) => `${instr.code.padEnd(42, ' ')} // ${instr.comment || ''}`).join('\n');

  return {
    messageType: classification,
    riskScore,
    threatLevel,
    flags,
    operations,
    threeAddressCode: tac,
    quadruples,
    basicBlocks,
    irCodeText
  };
}
