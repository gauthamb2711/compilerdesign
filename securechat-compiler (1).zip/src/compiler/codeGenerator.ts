import {
  CodeGeneratorResult,
  OptimizationResult,
  SemanticResult,
  TargetArchitecture,
  TargetAssemblyOutput
} from './types';

export function generateCode(
  semanticResult: SemanticResult,
  optimizationResult: OptimizationResult,
  originalMessage: string
): CodeGeneratorResult {
  const { classification, confidence, riskScore, threatLevel, riskReasons } = semanticResult;
  const processedText = optimizationResult.optimizedText;

  const warningReasons = riskReasons;
  const securityWarningRequired = classification !== 'SAFE';
  let warningHeader: string | undefined;

  if (classification === 'PHISHING') {
    warningHeader = 'CRITICAL PHISHING ATTACK DETECTED & COMPILED WITH DEFENSIVE ENVELOPE';
  } else if (classification === 'FRAUD') {
    warningHeader = 'FINANCIAL / FRAUD THREAT INTERCEPTED & MASKED';
  } else if (classification === 'SPAM') {
    warningHeader = 'PROMOTIONAL SPAM NORMALIZED BY COMPILER';
  } else if (classification === 'MISLEADING') {
    warningHeader = 'MISLEADING INFORMATION INTERCEPTED';
  } else if (classification === 'SUSPICIOUS') {
    warningHeader = 'SUSPICIOUS MESSAGE COMPILED WITH RESTRICTIONS';
  }

  // 1. x86-64 Target Assembly Generation
  const x86Code = `
; ==========================================================
; SecureChat Compiler Target Assembly (Architecture: x86-64)
; Generated Code for Classification: [${classification}]
; ==========================================================
section .data
    msg_raw:      db "${originalMessage.slice(0, 30).replace(/"/g, '\\"')}", 0
    msg_sanitized:db "${processedText.slice(0, 30).replace(/"/g, '\\"')}", 0
    risk_score:   dq ${riskScore}
    conf_level:   dq ${confidence}

section .text
    global _start

_start:
    ; Prologue: Setup stack frame
    push    rbp
    mov     rbp, rsp
    sub     rsp, 32

    ; Register Allocation Matrix:
    ; RAX -> Return Value / Exit Code
    ; RDI -> Message Payload Buffer Pointer
    ; RSI -> Security Classification Enum (${classification})
    ; RDX -> Risk Metric Weight (${riskScore})

    lea     rdi, [rel msg_sanitized]
    mov     rsi, ${riskScore}
    mov     rdx, ${confidence}

    ${
      classification !== 'SAFE'
        ? `; Security Barrier Branch
    cmp     rsi, 40
    jge     .sec_neutralize_trap
    jmp     .dispatch_client

.sec_neutralize_trap:
    ; Execute sanitized dispatch routine
    call    __sec_mask_credentials
    call    __sec_strip_links
    nop`
        : `; Safe Zero-Copy Path
    call    __dispatch_safe_stream`
    }

.dispatch_client:
    ; Epilogue & Syscall Dispatch
    mov     rax, 60         ; sys_exit
    xor     rdi, rdi        ; status = 0 (COMPILER_SUCCESS)
    syscall
`.trim();

  // 2. ARM64 (AArch64) Target Assembly Generation
  const arm64Code = `
// ==========================================================
// SecureChat Compiler Target Assembly (Architecture: ARM64)
// Generated Target Code for: [${classification}]
// ==========================================================
.data
.align 3
msg_buffer:     .asciz  "${processedText.slice(0, 30).replace(/"/g, '\\"')}"
risk_metric:    .word   ${riskScore}

.text
.global _start
.align 2

_start:
    // Setup Frame Record
    stp     x29, x30, [sp, -16]!
    mov     x29, sp

    // ARM64 Register Mapping:
    // X0 -> Base Address of Sanitized Message Stream
    // X1 -> Risk Metric Score (${riskScore})
    // X2 -> Security State Flag
    adrp    x0, msg_buffer
    add     x0, x0, :lo12:msg_buffer
    mov     x1, #${riskScore}
    mov     x2, #${confidence}

    ${
      classification !== 'SAFE'
        ? `// Security Intercept Handler
    cmp     x1, #40
    b.ge    .L_sanitize_trap
    b       .L_normal_delivery

.L_sanitize_trap:
    bl      _apply_compiler_sanitization
    nop`
        : `// Direct Streaming
    bl      _stream_verified_payload`
    }

.L_normal_delivery:
    // Teardown and Syscall
    ldp     x29, x30, [sp], 16
    mov     x8, #93         // svc_exit
    mov     x0, #0
    svc     #0
`.trim();

  // 3. MIPS32 Target Assembly Generation
  const mipsCode = `
# ==========================================================
# SecureChat Compiler Target Assembly (Architecture: MIPS32)
# Pipeline Target Code: [${classification}]
# ==========================================================
.data
msg_str:    .asciiz "${processedText.slice(0, 30).replace(/"/g, '\\"')}"
risk_val:   .word   ${riskScore}

.text
.globl main
main:
    # MIPS Register Allocation:
    # $a0 -> Message Buffer Address
    # $a1 -> Risk Value (${riskScore})
    # $v0 -> System Call Code / Return

    la      $a0, msg_str
    li      $a1, ${riskScore}
    li      $t0, 40

    ${
      classification !== 'SAFE'
        ? `bge     $a1, $t0, sanitize_flow
    nop
    j       deliver_payload
    nop

sanitize_flow:
    jal     sec_neutralize_proc
    nop`
        : `jal     safe_passthrough_proc
    nop`
    }

deliver_payload:
    li      $v0, 10         # Exit syscall
    syscall
`.trim();

  // 4. Pseudo Assembly for Education / General VM
  const pseudoCode = `
; ==========================================================
; SecureChat Compiler Pseudo-Assembly (Intermediate VM)
; Phase 6: Code Generation & Register Allocation
; ==========================================================
MODULE_BEGIN:
    ALLOC_STACK     64
    LOAD_REG        R0, &MSG_BUFFER_OPTIMIZED
    LOAD_IMM        R1, ${riskScore}              ; Risk Metric
    LOAD_IMM        R2, ${confidence}             ; Confidence
    
    CHECK_SECURITY  R1, THRESHOLD_40
    ${
      classification !== 'SAFE'
        ? `BRANCH_IF_WARN  HANDLE_THREAT
    
HANDLE_THREAT:
    APPLY_FILTER    R0, SANITIZE_ALL
    INJECT_HEADER   R0, "[${classification}_NEUTRALIZED]"
    DISPATCH_STREAM R0
    JUMP            MODULE_END`
        : `DISPATCH_DIRECT R0
    JUMP            MODULE_END`
    }

MODULE_END:
    FREE_STACK      64
    HALT_SUCCESS
`.trim();

  const assemblyOutputs: Record<TargetArchitecture, TargetAssemblyOutput> = {
    x86_64: {
      architecture: 'x86_64',
      code: x86Code,
      instructionsCount: x86Code.split('\n').filter((l) => l.trim() && !l.trim().startsWith(';') && !l.trim().startsWith('.')).length,
      registerAllocation: {
        RAX: 'Syscall Exit / Status',
        RDI: 'Message Pointer (&msg_sanitized)',
        RSI: `Risk Value (${riskScore})`,
        RDX: `Confidence (${confidence}%)`,
        RBP: 'Base Frame Pointer',
        RSP: 'Stack Pointer'
      },
      estimatedCycles: 14,
      byteSize: 128
    },
    ARM64: {
      architecture: 'ARM64',
      code: arm64Code,
      instructionsCount: arm64Code.split('\n').filter((l) => l.trim() && !l.trim().startsWith('//') && !l.trim().startsWith('.')).length,
      registerAllocation: {
        X0: 'Message Stream Pointer',
        X1: `Risk Metric (${riskScore})`,
        X2: `Confidence (${confidence}%)`,
        X8: 'Syscall Identifier (93)',
        X29: 'Frame Pointer',
        X30: 'Link Register'
      },
      estimatedCycles: 12,
      byteSize: 96
    },
    MIPS: {
      architecture: 'MIPS',
      code: mipsCode,
      instructionsCount: mipsCode.split('\n').filter((l) => l.trim() && !l.trim().startsWith('#') && !l.trim().startsWith('.')).length,
      registerAllocation: {
        '$a0': 'Argument 0: Buffer Base',
        '$a1': `Argument 1: Risk Value (${riskScore})`,
        '$t0': 'Temporary Register: Threshold 40',
        '$v0': 'Syscall Service Routine (10)'
      },
      estimatedCycles: 18,
      byteSize: 84
    },
    PSEUDO_ASSEMBLY: {
      architecture: 'PSEUDO_ASSEMBLY',
      code: pseudoCode,
      instructionsCount: pseudoCode.split('\n').filter((l) => l.trim() && !l.trim().startsWith(';')).length,
      registerAllocation: {
        R0: 'Message Buffer Register',
        R1: `Risk Metric (${riskScore})`,
        R2: `Confidence (${confidence}%)`
      },
      estimatedCycles: 8,
      byteSize: 64
    }
  };

  return {
    targetText: processedText,
    securityWarningRequired,
    warningHeader: warningHeader || '',
    warningReasons,
    classificationBadge: classification,
    confidence,
    riskScore,
    threatLevel,
    assemblyOutputs,
    selectedArch: 'x86_64',
    totalInstructions: assemblyOutputs.x86_64.instructionsCount
  };
}
