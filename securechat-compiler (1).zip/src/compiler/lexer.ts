import { LexicalResult, StandardTokenType, Token, TokenType } from './types';
import {
  ACTION_KEYWORDS,
  CREDENTIAL_KEYWORDS,
  CURRENCY_REGEX,
  EMAIL_REGEX,
  FINANCIAL_KEYWORDS,
  OTP_KEYWORDS,
  REWARD_KEYWORDS,
  URGENT_KEYWORDS,
  URL_REGEX
} from './securityRules';

const RESERVED_DSL_KEYWORDS = new Set([
  'message', 'send', 'receive', 'url', 'verify', 'account', 'bank', 'login', 'token',
  'let', 'const', 'var', 'if', 'else', 'function', 'return', 'import', 'export', 'call'
]);

export function lexicalAnalysis(message: string): LexicalResult {
  const tokens: Token[] = [];
  const urls: string[] = [];
  const emails: string[] = [];
  const phoneNumbers: string[] = [];
  const keywords: { word: string; category: TokenType }[] = [];

  if (!message || message.trim() === '') {
    return {
      tokens: [],
      urls: [],
      emails: [],
      phoneNumbers: [],
      keywords: [],
      tokenCount: 0,
      identifierCount: 0,
      literalCount: 0,
      operatorCount: 0,
      delimiterCount: 0
    };
  }

  const lines = message.split('\n');
  let currentTokenIndex = 0;
  let identifierCount = 0;
  let literalCount = 0;
  let operatorCount = 0;
  let delimiterCount = 0;

  // Global regex for URLs
  const urlRegexCopy = new RegExp(URL_REGEX.source, 'gi');
  let urlMatch: RegExpExecArray | null;
  while ((urlMatch = urlRegexCopy.exec(message)) !== null) {
    if (!urls.includes(urlMatch[0])) {
      urls.push(urlMatch[0]);
    }
  }

  // Global regex for Emails
  const emailRegexCopy = new RegExp(EMAIL_REGEX.source, 'gi');
  let emailMatch: RegExpExecArray | null;
  while ((emailMatch = emailRegexCopy.exec(message)) !== null) {
    if (!emails.includes(emailMatch[0])) {
      emails.push(emailMatch[0]);
    }
  }

  lines.forEach((lineText, lineIdx) => {
    const lineNum = lineIdx + 1;

    // Tokenize using comprehensive lexer pattern: URLs, Emails, Quoted Strings, Operators, Delimiters, Words, Numbers
    const tokenRegex = /(https?:\/\/[^\s]+|www\.[^\s]+|[a-zA-Z0-9-]+\.(?:com|org|net|xyz|info|top|site|online|tech|co|io|app|live|ru|tk)\b[^\s]*)|("[^"]*"|'[^']*')|([A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,})|((?:Rs\.?|INR|\$|€|£)\s?[\d,]+(?:\.\d{2})?)|(==|!=|<=|>=|&&|\|\||[+\-*\/=<>!%])|([()[\]{},;.:])|([a-zA-Z_]\w*)|(\d+(?:\.\d+)?)|([^\s\w])/g;

    let match: RegExpExecArray | null;
    while ((match = tokenRegex.exec(lineText)) !== null) {
      const raw = match[0];
      const colNum = match.index + 1;
      const lower = raw.toLowerCase();

      let type: TokenType = 'WORD';
      let category: StandardTokenType = 'IDENTIFIER';

      // 1. URL Literal
      if (match[1]) {
        type = 'URL';
        category = 'URL_LITERAL';
        literalCount++;
      }
      // 2. String Literal
      else if (match[2]) {
        type = 'WORD';
        category = 'STRING_LITERAL';
        literalCount++;
      }
      // 3. Email Literal
      else if (match[3]) {
        type = 'EMAIL';
        category = 'EMAIL_LITERAL';
        literalCount++;
      }
      // 4. Currency Literal
      else if (match[4]) {
        type = 'CURRENCY';
        category = 'CURRENCY_LITERAL';
        literalCount++;
      }
      // 5. Operator
      else if (match[5]) {
        type = 'SPECIAL_CHARACTER';
        category = 'OPERATOR';
        operatorCount++;
      }
      // 6. Delimiter
      else if (match[6]) {
        type = 'SPECIAL_CHARACTER';
        category = 'DELIMITER';
        delimiterCount++;
      }
      // 7. Word / Identifier / Keyword / Security Token
      else if (match[7]) {
        if (URGENT_KEYWORDS.has(lower)) {
          type = 'URGENT_KEYWORD';
          category = 'SECURITY_TOKEN';
          keywords.push({ word: raw, category: type });
        } else if (FINANCIAL_KEYWORDS.has(lower)) {
          type = 'FINANCIAL_KEYWORD';
          category = 'SECURITY_TOKEN';
          keywords.push({ word: raw, category: type });
        } else if (CREDENTIAL_KEYWORDS.has(lower)) {
          type = 'CREDENTIAL_KEYWORD';
          category = 'SECURITY_TOKEN';
          keywords.push({ word: raw, category: type });
        } else if (OTP_KEYWORDS.has(lower) || lower === 'otp') {
          type = 'OTP';
          category = 'SECURITY_TOKEN';
          keywords.push({ word: raw, category: type });
        } else if (ACTION_KEYWORDS.has(lower)) {
          type = 'ACTION_KEYWORD';
          category = 'SECURITY_TOKEN';
          keywords.push({ word: raw, category: type });
        } else if (REWARD_KEYWORDS.has(lower)) {
          type = 'REWARD_KEYWORD';
          category = 'SECURITY_TOKEN';
          keywords.push({ word: raw, category: type });
        } else if (RESERVED_DSL_KEYWORDS.has(lower)) {
          type = 'WORD';
          category = 'KEYWORD';
        } else {
          type = 'WORD';
          category = 'IDENTIFIER';
          identifierCount++;
        }
      }
      // 8. Number Literal
      else if (match[8]) {
        if (raw.length >= 4 && raw.length <= 6 && message.toLowerCase().includes('otp')) {
          type = 'OTP';
          category = 'SECURITY_TOKEN';
          keywords.push({ word: raw, category: type });
        } else {
          type = 'NUMBER';
          category = 'NUMBER_LITERAL';
          literalCount++;
        }
      }
      // 9. Special symbol
      else {
        type = 'SPECIAL_CHARACTER';
        category = 'SPECIAL_SYMBOL';
      }

      tokens.push({
        type,
        category,
        value: lower,
        raw,
        index: currentTokenIndex++,
        line: lineNum,
        col: colNum
      });
    }
  });

  return {
    tokens,
    urls,
    emails,
    phoneNumbers,
    keywords,
    tokenCount: tokens.length,
    identifierCount,
    literalCount,
    operatorCount,
    delimiterCount
  };
}
