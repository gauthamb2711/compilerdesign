import { generateCode } from './codeGenerator';
import { generateIntermediateCode } from './intermediateCode';
import { lexicalAnalysis } from './lexer';
import { optimizeMessage } from './optimizer';
import { syntaxAnalysis } from './parser';
import { semanticAnalysis } from './semanticAnalyzer';
import { CompilerConsoleLog, CompilerResult } from './types';

export function compileMessage(rawMessage: string): CompilerResult {
  const startTime = performance.now();
  const logs: CompilerConsoleLog[] = [];
  const nowStr = new Date().toLocaleTimeString();

  // Phase 1: Lexical Analysis
  const lexicalResult = lexicalAnalysis(rawMessage);
  logs.push({
    id: 'log-p1',
    type: 'INFO',
    phase: 1,
    phaseName: 'Lexical Analysis',
    message: `Tokenized source stream into ${lexicalResult.tokenCount} token(s) (${lexicalResult.identifierCount || 0} identifiers, ${lexicalResult.literalCount || 0} literals).`,
    timestamp: nowStr
  });

  // Phase 2: Syntax Analysis
  const syntaxResult = syntaxAnalysis(lexicalResult);
  if (syntaxResult.syntaxErrors.length > 0) {
    syntaxResult.syntaxErrors.forEach((err, idx) => {
      logs.push({
        id: `log-p2-err-${idx}`,
        type: 'ERROR',
        phase: 2,
        phaseName: 'Syntax Analysis',
        message: err,
        timestamp: nowStr
      });
    });
  } else {
    logs.push({
      id: 'log-p2-ok',
      type: 'SUCCESS',
      phase: 2,
      phaseName: 'Syntax Analysis',
      message: `Syntax tree built cleanly with ${syntaxResult.grammarRulesUsed.length} active grammar production rules.`,
      timestamp: nowStr
    });
  }

  if (syntaxResult.syntaxWarnings.length > 0) {
    syntaxResult.syntaxWarnings.forEach((warn, idx) => {
      logs.push({
        id: `log-p2-warn-${idx}`,
        type: 'WARNING',
        phase: 2,
        phaseName: 'Syntax Analysis',
        message: warn,
        timestamp: nowStr
      });
    });
  }

  // Phase 3: Semantic Analysis
  const semanticResult = semanticAnalysis(lexicalResult, syntaxResult, rawMessage);
  if (semanticResult.classification !== 'SAFE') {
    logs.push({
      id: 'log-p3-warn',
      type: 'WARNING',
      phase: 3,
      phaseName: 'Semantic Analysis',
      message: `Semantic Invariant Flag: Classification [${semanticResult.classification}], Risk Score: ${semanticResult.riskScore}/100.`,
      timestamp: nowStr
    });
  } else {
    logs.push({
      id: 'log-p3-ok',
      type: 'SUCCESS',
      phase: 3,
      phaseName: 'Semantic Analysis',
      message: `Semantic verification satisfied for ${semanticResult.symbolTable.length} symbol(s). Classification: [SAFE].`,
      timestamp: nowStr
    });
  }

  // Phase 4: Intermediate Code Generation
  const irResult = generateIntermediateCode(semanticResult, rawMessage);
  logs.push({
    id: 'log-p4',
    type: 'INFO',
    phase: 4,
    phaseName: 'Intermediate Code Generation',
    message: `Generated ${irResult.threeAddressCode.length} Three-Address Code (TAC) instructions and ${irResult.quadruples.length} Quadruples.`,
    timestamp: nowStr
  });

  // Phase 5: Code Optimization
  const optimizationResult = optimizeMessage(rawMessage, irResult, lexicalResult.urls);
  logs.push({
    id: 'log-p5',
    type: 'SUCCESS',
    phase: 5,
    phaseName: 'Code Optimization',
    message: `Optimization passes applied: ${optimizationResult.passes.length} passes, reduced ${optimizationResult.instructionReductionCount} instructions (${optimizationResult.improvementPercentage}% estimated improvement).`,
    timestamp: nowStr
  });

  // Phase 6: Target Code Generation
  const codeGenResult = generateCode(semanticResult, optimizationResult, rawMessage);
  logs.push({
    id: 'log-p6',
    type: 'SUCCESS',
    phase: 6,
    phaseName: 'Target Code Generation',
    message: `Target code synthesized successfully across x86-64, ARM64, and MIPS (${codeGenResult.totalInstructions} total assembly instructions).`,
    timestamp: nowStr
  });

  const endTime = performance.now();
  const executionTimeMs = parseFloat((endTime - startTime).toFixed(2));

  // Count AST nodes
  let astNodeCount = 1;
  const countAstNodes = (node: typeof syntaxResult.ast) => {
    if (node.children) {
      astNodeCount += node.children.length;
      node.children.forEach(countAstNodes);
    }
  };
  countAstNodes(syntaxResult.ast);

  return {
    originalText: rawMessage,
    lexical: lexicalResult,
    syntax: syntaxResult,
    semantic: semanticResult,
    intermediateCode: irResult,
    optimization: optimizationResult,
    codeGen: codeGenResult,
    processedText: codeGenResult.targetText,
    classification: semanticResult.classification,
    confidence: semanticResult.confidence,
    riskScore: semanticResult.riskScore,
    threatLevel: semanticResult.threatLevel,
    detectedUrls: lexicalResult.urls,
    removedUrls: optimizationResult.removedUrls,
    hasUrl: lexicalResult.urls.length > 0,
    reasons: semanticResult.riskReasons,
    statistics: {
      tokensGenerated: lexicalResult.tokenCount,
      syntaxNodes: astNodeCount,
      symbolCount: semanticResult.symbolTable.length,
      semanticChecks: semanticResult.semanticChecks.length,
      irInstructions: irResult.threeAddressCode.length,
      optimizationsApplied: optimizationResult.passes.length,
      finalInstructions: codeGenResult.totalInstructions,
      compilationTimeMs: Math.max(1.2, executionTimeMs),
      codeReductionPercent: optimizationResult.improvementPercentage
    },
    logs
  };
}
