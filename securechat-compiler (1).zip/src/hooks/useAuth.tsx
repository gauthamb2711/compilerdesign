import React, { useState, useEffect, createContext, useContext, ReactNode } from 'react';
import { User } from 'firebase/auth';
import { UserProfile } from '../types/user';
import {
  subscribeToAuthChanges,
  loginUser,
  registerUser,
  logoutUser,
  resetPassword,
  getUserProfile
} from '../services/authService';
import { initUserPresence } from '../services/presenceService';

interface AuthContextType {
  user: User | null;
  profile: UserProfile | null;
  loading: boolean;
  error: string | null;
  login: (email: string, pass: string) => Promise<UserProfile>;
  register: (fullName: string, email: string, phone: string, pass: string) => Promise<UserProfile>;
  logout: () => Promise<void>;
  forgotPassword: (email: string) => Promise<void>;
  clearError: () => void;
  refreshProfile: () => Promise<void>;
}

export const GUEST_PROFILE: UserProfile = {
  uid: 'guest_user_demo',
  fullName: 'Guest Developer',
  email: 'guest@securechat.io',
  phone: '+1 555-0199',
  emailNormalized: 'guest@securechat.io',
  phoneNormalized: '15550199',
  avatarUrl: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&w=120&q=80',
  online: true,
  lastSeen: new Date().toISOString(),
  createdAt: new Date().toISOString()
};

const AuthContext = createContext<AuthContextType | null>(null);

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [profile, setProfile] = useState<UserProfile | null>(GUEST_PROFILE);
  const [loading, setLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    let cleanupPresence: (() => void) | null = null;

    const unsubscribe = subscribeToAuthChanges(async (firebaseUser) => {
      setUser(firebaseUser);
      if (firebaseUser) {
        try {
          const userProf = await getUserProfile(firebaseUser.uid);
          setProfile(
            userProf || {
              uid: firebaseUser.uid,
              fullName: firebaseUser.displayName || firebaseUser.email?.split('@')[0] || 'User',
              email: firebaseUser.email || '',
              phone: '',
              emailNormalized: (firebaseUser.email || '').toLowerCase(),
              phoneNormalized: '',
              avatarUrl:
                firebaseUser.photoURL ||
                'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&w=120&q=80',
              online: true,
              lastSeen: new Date().toISOString(),
              createdAt: new Date().toISOString()
            }
          );
          cleanupPresence = initUserPresence(firebaseUser.uid);
        } catch (err) {
          console.error('Error fetching user profile:', err);
          setProfile(GUEST_PROFILE);
        }
      } else {
        setProfile(GUEST_PROFILE);
        if (cleanupPresence) cleanupPresence();
      }
      setLoading(false);
    });

    return () => {
      unsubscribe();
      if (cleanupPresence) cleanupPresence();
    };
  }, []);

  const login = async (email: string, pass: string) => {
    setError(null);
    setLoading(true);
    try {
      const prof = await loginUser(email, pass);
      setProfile(prof);
      return prof;
    } catch (err: any) {
      console.error('Login error:', err);
      setError(err.message || 'Failed to login. Please check credentials.');
      throw err;
    } finally {
      setLoading(false);
    }
  };

  const register = async (fullName: string, email: string, phone: string, pass: string) => {
    setError(null);
    setLoading(true);
    try {
      const prof = await registerUser(fullName, email, phone, pass);
      setProfile(prof);
      return prof;
    } catch (err: any) {
      console.error('Register error:', err);
      setError(err.message || 'Failed to create account.');
      throw err;
    } finally {
      setLoading(false);
    }
  };

  const logout = async () => {
    if (user) {
      await logoutUser(user.uid);
    }
    setUser(null);
    setProfile(null);
  };

  const forgotPassword = async (email: string) => {
    setError(null);
    try {
      await resetPassword(email);
    } catch (err: any) {
      setError(err.message || 'Failed to send password reset email.');
      throw err;
    }
  };

  const refreshProfile = async () => {
    if (user) {
      const p = await getUserProfile(user.uid);
      setProfile(p);
    }
  };

  const clearError = () => setError(null);

  return (
    <AuthContext.Provider
      value={{
        user,
        profile,
        loading,
        error,
        login,
        register,
        logout,
        forgotPassword,
        clearError,
        refreshProfile
      }}
    >
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth(): AuthContextType {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
}
