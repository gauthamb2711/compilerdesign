import { useState, useEffect } from 'react';
import { ChatMessage } from '../types';
import { subscribeToMessages, markMessagesAsSeen } from '../services/messageService';
import { subscribeToTypingStatus } from '../services/presenceService';

export function useMessages(
  conversationId: string | undefined,
  currentUserId: string | undefined,
  partnerId: string | undefined
) {
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [loading, setLoading] = useState<boolean>(false);
  const [partnerIsTyping, setPartnerIsTyping] = useState<boolean>(false);

  useEffect(() => {
    if (!conversationId) {
      setMessages([]);
      return;
    }

    setLoading(true);
    const unsubscribeMsgs = subscribeToMessages(conversationId, (data) => {
      setMessages(data);
      setLoading(false);

      if (currentUserId) {
        markMessagesAsSeen(conversationId, currentUserId, data);
      }
    });

    return () => unsubscribeMsgs();
  }, [conversationId, currentUserId]);

  useEffect(() => {
    if (!conversationId || !currentUserId) return;

    const unsubscribeTyping = subscribeToTypingStatus(
      conversationId,
      currentUserId,
      (isTyping) => {
        setPartnerIsTyping(isTyping);
      }
    );

    return () => unsubscribeTyping();
  }, [conversationId, currentUserId]);

  return {
    messages,
    loading,
    partnerIsTyping
  };
}
