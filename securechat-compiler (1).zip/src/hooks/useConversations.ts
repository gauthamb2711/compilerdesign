import { useState, useEffect } from 'react';
import { Conversation } from '../types/chat';
import { subscribeToUserConversations, resetUnreadCount } from '../services/conversationService';
import { useAuth } from './useAuth';

export function useConversations(userIdParam?: string) {
  const { user } = useAuth();
  const userId = userIdParam || user?.uid;

  const [conversations, setConversations] = useState<Conversation[]>([]);
  const [activeConversationId, setActiveConversationId] = useState<string | null>(null);
  const [loading, setLoading] = useState<boolean>(true);

  useEffect(() => {
    if (!userId) {
      setConversations([]);
      setLoading(false);
      return;
    }

    setLoading(true);
    const unsubscribe = subscribeToUserConversations(userId, (data) => {
      setConversations(data);
      setLoading(false);
    });

    return () => unsubscribe();
  }, [userId]);

  // Default to selecting first conversation if none selected
  useEffect(() => {
    if (!activeConversationId && conversations.length > 0) {
      setActiveConversationId(conversations[0].id);
    }
  }, [conversations, activeConversationId]);

  const selectConversation = (convId: string) => {
    setActiveConversationId(convId);
    if (userId && convId) {
      resetUnreadCount(convId, userId);
    }
  };

  const activeConversation = conversations.find((c) => c.id === activeConversationId) || null;

  return {
    conversations,
    activeConversation,
    activeConversationId,
    loading,
    selectConversation
  };
}
